using MetaEdge.MetaAuthWeb.Data.Models.Mapping;
using MetaEdge.MetaAuthWeb.Entity.Models;
using System.Data.Entity;

namespace MetaEdge.MetaAuthWeb.Data.Models
{
    public partial class MetaAuthWebContext : DbContext
    {
        public MetaAuthWebContext()
        {
            string connectionString = MetaEdge.Registry.ConnectionFactory.Get("MetaAuthWeb");
            base.Database.Connection.ConnectionString = connectionString;
            base.Database.CommandTimeout = 600;
        }

        public DbSet<sys_Parameters> sys_Parameters { get; set; }
        public DbSet<sys_ParameterType> sys_ParameterType { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new sys_ParametersMap());
            modelBuilder.Configurations.Add(new sys_ParameterTypeMap());
        }
    }
}
