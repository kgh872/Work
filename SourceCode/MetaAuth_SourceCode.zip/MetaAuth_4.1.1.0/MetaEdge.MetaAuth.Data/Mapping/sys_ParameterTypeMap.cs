using MetaEdge.MetaAuthWeb.Entity.Models;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.MetaAuthWeb.Data.Models.Mapping
{
    public class sys_ParameterTypeMap : EntityTypeConfiguration<sys_ParameterType>
    {
        public sys_ParameterTypeMap()
        {
            // Primary Key
            this.HasKey(t => t.TypeId);

            // Properties
            this.Property(t => t.TypeName)
                .HasMaxLength(20);

            this.Property(t => t.Comment)
                .HasMaxLength(100);

            this.Property(t => t.Comment1)
                .HasMaxLength(100);

            this.Property(t => t.Comment2)
                .HasMaxLength(100);

            this.Property(t => t.Comment3)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("sys_ParameterType");
            this.Property(t => t.TypeId).HasColumnName("TypeId");
            this.Property(t => t.AppId).HasColumnName("AppId");
            this.Property(t => t.TypeName).HasColumnName("TypeName");
            this.Property(t => t.Comment).HasColumnName("Comment");
            this.Property(t => t.Comment1).HasColumnName("Comment1");
            this.Property(t => t.Comment2).HasColumnName("Comment2");
            this.Property(t => t.Comment3).HasColumnName("Comment3");
            this.Property(t => t.Lst_Maint_Usr).HasColumnName("Lst_Maint_Usr");
            this.Property(t => t.Lst_Maint_Dt).HasColumnName("Lst_Maint_Dt");
        }
    }
}
