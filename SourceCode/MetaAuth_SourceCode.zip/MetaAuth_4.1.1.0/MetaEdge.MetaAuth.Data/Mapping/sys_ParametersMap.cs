using MetaEdge.MetaAuthWeb.Entity.Models;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.MetaAuthWeb.Data.Models.Mapping
{
    public class sys_ParametersMap : EntityTypeConfiguration<sys_Parameters>
    {
        public sys_ParametersMap()
        {
            // Primary Key
            this.HasKey(t => t.ParameterId);

            // Properties
            this.Property(t => t.TypeName)
                .HasMaxLength(20);

            this.Property(t => t.ParameterName)
                .HasMaxLength(20);

            this.Property(t => t.ParameterValue)
                .HasMaxLength(60);

            this.Property(t => t.Extension1)
                .HasMaxLength(60);

            this.Property(t => t.Extension2)
                .HasMaxLength(60);

            this.Property(t => t.Extension3)
                .HasMaxLength(60);

            // Table & Column Mappings
            this.ToTable("sys_Parameters");
            this.Property(t => t.ParameterId).HasColumnName("ParameterId");
            this.Property(t => t.AppId).HasColumnName("AppId");
            this.Property(t => t.TypeName).HasColumnName("TypeName");
            this.Property(t => t.Seq).HasColumnName("Seq");
            this.Property(t => t.ParameterName).HasColumnName("ParameterName");
            this.Property(t => t.ParameterValue).HasColumnName("ParameterValue");
            this.Property(t => t.Extension1).HasColumnName("Extension1");
            this.Property(t => t.Extension2).HasColumnName("Extension2");
            this.Property(t => t.Extension3).HasColumnName("Extension3");
            this.Property(t => t.Lst_Maint_Usr).HasColumnName("Lst_Maint_Usr");
            this.Property(t => t.Lst_Maint_Dt).HasColumnName("Lst_Maint_Dt");
        }
    }
}
