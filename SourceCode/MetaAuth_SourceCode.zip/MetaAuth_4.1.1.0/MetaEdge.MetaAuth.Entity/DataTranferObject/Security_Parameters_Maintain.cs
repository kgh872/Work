using System;
using System.Collections.Generic;

namespace MetaEdge.Security.Entity.Models
{
    public partial class Security_Parameters_Maintain
    {
        public Nullable<int> TypeId { get; set; }
        public int AppId { get; set; }
        public string TypeName { get; set; }
        public string Comment { get; set; }
        public string Comment1 { get; set; }
        public string Comment2 { get; set; }
        public string Comment3 { get; set; }
        public string Lst_Maint_Usr { get; set; }
        public Nullable<System.DateTime> Lst_Maint_Dt { get; set; }

        public ParameterDetail[] Parameters { get; set; }
        public string DeleteKeys { get; set; }
    }

    public partial class ParameterDetail
    {
        public Nullable<int> ParameterId { get; set; }
        public Nullable<int> AppId { get; set; }
        public string TypeName { get; set; }
        public Nullable<int> Seq { get; set; }
        public string ParameterName { get; set; }
        public string ParameterValue { get; set; }
        public string Extension1 { get; set; }
        public string Extension2 { get; set; }
        public string Extension3 { get; set; }
        public string Lst_Maint_Usr { get; set; }
        public Nullable<System.DateTime> Lst_Maint_Dt { get; set; }
    }
}
