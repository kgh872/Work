using System;
using System.Collections.Generic;

namespace MetaEdge.Security.Entity.Models
{
    public partial class Security_Parameters_Delete
    {
        public Security_Parameters_DeleteDetail[] DeleteDetail { get; set; }
    }

    public partial class Security_Parameters_DeleteDetail
    {
        public int AppId { get; set; }
        public int TypeId { get; set; }
        public string TypeName { get; set; }
    }
}
