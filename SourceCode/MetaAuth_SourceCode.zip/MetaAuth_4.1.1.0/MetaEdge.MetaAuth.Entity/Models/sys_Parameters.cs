using System;
using System.Collections.Generic;

namespace MetaEdge.MetaAuthWeb.Entity.Models
{
    public partial class sys_Parameters
    {
        public int ParameterId { get; set; }
        public int AppId { get; set; }
        public string TypeName { get; set; }
        public Nullable<int> Seq { get; set; }
        public string ParameterName { get; set; }
        public string ParameterValue { get; set; }
        public string Extension1 { get; set; }
        public string Extension2 { get; set; }
        public string Extension3 { get; set; }
        public string Lst_Maint_Usr { get; set; }
        public Nullable<System.DateTime> Lst_Maint_Dt { get; set; }
    }
}
