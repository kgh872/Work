using System;
using System.Collections.Generic;

namespace MetaEdge.MetaAuthWeb.Entity.Models
{
    public partial class sys_ParameterType
    {
        public int TypeId { get; set; }
        public int AppId { get; set; }
        public string TypeName { get; set; }
        public string Comment { get; set; }
        public string Comment1 { get; set; }
        public string Comment2 { get; set; }
        public string Comment3 { get; set; }
        public string Lst_Maint_Usr { get; set; }
        public Nullable<System.DateTime> Lst_Maint_Dt { get; set; }
    }
}
