﻿using System;
using System.Net;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace MetaEdge.MetaAuth.API
{
    public partial class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
            string ptcl = System.Web.Configuration.WebConfigurationManager.AppSettings["SecurityProtocolType"];
            switch (ptcl)
            {
                case "Ssl3":
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
                    break;
                case "Tls":
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
                    break;
                case "Tls11":
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11;
                    break;
                case "Tls12":
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    break;
            }
            
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            GlobalConfiguration.Configuration.IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.Always;
            System.Net.ServicePointManager.ServerCertificateValidationCallback = new System.Net.Security.RemoteCertificateValidationCallback(
            delegate(object MySender,
                System.Security.Cryptography.X509Certificates.X509Certificate MyCertificate,
                System.Security.Cryptography.X509Certificates.X509Chain MyChain,
                System.Net.Security.SslPolicyErrors MyErrors)
            {
                if (MySender is System.Net.WebRequest)
                {
                    //忽略憑証檢查，一律回傳true
                    return true;
                }
                return false;
            });
        }
        void Application_Error(object sender, EventArgs e)
        {
            try
            {
                Exception ex = Server.GetLastError();
                MetaEdge.Utility.ExceptionUtility.LogException(ex, ex.TargetSite.Name);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}