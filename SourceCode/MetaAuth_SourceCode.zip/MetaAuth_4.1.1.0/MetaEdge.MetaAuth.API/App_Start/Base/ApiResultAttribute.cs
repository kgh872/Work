﻿using MetaEdge.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;

namespace MetaEdge.MetaAuth.API
{
    public partial class WebApiConfig
    {
        public class ApiResultAttribute : System.Web.Http.Filters.ActionFilterAttribute
        {
            public override void OnActionExecuted(System.Web.Http.Filters.HttpActionExecutedContext actionExecutedContext)
            {
                base.OnActionExecuted(actionExecutedContext);

                ApiClientInfo clientInfo = GetWebInfo(actionExecutedContext.ActionContext);
                string logType = clientInfo.LogType; // actionExecutedContext.ActionContext.Request.Headers.GetValues("FATCA-LogType").ToList()[0];

                OperationLog(actionExecutedContext, clientInfo, "OnActionExecuted");

                if (actionExecutedContext.Exception == null)
                {
                    //if (actionExecutedContext.ActionContext.Response.StatusCode != System.Net.HttpStatusCode.NoContent
                    //    && actionExecutedContext.ActionContext.Response.Content == null)
                    //{
                    //    ApiResultEntity result = new ApiResultEntity();

                    //    //取得由 API 返回的狀態碼
                    //    result.Status = actionExecutedContext.ActionContext.Response.StatusCode;

                    //    //取得由 API 返回的資料
                    //    StringBuilder sb = new StringBuilder();
                    //    sb.Append("{");
                    //    sb.Append(Environment.NewLine);
                    //    sb.Append("\"value\": []");
                    //    sb.Append(Environment.NewLine);
                    //    sb.Append("}");

                    //    result.Data = sb.ToString();

                    //    HttpResponseMessage response =
                    //        new HttpResponseMessage(result.Status)
                    //        {
                    //            Content = new ObjectContent<JObject>(JObject.Parse(result.Data.ToString()), new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                    //            //Content = new ObjectContent<JObject>((item.Data), new System.Net.Http.Formatting.JsonMediaTypeFormatter(), new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("multipart/mixed"))
                    //        };

                    //    actionExecutedContext.ActionContext.Response = response;

                    //}

                    #region handle odata語法出錯的項目
                    if (!actionExecutedContext.Response.IsSuccessStatusCode && actionExecutedContext.Response.Content != null)
                    {
                        //將response的Content轉為可以序列化的物件
                        //從中取出odata Error的訊息
                        System.Net.Http.ObjectContent content = ((((System.Net.Http.ObjectContent)(actionExecutedContext.Response.Content))));

                        string errorSerialize = Newtonsoft.Json.JsonConvert.SerializeObject(content.Value, Formatting.None);
                        JObject errorObject = JObject.Parse(errorSerialize);
                        string exceptionTyp = (string)errorObject.SelectToken("ExceptionType");
                        string exceptionMsg = (string)errorObject.SelectToken("ExceptionMessage");

                        //exceptionTyp,exceptionMsg皆不為null時
                        if (!string.IsNullOrEmpty(exceptionTyp) && !string.IsNullOrEmpty(exceptionTyp))
                        {
                            //透過reflection去將Exception類別產生
                            Assembly _assembly = Assembly.Load("Microsoft.Data.OData");
                            Type objectInstance = _assembly.GetType(exceptionTyp);
                            Object[] constructParms = new object[] { exceptionMsg };  //建構式參數
                            Object reflectInsance = System.Activator.CreateInstance(objectInstance, constructParms);

                            if (reflectInsance is Microsoft.Data.OData.ODataException)
                            {
                                throw reflectInsance as Microsoft.Data.OData.ODataException;
                            }
                        }
                    }
                    #endregion
                }
            }

            public ApiClientInfo GetWebInfo(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                ApiClientInfo clientInfo = new ApiClientInfo();

                string webInfo = actionContext.Request.Headers.GetValues("WEB-INFO").ToList()[0];
                if (!string.IsNullOrEmpty(webInfo) && webInfo.Substring(0, 1) != "{")
                {
                    byte[] webInfoBytes = System.Convert.FromBase64String(webInfo);
                    string encryptWebInfo = System.Text.Encoding.GetEncoding("utf-8").GetString(webInfoBytes);
                    webInfo = MetaEdge.Security.AESDecryptor.Decrypt(encryptWebInfo);
                }

                webInfo = webInfo.TrimStart('{');
                webInfo = webInfo.TrimEnd('}');

                string[] webInfoArray = webInfo.Split(new string[] { "," }, StringSplitOptions.None);

                foreach (string strInfo in webInfoArray)
                {
                    string str = strInfo;
                    str = str.TrimStart('"').TrimEnd('"');

                    string[] strArray = str.Split(new string[] { ":" }, StringSplitOptions.None);
                    strArray[0] = strArray[0].TrimStart('"').TrimEnd('"');
                    strArray[1] = strArray[1].TrimStart('"').TrimEnd('"');

                    switch (strArray[0])
                    {
                        case "LogType":
                            clientInfo.LogType = strArray[1];
                            break;
                        case "UserId":
                            clientInfo.UserId = string.IsNullOrEmpty(strArray[1]) || strArray[1] == "null" ? 0 : int.Parse(strArray[1]);
                            break;
                        case "UserCode":
                            clientInfo.UserCode = strArray[1];
                            break;
                        case "UserName":
                            clientInfo.UserName = strArray[1];
                            break;
                        case "UserHostAddress":
                            clientInfo.UserHostAddress = strArray[1];
                            break;
                        case "AffiliateId":
                            clientInfo.AffiliateId = string.IsNullOrEmpty(strArray[1]) || strArray[1] == "null" ? 0 : int.Parse(strArray[1]);
                            break;
                        case "ActionName":
                            clientInfo.ActionName = strArray[1];
                            break;
                    }
                }

                return clientInfo;
            }

            public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                string _method = actionContext.Request.Method.ToString().ToUpper();
                string _json = Newtonsoft.Json.JsonConvert.SerializeObject(actionContext.ActionArguments);
                string _url = actionContext.Request.RequestUri.AbsoluteUri;

                MetaEdge.TextLog.ApiFactory.WriteLog(_json, _method, _url);
            }

            public class ApiResultEntity
            {
                public System.Net.HttpStatusCode Status { get; set; }

                public object Data { get; set; }

                public string ErrorMessage { get; set; }
            }

            public class NullResponseContent
            {
                public string Value { get; set; }
            }
        }

    }
}