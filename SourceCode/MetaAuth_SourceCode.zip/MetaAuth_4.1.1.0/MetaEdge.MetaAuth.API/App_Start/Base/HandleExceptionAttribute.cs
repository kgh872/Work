﻿using Microsoft.Data.OData;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http.Filters;

namespace MetaEdge.MetaAuth.API
{
    public class HandleExceptionAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            HttpStatusCode exceptionStatus = HttpStatusCode.Unused;
            Exception ex = actionExecutedContext.Exception;
            Exception baseEx = actionExecutedContext.Exception.GetBaseException();

            string exceptionType, message;
            #region exception handle
            if (baseEx is SqlException)
            {
                #region 將SqlException的訊息抓出
                string te = JsonConvert.SerializeObject(baseEx);
                JToken sqlExj = JObject.Parse(te).SelectToken("Errors").Value<JArray>()[0];

                exceptionType = baseEx.GetType().FullName;
                message = sqlExj.ToString();
                exceptionStatus = HttpStatusCode.BadRequest;
                #endregion
            }
            else if (baseEx is ODataException)
            {
                #region 將ODataException抓出
                exceptionType = baseEx.GetType().FullName;
                message = baseEx.Message;
                exceptionStatus = HttpStatusCode.BadRequest;
                #endregion
            }
            // => to String()即可查看所有ValidationErrors，不需再另外處理
            //else if (baseEx is DbEntityValidationException)
            //{
            //    #region 將DbEntityValidationException抓出
            //    DbEntityValidationException deve = baseEx as DbEntityValidationException;
            //    var entityError = deve.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
            //    var getFullMessage = string.Join("; ", entityError);
            //    var dbevExceptionMessage = string.Concat(deve.Message, "errors are: ", getFullMessage);

            //    exceptionType = baseEx.GetType().FullName;
            //    message = dbevExceptionMessage;
            //    exceptionStatus = HttpStatusCode.BadRequest;
            //    #endregion

            //}
            else
            {
                #region 將exception型別及原因回傳
                //exceptionType = baseEx.GetType().FullName;
                //exceptionMsg = baseEx.Message;
                exceptionType = ex.GetType().FullName;
                message = ex.Message;
                exceptionStatus = HttpStatusCode.InternalServerError;
                #endregion

            }
            #endregion
            JObject debuggerJO = new JObject();
            debuggerJO.Add("Request", actionExecutedContext.Request.ToString());
            debuggerJO.Add("RequestContent", GetBodyFromRequest(actionExecutedContext));
            Exception logException = new Exception(debuggerJO.ToString(), ex);
            string source = ex.GetType().FullName;
            if (actionExecutedContext.ActionContext != null && actionExecutedContext.ActionContext.ControllerContext != null)
            {
                source = actionExecutedContext.ActionContext.ControllerContext.Controller.ToString();
            }
            // Add ErrorLog
            MetaEdge.Utility.ExceptionUtility.LogException(logException, source);


            // TODO: 可取得Error Id/globalid  呈現在Message上顯示給User
            JObject exj = new JObject();
            exj.Add("ExceptionType", exceptionType);
            exj.Add("Message", "系統發生錯誤，請洽系統管理員。\n" + message);
            string exceptionMsg = exj.ToString();
            //var response = new HttpResponseMessage
            //{
            //    StatusCode = exceptionStatus,
            //    ReasonPhrase = exceptionMsg.Replace("\r\n", "")
            //};
            //response.Content = new StringContent(exceptionMsg);

            // 所有 不成功 的Response 使用CreateErrorResponse統一回傳的形式

            var response = actionExecutedContext.Request.CreateResponse(exceptionStatus, exceptionMsg.Replace("\r\n", ""));
            PropertyInfo propertyInfo = actionExecutedContext.ActionContext.GetType().GetProperty("Response");
            propertyInfo.SetValue(actionExecutedContext.ActionContext, response);
        }

        private string GetBodyFromRequest(HttpActionExecutedContext context)
        {
            string data;
            using (var stream = context.Request.Content.ReadAsStreamAsync().Result)
            {
                if (stream.CanSeek)
                {
                    stream.Position = 0;
                }
                data = context.Request.Content.ReadAsStringAsync().Result;
            }
            return data;
        }
    }

}