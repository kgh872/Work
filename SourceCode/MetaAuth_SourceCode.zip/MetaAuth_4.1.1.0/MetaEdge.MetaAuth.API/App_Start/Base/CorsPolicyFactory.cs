﻿using System.Net.Http;
using System.Web.Http.Cors;

namespace MetaEdge.MetaAuth.API
{
    public partial class WebApiConfig
    {
        #region [Custom CORS Policy Providers]
        public class CorsPolicyFactory : ICorsPolicyProviderFactory
        {
            ICorsPolicyProvider _provider = new AllowCorsPolicyAttribute();

            public ICorsPolicyProvider GetCorsPolicyProvider(HttpRequestMessage request)
            {
                return _provider;
            }
        }

        #endregion
    }
}