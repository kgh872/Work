﻿using System.Data.Entity;

namespace MetaEdge.MetaAuth.API
{
    #region[DBConfiguration]
    public class MyDbConfiguration : DbConfiguration
    {
        public MyDbConfiguration()
        {
            SetDatabaseLogFormatter(
                (context, writeAction) => new OneLineFormatter(context, writeAction));
        }
    }
    #endregion
}