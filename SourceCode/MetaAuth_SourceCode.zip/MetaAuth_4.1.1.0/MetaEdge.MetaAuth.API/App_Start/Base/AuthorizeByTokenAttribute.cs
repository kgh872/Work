﻿using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using System.Linq;
using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using MetaEdge.Web;

namespace MetaEdge.MetaAuth.API
{
    public partial class WebApiConfig
    {
        public class AuthorizeByTokenAttribute : AuthorizeAttribute
        {
            public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                base.OnAuthorization(actionContext);

                ApiClientInfo clientInfo = GetWebInfo(actionContext);
                HttpContext.Current.Items["UserId"] = clientInfo.UserId;
                HttpContext.Current.Items["UserCode"] = clientInfo.UserCode;
                HttpContext.Current.Items["AffiliateId"] = clientInfo.AffiliateId;
            }

            private static ApiClientInfo GetWebInfo(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                string webInfo = actionContext.Request.Headers.GetValues("WEB-INFO").ToList()[0];

                if (!string.IsNullOrEmpty(webInfo) && webInfo.Substring(0, 1) != "{")
                {
                    byte[] webInfoBytes = System.Convert.FromBase64String(webInfo);
                    string encryptWebInfo = System.Text.Encoding.GetEncoding("utf-8").GetString(webInfoBytes);
                    webInfo = MetaEdge.Security.AESDecryptor.Decrypt(encryptWebInfo);
                }

                ApiClientInfo clientInfo = JsonConvert.DeserializeObject<ApiClientInfo>(webInfo);
                return clientInfo;
            }

            //public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext context)
            //{
            //    System.Security.Principal.IPrincipal principal = context.ControllerContext.Request.GetUserPrincipal();
            //    if (principal == null || !principal.IsInRole("Administrators"))
            //    {
            //        context.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
            //    }

            //}

            protected override bool IsAuthorized(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                // 取得client端資訊
                var userHostAddress = ((System.Web.HttpContextWrapper)actionContext.Request.Properties["MS_HttpContext"]).Request.UserHostAddress;
                var userIdentity = ((System.Web.HttpContextWrapper)actionContext.Request.Properties["MS_HttpContext"]).Request.LogonUserIdentity;
                ApiClientInfo clientInfo = GetWebInfo(actionContext);

                string tokenExpiredSecond = MetaEdge.Registry.AppSettingsFactory.Get("TokenExpiredSecond");
                if (tokenExpiredSecond != null)
                {
                    string expiredSecondString = MetaEdge.Registry.AppSettingsFactory.Get("TokenExpiredSecond");
                    int expiredSecond = 60;
                    if (!int.TryParse(expiredSecondString, out expiredSecond))
                    {
                        expiredSecond = 60;
                    }

                    return clientInfo.RequestTime.Value.AddSeconds(expiredSecond) > System.DateTime.Now;
                }
                else
                {
                    return true;
                }
                
            }
        }
    }
}