﻿using MetaEdge.Security.Data.Models;
using System.Web.Http.OData.Builder;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using MetaEdge.MetaAuthWeb.Entity.Models;


namespace MetaEdge.MetaAuth.API
{
    public partial class WebApiConfig
    {
        private static ODataConventionModelBuilder CreateODataConventionModelBuilder()
        {
            ODataConventionModelBuilder builder = new ODataConventionModelBuilder();

            defineUserDB(ref builder);

            return builder;
        }

        private static void defineUserDB(ref ODataConventionModelBuilder builder)
        {
            #region [頁面使用的功能]

            // 登入紀錄查詢
            // =========================================================================
            builder.EntitySet<Security_log_Logon_List>("Security_log_Logon_List");
            // =========================================================================

            // 操作紀錄查詢
            // =========================================================================
            builder.EntitySet<Security_log_Audit_List>("Security_log_Audit_List");
            // =========================================================================

            // 組織維護
            // =========================================================================
            builder.EntitySet<Security_Affiliates_Delete>("Security_Affiliates_Delete");
            builder.EntitySet<Security_Affiliates_List>("Security_Affiliates_List");
            // =========================================================================

            // 人員維護
            // =========================================================================
            builder.EntitySet<Security_Users_List>("Security_Users_List");
            builder.EntitySet<Security_Users_Maintain>("Security_Users_Maintain");
            builder.EntitySet<Security_Users_List_InApplications>("Security_Users_List_InApplications");
            builder.EntitySet<auth_Roles>("Security_Users_List_InRoles");
            builder.EntitySet<auth_Roles>("Security_Users_List_NotInRoles");
            builder.EntitySet<Security_Users_Delete>("Security_Users_Delete");
            builder.EntitySet<Security_Users_ChangePw>("Security_Users_ChangePw");
            // =========================================================================

            // 人員指派角色
            // =========================================================================
            builder.EntitySet<Security_UserRole_Maintain>("Security_UserRole_Maintain");
            // =========================================================================

            // 功能表維護
            // =========================================================================
            builder.EntitySet<Security_Objects_Delete>("Security_Objects_Delete");
            // =========================================================================

            // 功能表結構維護 
            // =========================================================================
            builder.EntitySet<Security_PageMenu_Maintain>("Security_PageMenu_Maintain");
            // =========================================================================

            // 應用程式使用者指派
            // =========================================================================
            builder.EntitySet<auth_Users>("Security_Applications_List_InUsers");
            builder.EntitySet<auth_Users>("Security_Applications_List_NotInUsers");
            builder.EntitySet<Security_Applications_Maintain>("Security_Applications_Maintain");
            // =========================================================================

            // 角色維護
            // =========================================================================
            builder.EntitySet<Security_Roles_List>("Security_Roles_List");
            builder.EntitySet<Security_Roles_Delete>("Security_Roles_Delete");
            // =========================================================================

            // 參數維護
            // =========================================================================
            builder.EntitySet<Security_Parameters_Maintain>("Security_Parameters_Maintain");
            builder.EntitySet<Security_Parameters_Delete>("Security_Parameters_Delete");
            // =========================================================================

            // 權限設定
            // =========================================================================
            builder.EntitySet<Security_ObjectPermission_List>("Security_ObjectPermission_List");
            builder.EntitySet<Security_ObjectPermission_Maintain>("Security_ObjectPermission_Maintain");
            // =========================================================================

            // 角色指派權限
            // =========================================================================
            builder.EntitySet<Security_RolePermission_List>("Security_RolePermission_List");
            builder.EntitySet<Security_RolePermission_Maintain>("Security_RolePermission_Maintain");
            // =========================================================================

            // 角色指派人員
            // =========================================================================
            builder.EntitySet<auth_Users>("Security_Roles_List_InUsers");
            builder.EntitySet<auth_Users>("Security_Roles_List_NotInUsers");
            builder.EntitySet<Security_RoleUser_Maintain>("Security_RoleUser_Maintain");
            // =========================================================================

            // 系統錯誤訊息
            // =========================================================================
            builder.EntitySet<Security_log_Exception_List>("Security_log_Exception_List");
            builder.EntitySet<Security_log_Exception_View>("Security_log_Exception_View");
            // =========================================================================
            #endregion

            #region [網架框架]
            // =========================================================================
            builder.EntitySet<auth_Objects>("PageMenu"); // 系統功能選單
            builder.EntitySet<auth_Objects>("BreadcrumbTrail"); // 麵包屑導航
            builder.EntitySet<PageCommand>("PageCommand"); // 頁面可使用之功能權限
            // =========================================================================
            #endregion

            #region [職務代理人]
            // =========================================================================
            builder.EntitySet<Substitute_Users_List>("Substitute_Users_List"); // 被職務代理人選單
            // =========================================================================
            #endregion

            #region [原生資料表]
            // =========================================================================
            builder.EntitySet<auth_Affiliates>("auth_Affiliates"); // 組織檔
            builder.EntitySet<auth_Applications>("auth_Applications"); // 應用程式檔
            builder.EntitySet<auth_UserApplication>("auth_UserApplication"); // 使用者應用程式對應檔
            builder.EntitySet<auth_Users>("auth_Users"); // 使用者檔
            builder.EntitySet<auth_Roles>("auth_Roles"); // 角色檔
            builder.EntitySet<auth_Objects>("auth_Objects"); // 物件檔
            builder.EntitySet<auth_Operations>("auth_Operations"); // 操作檔
            builder.EntitySet<log_Audit>("log_Audit"); // 稽核紀錄檔
            builder.EntitySet<log_CodeTrace>("log_CodeTrace"); // 程式偵錯紀錄檔
            builder.EntitySet<log_Logon>("log_Logon"); // 登入紀錄檔
            builder.EntitySet<log_Operation>("log_Operation"); // 操作紀錄檔
            builder.EntitySet<sys_ParameterType>("sys_ParameterType"); // 參數檔
            builder.EntitySet<sys_Parameters>("sys_Parameters"); // 參數明細檔
            builder.EntitySet<sys_SSOToken>("sys_SSOToken"); // 登入簽章檔
            builder.EntitySet<log_Exception>("log_Exception"); // 系統錯誤訊息
            builder.EntitySet<sys_Notification>("sys_Notification"); //通知
            builder.EntitySet<sys_Substitute>("sys_Substitute"); //職務代理人
            // =========================================================================

            #endregion
        }
    }
}


