﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData.Batch;
using System.Web.Http.OData.Builder;
using System.Web.Http.OData.Routing.Conventions;
using MetaEdge.MetaAuth.API.ODataConventions;

namespace MetaEdge.MetaAuth.API
{
    public partial class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.EnableCors();

            //config.EnableCors(new EnableCorsAttribute("http://FATCAWEB", "*", "*"));
            config.EnableQuerySupport();

            // 新增OData Route Map
            ODataConventionModelBuilder builder = CreateODataConventionModelBuilder();

            // 新增複合主鍵的轉換處理
            var conventions = ODataRoutingConventions.CreateDefault();
            conventions.Insert(0, new CompositeKeyRoutingConvention());

            config.Routes.MapODataRoute(
                routeName: "ODataRoute",
                routePrefix: "odata",
                model: builder.GetEdmModel(),
                pathHandler: new CustomDefaultODataPathHandler(),
                routingConventions: conventions,
                batchHandler: new DefaultODataBatchHandler(GlobalConfiguration.DefaultServer));


            // 驗證使用者
            config.Filters.Add(new AuthorizeByTokenAttribute());

            config.Filters.Add(new ApiResultAttribute());

            // 處理錯誤訊息
            config.Filters.Add(new HandleExceptionAttribute());

            config.MessageHandlers.Add(new MetaEdge.Data.MethodOverrideHandler());
            //config.IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.Always;
        }

        private static bool ByPassLog(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            bool byPass = false;
            string controllerName = actionContext.ControllerContext.Controller.ToString();

            string[] byPassController = new string[]
            {
                "MetaEdge.MetaAuth.API.Controllers.BreadcrumbTrailController",
                "MetaEdge.MetaAuth.API.Controllers.PageCommandController",
                "MetaEdge.MetaAuth.API.Controllers.PageMenuController",
                "MetaEdge.MetaAuth.API.Controllers.log_AuditController",
                "MetaEdge.MetaAuth.API.Controllers.log_CodeTraceController",
                "MetaEdge.MetaAuth.API.Controllers.log_LogonController",
                "MetaEdge.MetaAuth.API.Controllers.log_OperationController",
            };

            if (byPassController.Contains(controllerName))
            {
                byPass = true;
            }

            return byPass;
        }
    }
}
