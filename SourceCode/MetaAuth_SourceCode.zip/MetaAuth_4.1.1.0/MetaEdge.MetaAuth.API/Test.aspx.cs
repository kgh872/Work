﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MetaEdge.MetaAuth.API
{
    public partial class Test : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TestDatabaseConnection();
        }

        #region [Database Connection Test]
        void TestDatabaseConnection()
        {
            string[] databaseArray = new string[] { "MetaAuth" };
            List<DatabaseTestInfo> databaseTestInfoList = new List<DatabaseTestInfo>();

            DataTable testInfo = new DataTable();
            testInfo.Columns.Add("Name");
            testInfo.Columns.Add("Status");
            testInfo.Columns.Add("Message");
        
            for (int i = 0; i < databaseArray.Length; i++)
            {
                string message = string.Empty;
                bool status = ValidateConnectionString(databaseArray[i], out message);

                testInfo.Rows.Add(databaseArray[i], status, message);
            }

            gvDatabaseTestInfo.DataSource = testInfo;
            gvDatabaseTestInfo.DataBind();
        }

        bool ValidateConnectionString(string connectionName, out string message)
        {
            bool isValidate = false;
            message = "Test connection successed.";
            string connectionString = string.Empty;
            SqlConnection conn = new SqlConnection();

            try
            {
                connectionString = MetaEdge.Registry.ConnectionFactory.Get(connectionName);
                if (string.IsNullOrEmpty(connectionString))
                {
                    message = string.Format("Connection string \"{0}\" is not found.", connectionName);
                    return false;
                }

                conn = new SqlConnection(connectionString);
                conn.Open();

                message = string.Format("{0} Database:{1}. UserId:{2}.", message, conn.Database, conn.ConnectionString);

                isValidate = true;

            }
            catch (SqlException ex)
            {
                StringBuilder errorMessages = new StringBuilder();
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    //errorMessages.Append("Index #" + i + "\n" +
                    //    "Message: " + ex.Errors[i].Message + "\n" +
                    //    "Error Number: " + ex.Errors[i].Number + "\n" +
                    //    "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                    //    "Source: " + ex.Errors[i].Source + "\n" +
                    //    "Procedure: " + ex.Errors[i].Procedure + "\n");
                    errorMessages.Append(ex.Errors[i].Message + "\n");
                }
                message = errorMessages.ToString();
            }
            catch (Exception ex)
            {
                message = ex.GetBaseException().Message;
            }
            finally
            {
                conn.Close();

            }
            return isValidate;
        }

        class DatabaseTestInfo
        {
            string Name { get; set; }
            bool Status { get; set; }
            string Message { get; set; }
            string Description { get; set; }
        }
        #endregion
    }
}