﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.OData;
//using LBOTSSO;

namespace MetaEdge.MetaAuth.API.Controllers
{
    
    public class SSOResponseController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // POST api/securityPath
        [Queryable]
        public async Task<IHttpActionResult> Post(SSORequest ssoRequest)
        {
            //SSOClient sso = new SSOClient();

            //JObject otherInfo = JObject.Parse(ssoRequest.otherInfo);
            //JObject validateState = sso.Verify(ssoRequest.verifySite,ssoRequest.ssoToken,ssoRequest.userId,ssoRequest.pwd,otherInfo);
            await db.SaveChangesAsync();


            SSOResponse loginInfo = new SSOResponse();
            loginInfo.loginStatus = true;
            loginInfo.loginMessage = "成功登入";



            return Created(loginInfo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
