﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Roles_List_InUsersController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Users> GET([FromODataUri] int RoleId)
        {
            var result = from s1 in db.auth_Users

                         join s2 in db.auth_UserRole
                           on s1.UserId equals s2.UserId

                         join s3 in db.auth_Roles
                           on s2.RoleId equals s3.RoleId
                           
                         where s2.RoleId == RoleId

                         select s1;

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
