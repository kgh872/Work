﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_RoleUser_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int RoleId, Security_RoleUser_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    var roles = db.auth_Roles.Where(o => o.RoleId == RoleId);

                    if (roles.Count() == 0)
                    {
                        return NotFound();
                    }

                    // 刪除使用者和角色的對應
                    // ===================================================
                    db.auth_UserRole.RemoveRange(db.auth_UserRole.Where(o => o.RoleId == RoleId));
                    await db.SaveChangesAsync();
                    // ===================================================

                    foreach (Security_RoleUser_Maintain_User user in list.Users)
                    {
                        auth_UserRole ur = new auth_UserRole();
                        ur.UserId = user.UserId;
                        ur.RoleId = list.RoleId;
                        ur.Lst_Maint_Usr = logonUserCode;
                        ur.Lst_Maint_Dt = DateTime.Now;

                        ur = MetaEdge.Utility.DataValidator.ValidateEntity(ur);

                        db.auth_UserRole.Add(ur);
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool auth_UsersExists(int id)
        {
            return db.auth_Users.Count(e => e.UserId == id) > 0;
        }
    }
}
