﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_ObjectPermission_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int AppId, Security_ObjectPermission_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    foreach (Security_ObjectPermission_List op in list.Detail)
                    {
                        foreach (ObjectPermission permission in op.Permissions)
                        {
                            if (permission.CheckedBefore != permission.Checked)
                            {
                                if (permission.PermissionId != 0)
                                {
                                    var p = db.auth_Permissions.Where(o => o.AppId == AppId && o.PermissionId == permission.PermissionId).First();
                                    db.auth_Permissions.Remove(p);
                                }
                                else
                                {
                                    auth_Permissions p = new auth_Permissions();
                                    p.AppId = AppId;
                                    p.ObjectId = op.ObjectId;
                                    p.OperationId = permission.OperationId;
                                    p.PermissionName = op.ObjectName + "-" + permission.OperationName;
                                    p.AppId = AppId;
                                    p.Lst_Maint_Usr = logonUserCode;
                                    p.Lst_Maint_Dt = DateTime.Now;
                                    db.auth_Permissions.Add(MetaEdge.Utility.DataValidator.ValidateEntity(p));
                                }
                            }
                        }
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
