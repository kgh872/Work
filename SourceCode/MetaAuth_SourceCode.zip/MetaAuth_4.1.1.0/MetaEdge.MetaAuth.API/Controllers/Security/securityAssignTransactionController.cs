﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System;
using System.Data.SqlClient;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class securityAssignTransactionController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Post(securityAssignTransaction security)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    db.Database.ExecuteSqlCommand("delete from auth_PagesInRoles where RoleId=@roleId", new SqlParameter("roleId", security.RoleId));
                    db.SaveChanges();

                    db.Database.ExecuteSqlCommand("delete from auth_PageFunctionsInRoles where RoleId=@roleId", new SqlParameter("roleId", security.RoleId));
                    db.SaveChanges();

                    //public List<auth_PageFunctionsInRoles> auth_PageFunctionsInRoles { get; set; }
                    //public List<auth_PagesInRoles> auth_PagesInRoles { get; set; }

                    //前端網頁已調整為=>只需勾選頁面，系統會直接授權頁面的所有功能(新修刪)
                    //foreach (auth_PageFunctionsInRoles fir in security.auth_PageFunctionsInRoles)
                    //{
                    //    db.auth_PageFunctionsInRoles.Add(fir);
                    //}
                    //db.SaveChanges();

                    foreach (auth_PagesInRoles pir in security.auth_PagesInRoles)
                    {
                        db.auth_PagesInRoles.Add(pir);
                    }
                    db.SaveChanges();

                    //自動指派勾選的頁面的所有功能(新修刪)
                    db.Database.ExecuteSqlCommand(@"insert into auth_PageFunctionsInRoles (PageId,FuncId,RoleId)
                                                    select s1.PageId,s1.FuncId,s0.RoleId as PageId from auth_PagesInRoles as s0
                                                    inner join auth_FunctionsInPages as s1 on s0.PageId = s1.PageId
                                                    where s0.RoleId = @roleId"
                        , new SqlParameter("roleId", security.RoleId));

                    //自動指派勾選的頁面的上一層、上上一層項目
                    db.Database.ExecuteSqlCommand(@"with category as
                                                    (
                                                        select LoweredPageId as PageId from auth_Pages 
                                                        where PageId in (select PageId from auth_PagesInRoles where RoleId=@roleId)
                                                    )
                                                    , module as
                                                    (
                                                        select LoweredPageId as PageId from auth_Pages
                                                        where PageId in (select PageId from category)
                                                    )
                                                    , pages as
                                                    (
                                                        select PageId from category
                                                        union
                                                        select PageId from module
                                                    )
                                                    insert into dbo.auth_PagesInRoles
                                                    select @roleId,PageId from pages"
                        , new SqlParameter("roleId", security.RoleId));

                    db.SaveChanges();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                }
            }

            return StatusCode(HttpStatusCode.Created);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
