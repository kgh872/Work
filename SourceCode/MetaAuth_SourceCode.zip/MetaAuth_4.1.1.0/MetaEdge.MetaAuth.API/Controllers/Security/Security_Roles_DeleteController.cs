﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Roles_DeleteController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Delete([FromODataUri] string RoleId, Security_Roles_Delete list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (Security_Roles_DeleteDetail detail in list.DeleteDetail)
                {
                    db.auth_UserRole.RemoveRange(db.auth_UserRole.Where(o => o.RoleId == detail.RoleId));
                    db.auth_RolePermission.RemoveRange(db.auth_RolePermission.Where(o => o.RoleId == detail.RoleId));
                    db.auth_Roles.RemoveRange(db.auth_Roles.Where(o => o.RoleId == detail.RoleId));
                }

                try
                {
                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(list);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
