﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_log_Logon_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<Security_log_Logon_List> Get([FromODataUri] int? AppId)
        {
            //SQL語法產出的內容
            //FROM            [dbo].[log_Logon] AS [Extent1]
            //INNER JOIN      [dbo].[auth_Applications] AS [Extent2] ON [Extent1].[AppId] = [Extent2].[AppId]
            //LEFT OUTER JOIN [dbo].[auth_Users] AS [Extent3] ON [Extent1].[UserId] = [Extent3].[UserId]

            var result = from s1 in db.log_Logon
                         where s1.AppId == (AppId == null ? s1.AppId : AppId)

                         join s2 in db.auth_Applications
                           on s1.AppId equals s2.AppId

                         into subGrp1

                         join s3 in db.auth_Users
                           on s1.UserId equals s3.UserId

                         into subGrp2

                         from app in subGrp1.DefaultIfEmpty()
                         from user in subGrp2.DefaultIfEmpty()

                         select new
                         {
                             ID = s1.ID
                             ,
                             AppId = s1.AppId
                             ,
                             AppName = app.AppName
                             ,
                             AppShortName = app.AppShortName
                             ,
                             UserId = s1.UserId
                             ,
                             UserCode = user.UserCode
                             ,
                             UserName = user.UserName
                             ,
                             LoginIP = s1.LoginIP
                             ,
                             LoginTime = s1.LoginTime
                             ,
                             LogoutTime = s1.LogoutTime
                             ,
                             Status = s1.Status
                         };

            List<Security_log_Logon_List> list = new List<Security_log_Logon_List>();
            foreach (var logon in result)
            {
                Security_log_Logon_List detail = new Security_log_Logon_List();
                detail.ID = logon.ID;
                detail.AppId = logon.AppId;
                detail.AppName = logon.AppName;
                detail.AppShortName = logon.AppShortName;
                detail.UserId = logon.UserId;
                detail.UserCode = logon.UserCode;
                detail.UserName = logon.UserName;
                detail.LoginIP = logon.LoginIP;
                detail.LoginTime = logon.LoginTime;
                detail.LogoutTime = logon.LogoutTime;
                detail.Status = logon.Status;

                list.Add(MetaEdge.Utility.DataValidator.ValidateEntity(detail));
            }

            return list.AsQueryable();
        }

        // GET odata/Security_log_Logon_List?appId=4&startTime='2019-04-01'&endTime='2019-04-10'
        /// <summary>Gets the specified log_Logon.</summary>
        /// <param name="appId">The application identifier.</param>
        /// <param name="startTime">The start time.</param>
        /// <param name="endTime">The end time.</param>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Security_log_Logon_List> Get([FromODataUri] int? appId, [FromODataUri] string startTime, [FromODataUri] string endTime)
        {
            DateTime startDateTime = DateTime.Parse(startTime);
            DateTime endDateTime = DateTime.Parse(endTime).AddDays(1);

            var result = from s1 in db.log_Logon
                         where s1.AppId == (appId == null ? s1.AppId : appId) && s1.LoginTime >= startDateTime && s1.LoginTime < endDateTime

                         join s2 in db.auth_Applications
                           on s1.AppId equals s2.AppId

                         into subGrp1

                         join s3 in db.auth_Users
                           on s1.UserId equals s3.UserId

                         into subGrp2

                         from app in subGrp1.DefaultIfEmpty()
                         from user in subGrp2.DefaultIfEmpty()

                         select new Security_log_Logon_List()
                         {
                             ID = s1.ID
                             ,
                             AppId = s1.AppId
                             ,
                             AppName = app.AppName
                             ,
                             AppShortName = app.AppShortName
                             ,
                             UserId = s1.UserId
                             ,
                             UserCode = user.UserCode
                             ,
                             UserName = user.UserName
                             ,
                             LoginIP = s1.LoginIP
                             ,
                             LoginTime = s1.LoginTime
                             ,
                             LogoutTime = s1.LogoutTime
                             ,
                             Status = s1.Status
                         };

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
