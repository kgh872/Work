﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Roles_List_NotInUsersController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Users> GET([FromODataUri] int RoleId)
        {
            var result = from s1 in db.auth_Users

                         // 只能夠指派該使角色的應用程式的對應人員
                         join s2 in db.auth_UserApplication
                           on s1.UserId equals s2.UserId

                         join s3 in db.auth_Roles.Where(o => o.RoleId == RoleId)
                           on s2.AppId equals s3.AppId

                         where !(from s5 in db.auth_UserRole
                                 where s5.RoleId == RoleId
                                 select s5.UserId)
                               .Contains(s1.UserId)

                         select s1;

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
