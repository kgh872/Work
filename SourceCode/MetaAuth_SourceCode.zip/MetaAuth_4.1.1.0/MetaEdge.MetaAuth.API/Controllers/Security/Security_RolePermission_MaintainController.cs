﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_RolePermission_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int RoleId, Security_RolePermission_Maintain list)
        {
            if (!ModelState.IsValid || RoleId != list.RoleId)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    db.auth_RolePermission.RemoveRange(db.auth_RolePermission.Where(o => o.RoleId == RoleId));

                    foreach (Security_RolePermission_List op in list.Detail)
                    {
                        foreach (RolePermission permission in op.Permissions)
                        {
                            if (permission.PermissionId != 0 && permission.Checked)
                            {
                                auth_RolePermission rp = new auth_RolePermission();
                                rp.RoleId = RoleId;
                                rp.PermissionId = permission.PermissionId;
                                rp.Lst_Maint_Usr = logonUserCode;
                                rp.Lst_Maint_Dt = DateTime.Now;

                                rp = MetaEdge.Utility.DataValidator.ValidateEntity(rp);

                                db.auth_RolePermission.Add(rp);
                            }
                        }
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
