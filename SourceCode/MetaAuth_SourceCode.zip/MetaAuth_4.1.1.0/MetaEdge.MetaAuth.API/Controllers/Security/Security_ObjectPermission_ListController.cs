﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_ObjectPermission_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        /// <summary>
        /// 權限設定 - 查詢清單
        /// </summary>
        /// <param name="AppId">以應用程式Id來篩選權限設定</param>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Security_ObjectPermission_List> Get([FromODataUri] int? AppId)
        {
            List<Security_ObjectPermission_List> list = new List<Security_ObjectPermission_List>();

            var modules = db.auth_Objects.Where(o => o.Parent == 0 && o.AppId == AppId).OrderBy(o => o.MenuPosition).ToList();

            foreach (var module in modules)
            {
                Security_ObjectPermission_List mObj = new Security_ObjectPermission_List();
                mObj.ObjectId = module.ObjectId;
                mObj.ObjectName = module.ObjectName;
                mObj.ModulePosition = module.MenuPosition;
                mObj.CategoryPosition = 0;
                mObj.ActionPosition = 0;

                mObj = MetaEdge.Utility.DataValidator.ValidateEntity(mObj);

                list.Add(mObj);

                var categorys = db.auth_Objects.Where(o => o.Parent == mObj.ObjectId && o.AppId == AppId).OrderBy(o => o.MenuPosition).ToList();

                foreach (var category in categorys)
                {
                    Security_ObjectPermission_List cObj = new Security_ObjectPermission_List();
                    cObj.ObjectId = category.ObjectId;
                    cObj.ObjectName = category.ObjectName;
                    cObj.ModulePosition = module.MenuPosition;
                    cObj.CategoryPosition = category.MenuPosition;
                    cObj.ActionPosition = 0;

                    cObj = MetaEdge.Utility.DataValidator.ValidateEntity(cObj);

                    list.Add(cObj);

                    var actions = db.auth_Objects.Where(o => o.Parent == cObj.ObjectId && o.AppId == AppId).OrderBy(o => o.MenuPosition).ToList();

                    foreach (var action in actions)
                    {
                        Security_ObjectPermission_List aObj = new Security_ObjectPermission_List();
                        aObj.ObjectId = action.ObjectId;
                        aObj.ObjectName = action.ObjectName;
                        aObj.ModulePosition = module.MenuPosition;
                        aObj.CategoryPosition = category.MenuPosition;
                        aObj.ActionPosition = action.MenuPosition;
                        list.Add(MetaEdge.Utility.DataValidator.ValidateEntity(aObj));
                    }
                }
            }

            foreach (Security_ObjectPermission_List permission in list)
            {
                var operations = (from s1 in db.auth_Operations.Where(o => o.AppId == AppId)

                                  join s2 in db.auth_Permissions.Where(o => o.AppId == AppId && o.ObjectId == permission.ObjectId)
                                    on s1.OperationId equals s2.OperationId

                                  into subGrp
                                  from result in subGrp.DefaultIfEmpty()

                                  select new
                                  {
                                      PermissionId = result.PermissionId != null ? result.PermissionId : 0
                                      ,
                                      OperationId = s1.OperationId
                                      ,
                                      OperationCode = s1.OperationCode
                                      ,
                                      Seq = s1.Seq
                                      ,
                                      Type = s1.Type
                                      ,
                                      OperationName = s1.OperationName
                                      ,
                                      Checked = result.ObjectId != null
                                  }).ToList();
                ObjectPermission[] permissions = new ObjectPermission[operations.Count()];

                for (int i = 0; i < permissions.Count(); i++)
                {
                    ObjectPermission op = new ObjectPermission();
                    op.PermissionId = operations[i].PermissionId;
                    op.OperationId = operations[i].OperationId;
                    op.Seq = operations[i].Seq;
                    op.Type = operations[i].Type;
                    op.OperationName = operations[i].OperationName;
                    op.CheckedBefore = operations[i].Checked;
                    op.Checked = operations[i].Checked;
                    permissions[i] = op;
                }

                permission.Permissions = permissions;
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
