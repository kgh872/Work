﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_PageMenu_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int AppId, Security_PageMenu_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    // 在前端新增的項目 ObjectId 會是 GUID，實際新增至資料庫後，ObjectId 會是遞增 int，所以用 Dictionary 來紀錄對照表
                    // 主要用於 Parent 欄位
                    Dictionary<string, int> ModuleGuid = new Dictionary<string, int>();
                    Dictionary<string, int> CategoryGuid = new Dictionary<string, int>();

                    foreach (PageMenu module in list.Modules)
                    {
                        int objectId;
                        auth_Objects obj = CreateObject(module, logonUserCode);

                        // 若 ObjectId 為 int，代表是即有資料，需執行編輯作業
                        if (int.TryParse(module.ObjectId, out objectId))
                        {
                            obj.ObjectId = objectId;
                            db.Entry(obj).State = EntityState.Modified;
                        }
                        else
                        {
                            obj = MetaEdge.Utility.DataValidator.ValidateEntity(obj);

                            db.auth_Objects.Add(obj);
                            await db.SaveChangesAsync();
                            ModuleGuid.Add(MetaEdge.Utility.DataValidator.ValidateObject(module.ObjectId), obj.ObjectId);
                        }
                    }

                    foreach (PageMenu category in list.Categorys)
                    {
                        // 取得在資料庫的 ObjectId
                        if (ModuleGuid.ContainsKey(category.Parent))
                        {
                            category.Parent = ModuleGuid[category.Parent].ToString();
                        }

                        int objectId;
                        auth_Objects obj = CreateObject(category, logonUserCode);

                        // 若 ObjectId 為 int，代表是即有資料，需執行編輯作業
                        if (int.TryParse(category.ObjectId, out objectId))
                        {
                            obj.ObjectId = objectId;
                            db.Entry(obj).State = EntityState.Modified;
                        }
                        else
                        {
                            obj = MetaEdge.Utility.DataValidator.ValidateEntity(obj);

                            db.auth_Objects.Add(obj);
                            await db.SaveChangesAsync();
                            CategoryGuid.Add(MetaEdge.Utility.DataValidator.ValidateObject(category.ObjectId), obj.ObjectId);
                        }
                    }

                    foreach (PageMenu action in list.Actions)
                    {
                        // 取得在資料庫的 ObjectId
                        if (CategoryGuid.ContainsKey(action.Parent))
                        {
                            action.Parent = CategoryGuid[action.Parent].ToString();
                        }

                        int objectId;
                        auth_Objects obj = CreateObject(action, logonUserCode);

                        // 若 ObjectId 為 int，代表是即有資料，需執行編輯作業
                        if (int.TryParse(action.ObjectId, out objectId))
                        {
                            obj.ObjectId = objectId;
                            db.Entry(obj).State = EntityState.Modified;
                        }
                        else
                        {
                            obj = MetaEdge.Utility.DataValidator.ValidateEntity(obj);

                            db.auth_Objects.Add(obj);
                        }
                    }

                    foreach (PageMenu deletedPage in list.DeletedObjects)
                    {
                        int objectId = int.Parse(deletedPage.ObjectId);
                        db.auth_Objects.RemoveRange(db.auth_Objects.Where(o => o.ObjectId == objectId));
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        private auth_Objects CreateObject(PageMenu page, string logonUserCode)
        {
            auth_Objects obj = new auth_Objects();
            obj.AppId = page.AppId;
            obj.ObjectCode = page.ObjectCode;

            int parentId = 0;
            if (int.TryParse(page.Parent, out parentId))
            {
                obj.Parent = parentId;
            }

            obj.ObjectName = page.ObjectName;
            obj.MenuPosition = page.MenuPosition;
            obj.MenuText = page.MenuText;
            obj.ToolTipText = page.ToolTipText;
            obj.NavigateUrl = page.NavigateUrl;
            obj.ReportUrl = page.ReportUrl;
            obj.MenuClass = page.MenuClass;
            obj.Suspended = page.Suspended;
            obj.IconUrl = page.IconUrl;
            obj.AffiliateId = page.AffiliateId;
            obj.Lst_Maint_Usr = logonUserCode;
            obj.Lst_Maint_Dt = DateTime.Now;

            return obj;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
