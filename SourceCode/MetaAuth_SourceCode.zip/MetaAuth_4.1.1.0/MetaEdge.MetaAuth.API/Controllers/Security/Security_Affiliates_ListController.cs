﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Affiliates_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<Security_Affiliates_List> Get()
        {
            var result = from s1 in db.auth_Affiliates

                         join s2 in db.auth_Affiliates
                           on s1.Parent equals s2.AffiliateId

                         into subGrp1

                         from affiliate in subGrp1.DefaultIfEmpty()

                         select new Security_Affiliates_List
                         {
                             AffiliateId = s1.AffiliateId
                             ,
                             AffiliateCode = s1.AffiliateCode
                             ,
                             AffiliateName = s1.AffiliateName
                             ,
                             Parent = s1.Parent
                             ,
                             ParentCode = affiliate.AffiliateCode
                             ,
                             ParentName = affiliate.AffiliateName
                             ,
                             Lst_Maint_Usr = s1.Lst_Maint_Usr
                             ,
                             Lst_Maint_Dt = s1.Lst_Maint_Dt
                         };

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
