﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Applications_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int AppId, Security_Applications_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    var apps = db.auth_Applications.Where(o => o.AppId == AppId);

                    if (apps.Count() == 0)
                    {
                        return NotFound();
                    }

                    // 刪除使用者和應用程式的對應
                    // ===================================================
                    db.auth_UserApplication.RemoveRange(db.auth_UserApplication.Where(o => o.AppId == AppId));
                    // ===================================================

                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    foreach (Security_Applications_Maintain_User app in list.Users)
                    {
                        auth_UserApplication ua = new auth_UserApplication();
                        ua.UserId = app.UserId;
                        ua.AppId = list.AppId;
                        ua.Lst_Maint_Usr = logonUserCode;
                        ua.Lst_Maint_Dt = DateTime.Now;

                        db.auth_UserApplication.Add(MetaEdge.Utility.DataValidator.ValidateEntity(ua));
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool auth_UsersExists(int id)
        {
            return db.auth_Users.Count(e => e.UserId == id) > 0;
        }
    }
}
