﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_log_Exception_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<Security_log_Exception_List> Get([FromODataUri] int? AppId)
        {
            var result = from s1 in db.log_Exception
                         where s1.AppId == (AppId == null ? s1.AppId : AppId)

                         join s2 in db.auth_Applications
                           on s1.AppId equals s2.AppId

                         into subGrp1

                         from log in subGrp1.DefaultIfEmpty()
                         select new Security_log_Exception_List()
                         {
                             ID = s1.ID
                             ,
                             GlobalId = s1.GlobalId
                             ,
                             AppId = s1.AppId
                             ,
                             AppName = log.AppName
                             ,
                             AppShortName = log.AppShortName
                             ,
                             HostName = s1.HostName
                             ,
                             ServiceName = s1.ServiceName
                             ,
                             LogLevel = s1.LogLevel
                             ,
                             Source = s1.Source
                             ,
                             Message = s1.Message
                             ,
                             LogTime = s1.LogTime
                         };

            return result;
        }

        [Queryable]
        public IQueryable<Security_log_Exception_List> Get([FromODataUri] int? AppId, [FromODataUri] string startTime, [FromODataUri] string endTime)
        {
            DateTime startDateTime = DateTime.Parse(startTime);
            DateTime endDateTime = DateTime.Parse(endTime).AddDays(1);

            var result = from s1 in db.log_Exception
                         where s1.AppId == (AppId == null ? s1.AppId : AppId) && s1.LogTime >= startDateTime && s1.LogTime < endDateTime

                         join s2 in db.auth_Applications
                           on s1.AppId equals s2.AppId

                         into subGrp1

                         from log in subGrp1.DefaultIfEmpty()
                         select new Security_log_Exception_List()
                         {
                             ID = s1.ID
                             ,
                             GlobalId = s1.GlobalId
                             ,
                             AppId = s1.AppId
                             ,
                             AppName = log.AppName
                             ,
                             AppShortName = log.AppShortName
                             ,
                             HostName = s1.HostName
                             ,
                             ServiceName = s1.ServiceName
                             ,
                             LogLevel = s1.LogLevel
                             ,
                             Source = s1.Source
                             ,
                             Message = s1.Message
                             ,
                             LogTime = s1.LogTime
                         };

            return result;
        }

        [Queryable]
        public IQueryable<Security_log_Exception_List> GET([FromODataUri] Int64 ID)
        {
            var result = from s1 in db.log_Exception
                         where s1.ID == ID

                         join s2 in db.auth_Applications
                           on s1.AppId equals s2.AppId

                         into subGrp1

                         from log in subGrp1.DefaultIfEmpty()
                         select new Security_log_Exception_List()
                         {

                             ID = s1.ID
                             ,
                             GlobalId = s1.GlobalId
                             ,
                             AppId = s1.AppId
                             ,
                             AppName = log.AppName
                             ,
                             AppShortName = log.AppShortName
                             ,
                             HostName = s1.HostName
                             ,
                             ServiceName = s1.ServiceName
                             ,
                             LogLevel = s1.LogLevel
                             ,
                             Source = s1.Source
                             ,
                             Message = s1.Message
                             ,
                             LogTime = s1.LogTime
                         };

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}