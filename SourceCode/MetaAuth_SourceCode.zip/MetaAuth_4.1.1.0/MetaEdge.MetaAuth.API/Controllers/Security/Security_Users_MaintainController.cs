﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Users_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Post(Security_Users_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
                    auth_Users user = new auth_Users();
                    user.UserCode = list.UserCode;
                    user.UserName = list.UserName;
                    user.AffiliateId = list.AffiliateId;

                    if (!string.IsNullOrEmpty(list.Password))
                    {
                        user.Password = MetaEdge.Security.Cryptography.ToSHA512(list.Password);
                    }

                    user.SignOnRetryLimit = list.SignOnRetryLimit;
                    user.SignOnErrorCnt = 0;
                    user.Suspended = list.Suspended;

                    if (list.Suspended == true)
                    {
                        user.SuspendedDate = DateTime.Now;
                    }

                    user.LastPasswordChangedDate = null;// DateTime.Now;

                    user.Email = list.Email;
                    user.Comment = list.Comment;
                    user.Domain = list.Domain;
                    user.Lst_Maint_Usr = logonUserCode;
                    user.Lst_Maint_Dt = DateTime.Now;

                    user = MetaEdge.Utility.DataValidator.ValidateEntity(user);

                    db.auth_Users.Add(user);
                    await db.SaveChangesAsync();

                    foreach (Security_Users_Maintain_Application app in list.Applications)
                    {
                        auth_UserApplication ua = new auth_UserApplication();
                        ua.UserId = user.UserId;
                        ua.AppId = app.AppId;
                        ua.Lst_Maint_Usr = logonUserCode;
                        ua.Lst_Maint_Dt = DateTime.Now;

                        ua = MetaEdge.Utility.DataValidator.ValidateEntity(ua);

                        db.auth_UserApplication.Add(ua);
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int UserId, Security_Users_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    int logonUserId = int.Parse(HttpContext.Current.Items["UserId"].ToString());
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    var users = db.auth_Users.Where(o => o.UserId == UserId);

                    if (users.Count() == 0)
                    {
                        return NotFound();
                    }
                    else
                    {
                        auth_Users user = users.First();
                        user.UserName = list.UserName;
                        user.AffiliateId = list.AffiliateId;

                        // 判斷密碼是否有變更，若有的話，需要再次加密密碼
                        if (user.Password != list.Password)
                        {
                            user.Password = MetaEdge.Security.Cryptography.ToSHA512(list.Password);
                            user.LastPasswordChangedDate = null; // DateTime.Now;
                        }

                        user.SignOnRetryLimit = list.SignOnRetryLimit;
                        user.SignOnErrorCnt = 0;
                        user.Suspended = list.Suspended;

                        if (list.Suspended == true)
                        {
                            user.SuspendedDate = DateTime.Now;
                        }

                        user.Email = list.Email;
                        user.Comment = list.Comment;
                        user.Domain = list.Domain;
                        user.Lst_Maint_Usr = logonUserCode;
                        user.Lst_Maint_Dt = DateTime.Now;
                        db.Entry(user).State = EntityState.Modified;
                    }

                    // 刪除使用者和應用程式的對應
                    // 因為 user1 可能有1個以上的應用程式權限，但設定人員卻不一定相同的權限
                    // 所以只會刪除設定人員所可以編輯的應用程式權限
                    // 例如：設定人員有app1、app3、app5，user1有app1、app2、app3，所以只會刪除user1的app1、app3
                    // ===================================================
                    var result = from s1 in db.auth_UserApplication.Where(o => o.UserId == UserId)

                                 join s2 in db.auth_UserApplication.Where(o => o.UserId == logonUserId)
                                   on s1.AppId equals s2.AppId

                                 select s1;

                    db.auth_UserApplication.RemoveRange(result);
                    // ===================================================

                    foreach (Security_Users_Maintain_Application app in list.Applications)
                    {
                        auth_UserApplication ua = new auth_UserApplication();
                        ua.UserId = list.UserId;
                        ua.AppId = app.AppId;
                        ua.Lst_Maint_Usr = logonUserCode;
                        ua.Lst_Maint_Dt = DateTime.Now;

                        ua = MetaEdge.Utility.DataValidator.ValidateEntity(ua);

                        db.auth_UserApplication.Add(ua);
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool auth_UsersExists(int id)
        {
            return db.auth_Users.Count(e => e.UserId == id) > 0;
        }
    }
}
