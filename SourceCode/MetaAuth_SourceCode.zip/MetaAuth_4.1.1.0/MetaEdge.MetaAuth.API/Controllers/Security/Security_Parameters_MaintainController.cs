﻿using MetaEdge.MetaAuthWeb.Data.Models;
using MetaEdge.MetaAuthWeb.Entity.Models;
using MetaEdge.Security.Entity.Models;
using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Parameters_MaintainController : ODataController
    {
        private MetaAuthWebContext db = new MetaAuthWebContext();

        public async Task<IHttpActionResult> Post(Security_Parameters_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    sys_ParameterType spt = new sys_ParameterType();
                    spt.AppId = list.AppId;
                    spt.TypeName = list.TypeName;
                    spt.Comment = list.Comment;
                    spt.Comment1 = list.Comment1;
                    spt.Comment2 = list.Comment2;
                    spt.Comment3 = list.Comment3;
                    spt.Lst_Maint_Usr = logonUserCode;
                    spt.Lst_Maint_Dt = DateTime.Now;

                    spt = MetaEdge.Utility.DataValidator.ValidateEntity(spt);

                    db.sys_ParameterType.Add(spt);

                    foreach (ParameterDetail param in list.Parameters)
                    {
                        sys_Parameters sp = new sys_Parameters();
                        sp.AppId = list.AppId;
                        sp.TypeName = list.TypeName;
                        sp.Seq = param.Seq;
                        sp.ParameterName = param.ParameterName;
                        sp.ParameterValue = param.ParameterValue;
                        sp.Extension1 = param.Extension1;
                        sp.Extension2 = param.Extension2;
                        sp.Extension3 = param.Extension3;
                        sp.Lst_Maint_Usr = logonUserCode;
                        sp.Lst_Maint_Dt = DateTime.Now;

                        sp = MetaEdge.Utility.DataValidator.ValidateEntity(sp);
                        db.sys_Parameters.Add(sp);
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int TypeId, Security_Parameters_Maintain list)
        {
            if (!ModelState.IsValid || TypeId != list.TypeId)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    var result = db.sys_ParameterType.Where(o => o.TypeId == TypeId);

                    if (result.Count() == 0)
                    {
                        return NotFound();
                    }

                    sys_ParameterType spt = result.First();
                    spt.Comment = list.Comment;
                    spt.Comment1 = list.Comment1;
                    spt.Comment2 = list.Comment2;
                    spt.Comment3 = list.Comment3;
                    spt.Lst_Maint_Usr = logonUserCode;
                    spt.Lst_Maint_Dt = DateTime.Now;

                    db.Entry<sys_ParameterType>(spt).State = EntityState.Modified;

                    string[] deleteKeys = list.DeleteKeys.Split(';');
                    foreach (string key in deleteKeys)
                    {
                        int id;
                        if (int.TryParse(key, out id))
                        {
                            db.sys_Parameters.RemoveRange(db.sys_Parameters.Where(o => o.AppId == list.AppId && o.ParameterId == id));
                        }
                    }
                    
                    foreach (ParameterDetail param in list.Parameters)
                    {
                        if (param.ParameterId == null)
                        {
                            sys_Parameters sp = new sys_Parameters();
                            sp.AppId = list.AppId;
                            sp.TypeName = list.TypeName;
                            sp.Seq = param.Seq;
                            sp.ParameterName = param.ParameterName;
                            sp.ParameterValue = param.ParameterValue;
                            sp.Extension1 = param.Extension1;
                            sp.Extension2 = param.Extension2;
                            sp.Extension3 = param.Extension3;
                            sp.Lst_Maint_Usr = logonUserCode;
                            sp.Lst_Maint_Dt = DateTime.Now;

                            sp = MetaEdge.Utility.DataValidator.ValidateEntity(sp);

                            db.sys_Parameters.Add(sp);
                        }
                        else
                        {
                            sys_Parameters sp = db.sys_Parameters.Where(o => o.AppId == list.AppId && o.ParameterId == param.ParameterId).First();
                            sp.Seq = param.Seq;
                            sp.ParameterName = param.ParameterName;
                            sp.ParameterValue = param.ParameterValue;
                            sp.Extension1 = param.Extension1;
                            sp.Extension2 = param.Extension2;
                            sp.Extension3 = param.Extension3;
                            sp.Lst_Maint_Usr = logonUserCode;
                            sp.Lst_Maint_Dt = DateTime.Now;

                            db.Entry<sys_Parameters>(sp).State = EntityState.Modified;
                        }
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
