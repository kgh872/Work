﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Roles_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        /// <summary>
        /// 角色維護 - 查詢清單
        /// </summary>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Security_Roles_List> Get([FromODataUri] int? AppId)
        {
            var result = (from s1 in db.auth_Roles.Where(o => o.AppId == AppId)

                          join s2 in db.auth_Applications
                           on s1.AppId equals s2.AppId

                         into subGrp1

                          from application in subGrp1.DefaultIfEmpty()

                         select new
                         {
                             RoleId = s1.RoleId
                             ,
                             AppId = s1.AppId
                             ,
                             AppName = application.AppName
                             ,
                             RoleCode = s1.RoleCode
                             ,
                             RoleName = s1.RoleName
                             ,
                             Parent = s1.Parent
                             ,
                             Comment = s1.Comment
                             ,
                             AffiliateId = s1.AffiliateId
                             ,
                             Lst_Maint_Usr = s1.Lst_Maint_Usr
                             ,
                             Lst_Maint_Dt = s1.Lst_Maint_Dt
                         }).Distinct();

            List<Security_Roles_List> list = new List<Security_Roles_List>();

            foreach (var role in result)
            {
                Security_Roles_List detail = new Security_Roles_List();
                detail.RoleId = role.RoleId;
                detail.AppId = role.AppId;
                detail.AppName = role.AppName;
                detail.RoleCode = role.RoleCode;
                detail.RoleName = role.RoleName;
                detail.Parent = role.Parent;
                detail.Comment = role.Comment;
                detail.AffiliateId = role.AffiliateId;
                detail.Lst_Maint_Usr = role.Lst_Maint_Usr;

                detail = MetaEdge.Utility.DataValidator.ValidateEntity(detail);

                list.Add(detail);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
