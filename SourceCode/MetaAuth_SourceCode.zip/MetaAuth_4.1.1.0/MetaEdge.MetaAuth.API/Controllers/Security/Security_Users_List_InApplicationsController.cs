﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Users_List_InApplicationsController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<Security_Users_List_InApplications> GET([FromODataUri] int? UserId)
        {
            int logonUserId = int.Parse(HttpContext.Current.Items["UserId"].ToString());

            var result = from s1 in db.auth_Applications

                         join s2 in db.auth_UserApplication.Where(o => o.UserId == UserId)
                           on s1.AppId equals s2.AppId

                         into subGrp1
                         from ua1 in subGrp1.DefaultIfEmpty()

                         join s3 in db.auth_UserApplication.Where(o => o.UserId == logonUserId)
                           on s1.AppId equals s3.AppId

                         into subGrp2
                         from ua2 in subGrp2.DefaultIfEmpty()

                         select new
                         {
                             AppId = s1.AppId
                             ,
                             AppName = s1.AppName
                             ,
                             AppShortName = s1.AppShortName
                             ,
                             Comment = s1.Comment
                             ,
                             Checked = ua1.UserId != null
                             ,
                             Enabled = ua2.UserId != null
                         };

            List<Security_Users_List_InApplications> list = new List<Security_Users_List_InApplications>();

            foreach (var app in result)
            {
                Security_Users_List_InApplications detail = new Security_Users_List_InApplications();
                detail.AppId = app.AppId;
                detail.AppName = app.AppName;
                detail.AppShortName = app.AppShortName;
                detail.Comment = app.Comment;
                detail.Checked = app.Checked;
                detail.Enabled = app.Enabled;

                detail = MetaEdge.Utility.DataValidator.ValidateEntity(detail);

                list.Add(detail);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
