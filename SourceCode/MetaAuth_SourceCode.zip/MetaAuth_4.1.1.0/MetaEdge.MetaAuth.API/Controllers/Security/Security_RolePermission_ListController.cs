﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_RolePermission_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        /// <summary>
        /// 角色權限設定
        /// </summary>
        /// <param name="AppId">以應用程式Id來篩選權限設定</param>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Security_RolePermission_List> Get([FromODataUri] int AppId, [FromODataUri] int RoleId)
        {
            List<Security_RolePermission_List> list = new List<Security_RolePermission_List>();

            var modules = db.auth_Objects.Where(o => o.Parent == 0 && o.AppId == AppId).OrderBy(o => o.MenuPosition).ToList();

            foreach (var module in modules)
            {
                Security_RolePermission_List mObj = new Security_RolePermission_List();
                mObj.ObjectId = module.ObjectId;
                mObj.ObjectName = module.ObjectName;
                mObj.ModulePosition = module.MenuPosition;
                mObj.CategoryPosition = 0;
                mObj.ActionPosition = 0;

                mObj = MetaEdge.Utility.DataValidator.ValidateEntity(mObj);

                list.Add(mObj);

                var categorys = db.auth_Objects.Where(o => o.Parent == mObj.ObjectId && o.AppId == AppId).OrderBy(o => o.MenuPosition).ToList();

                foreach (var category in categorys)
                {
                    Security_RolePermission_List cObj = new Security_RolePermission_List();
                    cObj.ObjectId = category.ObjectId;
                    cObj.ObjectName = category.ObjectName;
                    cObj.ModulePosition = module.MenuPosition;
                    cObj.CategoryPosition = category.MenuPosition;
                    cObj.ActionPosition = 0;

                    cObj = MetaEdge.Utility.DataValidator.ValidateEntity(cObj);

                    list.Add(cObj);

                    var actions = db.auth_Objects.Where(o => o.Parent == cObj.ObjectId && o.AppId == AppId).OrderBy(o => o.MenuPosition).ToList();

                    foreach (var action in actions)
                    {
                        Security_RolePermission_List aObj = new Security_RolePermission_List();
                        aObj.ObjectId = action.ObjectId;
                        aObj.ObjectName = action.ObjectName;
                        aObj.ModulePosition = module.MenuPosition;
                        aObj.CategoryPosition = category.MenuPosition;
                        aObj.ActionPosition = action.MenuPosition;

                        aObj = MetaEdge.Utility.DataValidator.ValidateEntity(aObj);

                        list.Add(aObj);
                    }
                }
            }

            foreach (Security_RolePermission_List permission in list)
            {
                var operations = (from s1 in db.auth_Operations.Where(o => o.AppId == AppId)

                                  join s2 in db.auth_Permissions.Where(o => o.AppId == AppId && o.ObjectId == permission.ObjectId)
                                    on s1.OperationId equals s2.OperationId

                                  into subGrp1
                                  from result1 in subGrp1.DefaultIfEmpty()

                                  join s3 in db.auth_RolePermission.Where(o => o.RoleId == RoleId)
                                    on result1.PermissionId equals s3.PermissionId

                                  into subGrp2
                                  from result2 in subGrp2.DefaultIfEmpty()

                                  select new
                                  {
                                      PermissionId = result1.PermissionId != null ? result1.PermissionId : 0
                                      ,
                                      OperationId = s1.OperationId
                                      ,
                                      OperationCode = s1.OperationCode
                                      ,
                                      Seq = s1.Seq
                                      ,
                                      Type = s1.Type
                                      ,
                                      OperationName = s1.OperationName
                                      ,
                                      Visible = result1.ObjectId != null
                                      ,
                                      Checked = result2.PermissionId != null
                                  }).ToList();
                RolePermission[] permissions = new RolePermission[operations.Count()];

                for (int i = 0; i < permissions.Count(); i++)
                {
                    RolePermission op = new RolePermission();
                    op.PermissionId = operations[i].PermissionId;
                    op.OperationId = operations[i].OperationId;
                    op.Seq = operations[i].Seq;
                    op.Type = operations[i].Type;
                    op.OperationName = operations[i].OperationName;
                    op.Checked = operations[i].Checked;
                    op.CheckedBefore = operations[i].Checked;
                    op.Visible = operations[i].Visible;
                    permissions[i] = op;
                }

                permission.Permissions = permissions;
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
