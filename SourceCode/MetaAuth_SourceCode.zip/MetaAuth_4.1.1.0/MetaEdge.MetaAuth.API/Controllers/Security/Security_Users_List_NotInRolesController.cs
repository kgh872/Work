﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Users_List_NotInRolesController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Roles> GET([FromODataUri] int UserId)
        {
            int logonUserId = int.Parse(HttpContext.Current.Items["UserId"].ToString());

            var result = from s1 in db.auth_Roles

                         // 只能夠指派該使用者擁有的應用程式底下的角色
                         join s3 in db.auth_UserApplication.Where(o => o.UserId == UserId)
                           on s1.AppId equals s3.AppId

                         // 只能夠指派該設定人員擁有的應用程式底下的角色
                         join s4 in db.auth_UserApplication.Where(o => o.UserId == logonUserId)
                           on s1.AppId equals s4.AppId

                         where !(from s2 in db.auth_UserRole
                                 where s2.UserId == UserId
                                 select s2.RoleId)
                               .Contains(s1.RoleId)

                         select s1;

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
