﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;
using System.Net.Http;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Users_ChangePwController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Post(Security_Users_ChangePw user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    int logonUserId = int.Parse(HttpContext.Current.Items["UserId"].ToString());
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    if(user.UserId != logonUserId)
                    {
                        throw new HttpResponseException(Request.CreateErrorResponse(System.Net.HttpStatusCode.BadRequest, "使用者驗證錯誤！"));
                    }

                    var users = db.auth_Users.Where(o => o.UserId == logonUserId);

                    if (users.Count() == 0)
                    {
                        return NotFound();
                    }
                    else if (users.First().Password != MetaEdge.Security.Cryptography.ToSHA512(user.OldPw))
                    {
                        //throw new Exception("原密碼輸入錯誤.");
                        throw new HttpResponseException(Request.CreateErrorResponse(System.Net.HttpStatusCode.BadRequest, "原密碼輸入錯誤！"));
                    }
                    else
                    {
                        auth_Users userData = users.First();
                        userData.Password = MetaEdge.Security.Cryptography.ToSHA512(user.NewPw);
                        userData.SignOnErrorCnt = 0;
                        userData.Suspended = false;
                        userData.LastPasswordChangedDate = DateTime.Now;
                        userData.Lst_Maint_Usr = logonUserCode;
                        userData.Lst_Maint_Dt = DateTime.Now;
                        db.Entry(userData).State = EntityState.Modified;
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return StatusCode(HttpStatusCode.NoContent);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool auth_UsersExists(int id)
        {
            return db.auth_Users.Count(e => e.UserId == id) > 0;
        }
    }
}
