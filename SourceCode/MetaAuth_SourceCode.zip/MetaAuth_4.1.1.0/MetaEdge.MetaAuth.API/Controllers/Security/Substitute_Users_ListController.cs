﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Substitute_Users_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        /// <summary>
        /// 使用者維護 - 查詢清單
        /// </summary>
        /// <param name="AppId">以應用程式Id來篩選，不輸入此值，會查詢所有的使用者</param>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Substitute_Users_List> Get()
        {
            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            
            // 篩選登入當下是否有設定代理其他人員
            var result = (from s1 in db.sys_Substitute

                          join s2 in db.auth_Affiliates
                           on s1.AffiliateId equals s2.AffiliateId

                         into subGrp1

                         join s3 in db.auth_Users
                           on s1.UserId equals s3.UserId

                         into subGrp2

                          join s4 in db.auth_Users
                            on s1.SubstituteUserId equals s4.UserId

                          into subGrp3

                          from affiliate in subGrp1.DefaultIfEmpty()
                         from user in subGrp2.DefaultIfEmpty()
                          from substitute in subGrp3.DefaultIfEmpty()

                          where substitute.UserCode == logonUserCode
                                && s1.Suspended != true
                                && DateTime.Today >= s1.StartTime.Value 
                                && DateTime.Today <= s1.EndTime.Value

                         select new
                         {
                             UserId = s1.UserId
                             ,
                             AffiliateId = s1.AffiliateId
                             ,
                             AffiliateCode = affiliate.AffiliateCode
                             ,
                             AffiliateName = affiliate.AffiliateName
                             ,
                             UserCode = user.UserCode
                             ,
                             UserName = user.UserName
                             ,                           
                             Email = user.Email
                             ,
                             Domain = user.Domain
                         }).Distinct();

            List<Substitute_Users_List> list = new List<Substitute_Users_List>();

            foreach (var user in result)
            {
                Substitute_Users_List detail = new Substitute_Users_List();
                detail.UserId = user.UserId;
                detail.AffiliateId = user.AffiliateId;
                detail.AffiliateCode = user.AffiliateCode;
                detail.AffiliateName = user.AffiliateName;
                detail.UserCode = user.UserCode;
                detail.UserName = user.UserName;
                detail.Email = user.Email;
                detail.Domain = user.Domain;

                detail = MetaEdge.Utility.DataValidator.ValidateEntity(detail);

                list.Add(detail);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
