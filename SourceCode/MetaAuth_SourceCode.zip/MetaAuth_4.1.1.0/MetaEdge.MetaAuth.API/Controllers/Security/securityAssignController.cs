﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaFiT.API.Controllers
{
    public class securityAssignController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // GET odata/auth_Users
        [Queryable]
        public IQueryable<securityAssign> Get(int roleId)
        {
            return db.usp_Web_securityAssign_Select_Result(roleId).AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
