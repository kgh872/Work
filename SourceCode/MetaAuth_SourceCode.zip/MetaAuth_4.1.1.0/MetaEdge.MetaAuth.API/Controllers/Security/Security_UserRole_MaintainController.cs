﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using System;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_UserRole_MaintainController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int UserId, Security_UserRole_Maintain list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            int logonUserId = int.Parse(HttpContext.Current.Items["UserId"].ToString());
            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    var users = db.auth_Users.Where(o => o.UserId == UserId);

                    if (users.Count() == 0)
                    {
                        return NotFound();
                    }

                    // 刪除使用者和角色的對應
                    // 因為 user1 可能有1個以上的應用程式的角色權限，但設定人員卻不一定相同的權限
                    // 所以只會刪除設定人員所可以編輯的應用程式權限
                    // 例如：設定人員有app1，user1有app1_role1、app1_role2、app2_role1、app1_role2，所以只會刪除user1的app1_role1、app1_role2
                    // ===================================================
                    var result = from s1 in db.auth_UserRole.Where(o => o.UserId == UserId)

                                 join s2 in db.auth_Roles
                                   on s1.RoleId equals s2.RoleId

                                 join s3 in db.auth_UserApplication.Where(o => o.UserId == logonUserId)
                                   on s2.AppId equals s3.AppId

                                 select s1;

                    db.auth_UserRole.RemoveRange(result);
                    // ===================================================

                    foreach (Security_UserRole_Maintain_Role role in list.Roles)
                    {
                        auth_UserRole ur = new auth_UserRole();
                        ur.UserId = list.UserId;
                        ur.RoleId = role.RoleId;
                        ur.Lst_Maint_Usr = logonUserCode;
                        ur.Lst_Maint_Dt = DateTime.Now;

                        ur = MetaEdge.Utility.DataValidator.ValidateEntity(ur);

                        db.auth_UserRole.Add(ur);
                    }

                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(list);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool auth_UsersExists(int id)
        {
            return db.auth_Users.Count(e => e.UserId == id) > 0;
        }
    }
}
