﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class Security_Users_ListController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        /// <summary>
        /// 使用者維護 - 查詢清單
        /// </summary>
        /// <param name="AppId">以應用程式Id來篩選，不輸入此值，會查詢所有的使用者</param>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Security_Users_List> Get([FromODataUri] int? AppId)
        {
            var result = (from s1 in db.auth_Users

                         join s2 in db.auth_Affiliates
                           on s1.AffiliateId equals s2.AffiliateId

                         into subGrp1

                         join s3 in db.auth_UserApplication
                           on s1.UserId equals s3.UserId

                         into subGrp2

                         from affiliate in subGrp1.DefaultIfEmpty()
                         from application in subGrp2.DefaultIfEmpty()

                         where application.AppId == AppId || AppId == null

                         select new
                         {
                             UserId = s1.UserId
                             ,
                             AffiliateId = s1.AffiliateId
                             ,
                             AffiliateCode = affiliate.AffiliateCode
                             ,
                             AffiliateName = affiliate.AffiliateName
                             ,
                             UserCode = s1.UserCode
                             ,
                             UserName = s1.UserName
                             ,
                             Password = s1.Password
                             ,
                             SignOnRetryLimit = s1.SignOnRetryLimit
                             ,
                             SignOnErrorCnt = s1.SignOnErrorCnt
                             ,
                             Suspended = s1.Suspended
                             ,
                             SuspendedDate = s1.SuspendedDate
                             ,
                             LastPasswordChangedDate = s1.LastPasswordChangedDate
                             ,
                             Email = s1.Email
                             ,
                             Comment = s1.Comment
                             ,
                             Domain = s1.Domain
                             ,
                             Lst_Maint_Usr = s1.Lst_Maint_Usr
                             ,
                             Lst_Maint_Dt = s1.Lst_Maint_Dt
                         }).Distinct();

            List<Security_Users_List> list = new List<Security_Users_List>();

            foreach (var user in result)
            {
                Security_Users_List detail = new Security_Users_List();
                detail.UserId = user.UserId;
                detail.AffiliateId = user.AffiliateId;
                detail.AffiliateCode = user.AffiliateCode;
                detail.AffiliateName = user.AffiliateName;
                detail.UserCode = user.UserCode;
                detail.UserName = user.UserName;
                detail.Password = user.Password;
                detail.SignOnRetryLimit = user.SignOnRetryLimit;
                detail.SignOnErrorCnt = user.SignOnErrorCnt;
                detail.Suspended = user.Suspended;
                detail.SuspendedDate = user.SuspendedDate;
                detail.LastPasswordChangedDate = user.LastPasswordChangedDate;
                detail.Email = user.Email;
                detail.Comment = user.Comment;
                detail.Domain = user.Domain;
                detail.Lst_Maint_Usr = user.Lst_Maint_Usr;
                detail.Lst_Maint_Dt = user.Lst_Maint_Dt;

                detail = MetaEdge.Utility.DataValidator.ValidateEntity(detail);

                list.Add(detail);
            }

            return list.AsQueryable();
        }

        /// <summary>
        /// 使用者維護 - 查詢清單
        /// </summary>
        /// <param name="AppId">以應用程式Id來篩選，不輸入此值，會查詢所有的使用者</param>
        /// <returns></returns>
        [Queryable]
        public IQueryable<Security_Users_List> Get([FromODataUri] int AppId, [FromODataUri] int RoleId)
        {
            var result = (from s1 in db.auth_Users
                          join s2 in db.auth_Affiliates
                            on s1.AffiliateId equals s2.AffiliateId
                          join s3 in db.auth_UserApplication
                            on s1.UserId equals s3.UserId
                          join s4 in db.auth_UserRole
                            on s1.UserId equals s4.UserId
                          where s3.AppId == AppId && s4.RoleId == RoleId

                          select new Security_Users_List
                          {
                              UserId = s1.UserId
                              ,
                              AffiliateId = s1.AffiliateId
                              ,
                              AffiliateCode = s2.AffiliateCode
                              ,
                              AffiliateName = s2.AffiliateName
                              ,
                              UserCode = s1.UserCode
                              ,
                              UserName = s1.UserName
                              ,
                              Password = s1.Password
                              ,
                              SignOnRetryLimit = s1.SignOnRetryLimit
                              ,
                              SignOnErrorCnt = s1.SignOnErrorCnt
                              ,
                              Suspended = s1.Suspended
                              ,
                              SuspendedDate = s1.SuspendedDate
                              ,
                              LastPasswordChangedDate = s1.LastPasswordChangedDate
                              ,
                              Email = s1.Email
                              ,
                              Comment = s1.Comment
                              ,
                              Domain = s1.Domain
                              ,
                              Lst_Maint_Usr = s1.Lst_Maint_Usr
                              ,
                              Lst_Maint_Dt = s1.Lst_Maint_Dt
                          }).Distinct();

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
