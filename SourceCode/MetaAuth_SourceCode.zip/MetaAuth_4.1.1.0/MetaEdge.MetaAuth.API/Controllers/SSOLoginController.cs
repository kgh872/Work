﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.OData;
//using LBOTSSO;

namespace MetaEdge.MetaAuth.API.Controllers
{
    
    public class SSOLoginController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<SSOResponse> Get()
        {
            List<SSOResponse> l = new List<SSOResponse>();
            SSOResponse loginInfo = new SSOResponse();
            loginInfo.loginStatus = true;
            loginInfo.loginMessage = "成功登入";

            loginInfo = MetaEdge.Utility.DataValidator.ValidateEntity(loginInfo);

            l.Add(loginInfo);
            return l.AsQueryable();
        }

        // POST api/securityPath
        public async Task<IHttpActionResult> Post(SSORequest ssoRequest)
        {
            //SSOClient sso = new SSOClient();

            //JObject otherInfo = JObject.Parse(ssoRequest.otherInfo);
            //JObject validateState = sso.Verify(ssoRequest.verifySite,ssoRequest.ssoToken,ssoRequest.userId,ssoRequest.pwd,otherInfo);
            await db.SaveChangesAsync();


            SSOResponse loginInfo = new SSOResponse();
            loginInfo.loginStatus = true;
            loginInfo.loginMessage = "成功登入";



            return Created(ssoRequest);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
