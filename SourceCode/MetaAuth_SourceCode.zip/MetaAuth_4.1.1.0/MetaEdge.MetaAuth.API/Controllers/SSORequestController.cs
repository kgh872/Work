﻿using Newtonsoft.Json.Linq;
using MetaEdge.Security.Data.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    
    public class SSORequestController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<SSOResponse> Get()
        {
            List<SSOResponse> response = new List<SSOResponse>();
            SSOResponse loginInfo = new SSOResponse();
            loginInfo.loginStatus = true;
            loginInfo.loginMessage = "成功登入";

            loginInfo = MetaEdge.Utility.DataValidator.ValidateEntity(loginInfo);

            response.Add(loginInfo);
            return response.AsQueryable();
        }

        [Queryable]
        public async Task<IHttpActionResult> Post(SSORequest ssoRequest)
        {
            SSOResponse loginInfo = new SSOResponse();
            try
            {
                //傳入的Jobject物件
                JObject otherInfo = JObject.Parse(ssoRequest.otherInfo);
                //SSOClient sso = new SSOClient();
                //JObject jsonInfo = sso.Verify("", "", ssoRequest.userId, ssoRequest.pwd, otherInfo);

                string ssoProvider = ConfigurationManager.AppSettings["SSOProvider"];
                ObjectHandle oh = Activator.CreateInstance(ssoProvider, ssoProvider + ".SSOClient");
                object inst = oh.Unwrap();
                Type type = inst.GetType();

                object[] args = new object[] { "", "", ssoRequest.userId, ssoRequest.pwd, otherInfo };

                JObject jsonInfo = (JObject)type.InvokeMember("Verify", BindingFlags.InvokeMethod, Type.DefaultBinder, inst, args);


                if (jsonInfo["loginStatus"].ToString().ToLower() == "false")
                {
                    loginInfo.loginStatus = false;
                    loginInfo.loginMessage = jsonInfo["loginMessage"].ToString();
                }
                else
                {
                    loginInfo.loginStatus = true;
                    loginInfo.loginMessage = jsonInfo["loginMessage"].ToString();
                }
            }
            catch (Exception ex)
            {
                loginInfo.loginStatus = false;
                loginInfo.loginMessage = ex.GetBaseException().Message;
            }
            return Created(loginInfo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
