﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class log_LogonController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // GET odata/log_Logon
        [Queryable]
        public IQueryable<log_Logon> Get()
        {
            return db.log_Logon;
        }

        // GET odata/log_Logon(5)
        [Queryable]
        public SingleResult<log_Logon> Get([FromODataUri] int id)
        {
            return SingleResult.Create(db.log_Logon.Where(log_logon => log_logon.ID == id));
        }

        // PUT odata/log_Logon(5)
        public async Task<IHttpActionResult> Put([FromODataUri] int id, log_Logon log_logon)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != log_logon.ID)
            {
                return BadRequest();
            }

            db.Entry(log_logon).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_LogonExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_logon);
        }

        // POST odata/log_Logon
        public async Task<IHttpActionResult> Post(log_Logon log_logon)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_logon = MetaEdge.Utility.DataValidator.ValidateEntity(log_logon);

            db.log_Logon.Add(log_logon);
            await db.SaveChangesAsync();

            return Created(log_logon);
        }

        // PATCH odata/log_Logon(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int id, Delta<log_Logon> patch)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_Logon log_logon = await db.log_Logon.FindAsync(id);
            if (log_logon == null)
            {
                return NotFound();
            }

            patch.Patch(log_logon);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_LogonExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_logon);
        }

        // DELETE odata/log_Logon(5)
        public async Task<IHttpActionResult> Delete([FromODataUri] int id)
        {
            log_Logon log_logon = await db.log_Logon.FindAsync(id);
            if (log_logon == null)
            {
                return NotFound();
            }

            db.log_Logon.Remove(log_logon);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool log_LogonExists(int id)
        {
            return db.log_Logon.Count(e => e.ID == id) > 0;
        }
    }
}
