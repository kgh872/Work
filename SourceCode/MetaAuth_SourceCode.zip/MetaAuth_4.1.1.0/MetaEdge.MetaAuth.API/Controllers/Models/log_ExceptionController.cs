﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class log_ExceptionController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // GET odata/log_Exception
        [Queryable]
        public IQueryable<log_Exception> Get()
        {
            return db.log_Exception;
        }

        // GET odata/log_Exception(5)
        [Queryable]
        public SingleResult<log_Exception> Get([FromODataUri] int id)
        {
            return SingleResult.Create(db.log_Exception.Where(log_Exception => log_Exception.ID == id));
        }

        // PUT odata/log_Exception(5)
        public async Task<IHttpActionResult> Put([FromODataUri] int id, log_Exception log_Exception)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != log_Exception.ID)
            {
                return BadRequest();
            }

            db.Entry(log_Exception).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_ExceptionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_Exception);
        }

        // POST odata/log_Exception
        public async Task<IHttpActionResult> Post(log_Exception log_Exception)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_Exception = MetaEdge.Utility.DataValidator.ValidateEntity(log_Exception);

            db.log_Exception.Add(log_Exception);
            await db.SaveChangesAsync();

            return Created(log_Exception);
        }

        // PATCH odata/log_Exception(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int id, Delta<log_Exception> patch)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_Exception log_Exception = await db.log_Exception.FindAsync(id);
            if (log_Exception == null)
            {
                return NotFound();
            }

            patch.Patch(log_Exception);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_ExceptionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_Exception);
        }

        // DELETE odata/log_Exception(5)
        public async Task<IHttpActionResult> Delete([FromODataUri] int id)
        {
            log_Exception log_Exception = await db.log_Exception.FindAsync(id);
            if (log_Exception == null)
            {
                return NotFound();
            }

            db.log_Exception.Remove(log_Exception);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool log_ExceptionExists(int id)
        {
            return db.log_Exception.Count(e => e.ID == id) > 0;
        }
    }
}
