﻿using MetaEdge.Security.Data.Models;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using System.Data.Entity.Infrastructure;
using System.Data.Entity;
using System.Threading.Tasks;
using MetaEdge.Security.Entity.Models;
using System.Net.Http;
using System.Net;
using System.Web;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class auth_ObjectsController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Objects> Get()
        {
            return db.auth_Objects;
        }

        [Queryable]
        public IQueryable<auth_Objects> Get([FromODataUri] int AppId)
        {
            return db.auth_Objects.Where(o => o.AppId == AppId);
        }

        public HttpResponseMessage Post(auth_Objects obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    obj.Parent = obj.Parent == null ? 0 : obj.Parent;
                    obj.Lst_Maint_Usr = logonUserCode;
                    obj.Lst_Maint_Dt = DateTime.Now;

                    obj = MetaEdge.Utility.DataValidator.ValidateEntity(obj);

                    db.auth_Objects.Add(obj);
                    db.SaveChanges();

                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, obj);

                    return response;
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
