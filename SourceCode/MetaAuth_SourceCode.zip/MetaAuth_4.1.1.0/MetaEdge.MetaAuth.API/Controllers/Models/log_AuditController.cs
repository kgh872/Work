﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class log_AuditController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<log_Audit> Get()
        {
            return db.log_Audit;
        }

        [Queryable]
        public SingleResult<log_Audit> Get([FromODataUri] int id)
        {
            return SingleResult.Create(db.log_Audit.Where(o => o.ID == id));
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int id, log_Audit logAudit)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != logAudit.ID)
            {
                return BadRequest();
            }

            db.Entry(logAudit).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_AuditExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(logAudit);
        }

        public async Task<IHttpActionResult> Post(log_Audit logAudit)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            SqlConnectionStringBuilder connBuilder = new SqlConnectionStringBuilder(db.Database.Connection.ConnectionString);
            logAudit.Target = logAudit.Target + ">>" + connBuilder.DataSource;
            logAudit.Account = logAudit.Account + ">>" + connBuilder.UserID;

            logAudit = MetaEdge.Utility.DataValidator.ValidateEntity(logAudit);

            db.log_Audit.Add(logAudit);
            await db.SaveChangesAsync();

            return Created(logAudit);
        }

        [AcceptVerbs("PATCH", "MERGE")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int id, Delta<log_Audit> patch)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_Audit logAudit = await db.log_Audit.FindAsync(id);
            if (logAudit == null)
            {
                return NotFound();
            }

            patch.Patch(logAudit);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_AuditExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(logAudit);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] int id)
        {
            log_Audit logAudit = await db.log_Audit.FindAsync(id);
            if (logAudit == null)
            {
                return NotFound();
            }

            db.log_Audit.Remove(logAudit);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool log_AuditExists(int id)
        {
            return db.log_Audit.Count(e => e.ID == id) > 0;
        }
    }
}
