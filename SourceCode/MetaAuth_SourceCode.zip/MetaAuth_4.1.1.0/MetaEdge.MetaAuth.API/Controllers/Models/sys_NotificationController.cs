﻿using MetaEdge.Security.Data.Models;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.Security.Entity.Models;
using System.Collections.Generic;
using System;
using System.Net.Http;
using System.Net;
using System.Data.Entity;
using System.Threading.Tasks;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class sys_NotificationController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IEnumerable<sys_Notification> Get()
        {
            using (var transaction = db.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                return db.sys_Notification;
            }
        }

        [Queryable]
        public IEnumerable<sys_Notification> Get([FromODataUri] int AppId)
        {
            using (var transaction = db.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
                return db.sys_Notification.Where(t => t.AppId == AppId && t.UserCode == logonUserCode);
            }
        }

        public HttpResponseMessage Post(sys_Notification notification)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    DateTime now = DateTime.Now;
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    notification.NotificationId = notification.NotificationId == null ? Guid.NewGuid().ToString() : notification.NotificationId;
                    notification.NotificationDateTime = notification.NotificationDateTime == null ? now : notification.NotificationDateTime;
                    notification.Lst_Maint_Usr = logonUserCode;
                    notification.Lst_Maint_Dt = now;

                    notification = MetaEdge.Utility.DataValidator.ValidateEntity(notification);
                    db.sys_Notification.Add(notification);
                    db.SaveChanges();

                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, notification);

                    return response;
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int AppId, [FromODataUri] string NotificationId, sys_Notification notification)
        {
            var decodeNotificationId = HttpUtility.UrlDecode(NotificationId);
            //if (!ModelState.IsValid || AppId != notification.AppId || decodeNotificationId != notification.NotificationId)
            //{
            //    return BadRequest(ModelState);
            //}

            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            notification.Lst_Maint_Usr = logonUserCode;
            notification.Lst_Maint_Dt = DateTime.Now;
            //notification.NotificationRead = "1";
            db.Entry(notification).State = EntityState.Modified;

            await db.SaveChangesAsync();

            return Created(notification);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] int appId)
        {
            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            var notifications = db.sys_Notification.Where(t => t.AppId == appId && t.UserCode == logonUserCode);
            if (notifications == null)
            {
                return NotFound();
            }

            List<sys_NotificationHistory> notificationHistories = new List<sys_NotificationHistory>();
            foreach (var notification in notifications)
            {
                notificationHistories.Add(MetaEdge.Utility.DataValidator.ValidateEntity(new sys_NotificationHistory()
                {
                    AppId = notification.AppId
                    ,
                    NotificationId = notification.NotificationId
                    ,
                    IconClass = notification.IconClass
                    ,
                    Title = notification.Title
                    ,
                    ObjectId = notification.ObjectId
                    ,
                    UserCode = notification.UserCode
                    ,
                    Parameter = notification.Parameter
                    ,
                    Count = notification.Count
                    ,
                    ContentText = notification.ContentText
                    ,
                    NotificationRead = notification.NotificationRead
                    ,
                    NotificationDateTime = notification.NotificationDateTime
                    ,
                    Lst_Maint_Usr = notification.Lst_Maint_Usr
                    ,
                    Lst_Maint_Dt = notification.Lst_Maint_Dt
                    ,
                    CreateUser = logonUserCode
                    ,
                    CreateDate = DateTime.Now
                }));
            }
            db.sys_NotificationHistory.AddRange(notificationHistories.ToArray());

            db.sys_Notification.RemoveRange(notifications);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] int appId, [FromODataUri] string NotificationId)
        {
            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            var notifications = db.sys_Notification.Where(t => t.AppId == appId && t.NotificationId == NotificationId && t.UserCode == logonUserCode);
            if (notifications == null)
            {
                return NotFound();
            }

            List<sys_NotificationHistory> notificationHistories = new List<sys_NotificationHistory>();
            foreach (var notification in notifications)
            {
                notificationHistories.Add(MetaEdge.Utility.DataValidator.ValidateEntity(new sys_NotificationHistory()
                {
                    AppId = notification.AppId
                    ,
                    NotificationId = notification.NotificationId
                    ,
                    IconClass = notification.IconClass
                    ,
                    Title = notification.Title
                    ,
                    ObjectId = notification.ObjectId
                    ,
                    UserCode = notification.UserCode
                    ,
                    Parameter = notification.Parameter
                    ,
                    Count = notification.Count
                    ,
                    ContentText = notification.ContentText
                    ,
                    NotificationRead = notification.NotificationRead
                    ,
                    NotificationDateTime = notification.NotificationDateTime
                    ,
                    Lst_Maint_Usr = notification.Lst_Maint_Usr
                    ,
                    Lst_Maint_Dt = notification.Lst_Maint_Dt
                    ,
                    CreateUser = logonUserCode
                    ,
                    CreateDate = DateTime.Now
                }));
            }
            db.sys_NotificationHistory.AddRange(notificationHistories.ToArray());

            db.sys_Notification.RemoveRange(notifications);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}