﻿using MetaEdge.Security.Data.Models;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.Security.Entity.Models;
using System.Collections.Generic;
using System;
using System.Net.Http;
using System.Net;
using System.Data.Entity;
using System.Threading.Tasks;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class sys_SubstituteController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IEnumerable<sys_Substitute> Get()
        {
            using (var transaction = db.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                return db.sys_Substitute;
            }
        }

        [Queryable]
        public IEnumerable<sys_Substitute> Get([FromODataUri] int substituteUserId)
        {
            // 篩選登入當下是否有設定代理其他人員
            using (var transaction = db.Database.BeginTransaction(System.Data.IsolationLevel.ReadUncommitted))
            {
                return db.sys_Substitute.Where(t=>t.SubstituteUserId == substituteUserId
                                            && t.Suspended != true
                                            && DateTime.Today >= t.StartTime.Value
                                            && DateTime.Today <= t.EndTime.Value
                                            );
            }
        }

        public HttpResponseMessage Post(sys_Substitute substitute)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    DateTime now = DateTime.Now;
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    substitute.Lst_Maint_Usr = logonUserCode;
                    substitute.Lst_Maint_Dt = now;

                    substitute = MetaEdge.Utility.DataValidator.ValidateEntity(substitute);

                    db.sys_Substitute.Add(substitute);
                    db.SaveChanges();

                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, substitute);

                    return response;
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int substituteId, sys_Substitute substitute)
        {
           
            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            substitute.Lst_Maint_Usr = logonUserCode;
            substitute.Lst_Maint_Dt = DateTime.Now;
            //notification.NotificationRead = "1";
            db.Entry(substitute).State = EntityState.Modified;

            await db.SaveChangesAsync();

            return Created(substitute);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] int substituteId)
        {
            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            var substitutes = db.sys_Substitute.Where(t => t.SubstituteId == substituteId);
            if (substitutes == null)
            {
                return NotFound();
            }

            List<sys_SubstituteHistory> substituteHistories = new List<sys_SubstituteHistory>();
            foreach (var substitute in substitutes)
            {
                substituteHistories.Add(MetaEdge.Utility.DataValidator.ValidateEntity(new sys_SubstituteHistory()
                {
                    SubstituteId = substitute.SubstituteId
                    ,
                    AffiliateId = substitute.AffiliateId
                    ,
                    UserId = substitute.UserId
                    ,
                    SubstituteUserId = substitute.SubstituteUserId
                    ,
                    StartTime = substitute.StartTime
                    ,
                    EndTime = substitute.EndTime
                    ,
                    Reason = substitute.Reason
                    ,
                    Suspended = substitute.Suspended
                    ,
                    Lst_Maint_Usr = substitute.Lst_Maint_Usr
                    ,
                    Lst_Maint_Dt = substitute.Lst_Maint_Dt
                }));
            }
            db.sys_SubstituteHistory.AddRange(substituteHistories.ToArray());

            db.sys_Substitute.RemoveRange(substitutes);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}