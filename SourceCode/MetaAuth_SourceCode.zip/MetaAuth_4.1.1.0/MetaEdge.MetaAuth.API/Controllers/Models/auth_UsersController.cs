﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class auth_UsersController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Users> Get()
        {
            return db.auth_Users;
        }

        [Queryable]
        public IQueryable<auth_Users> Get([FromODataUri] string UserCode)
        {
            return db.auth_Users.Where(t => t.UserCode == UserCode);
        }

        [Queryable]
        public IQueryable<auth_Users> Get([FromODataUri] int UserId)
        {
            return db.auth_Users.Where(o => o.UserId == UserId);
        }

        [Queryable]
        public IQueryable<auth_Users> Get([FromODataUri] int AppId, [FromODataUri] string UserCode)
        {
            var result = from s1 in db.auth_Users

                         where (from s2 in db.auth_UserApplication
                                where s2.AppId == AppId
                                select s2.UserId)
                               .Contains(s1.UserId)
                            && s1.UserCode == UserCode

                         select s1;

            return result;
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int UserId, auth_Users user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            //user.Lst_Maint_Usr = logonUserCode;
            user.Lst_Maint_Dt = DateTime.Now;
            db.Entry(user).State = EntityState.Modified;

            await db.SaveChangesAsync();

            return Created(user);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
