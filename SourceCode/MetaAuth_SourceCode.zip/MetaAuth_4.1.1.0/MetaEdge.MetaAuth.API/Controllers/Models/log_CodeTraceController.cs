﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class log_CodeTraceController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // GET odata/log_CodeTrace
        [Queryable]
        public IQueryable<log_CodeTrace> Getlog_CodeTrace()
        {
            return db.log_CodeTrace;
        }

        // GET odata/log_CodeTrace(5)
        [Queryable]
        public SingleResult<log_CodeTrace> Getlog_CodeTrace([FromODataUri] int id)
        {
            return SingleResult.Create(db.log_CodeTrace.Where(log_CodeTrace => log_CodeTrace.ID == id));
        }

        // PUT odata/log_CodeTrace(5)
        public async Task<IHttpActionResult> Put([FromODataUri] int id, log_CodeTrace log_CodeTrace)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != log_CodeTrace.ID)
            {
                return BadRequest();
            }

            db.Entry(log_CodeTrace).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_CodeTraceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_CodeTrace);
        }

        // POST odata/log_CodeTrace
        public async Task<IHttpActionResult> Post(log_CodeTrace log_CodeTrace)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_CodeTrace = MetaEdge.Utility.DataValidator.ValidateEntity(log_CodeTrace);

            db.log_CodeTrace.Add(log_CodeTrace);
            await db.SaveChangesAsync();

            return Created(log_CodeTrace);
        }

        // PATCH odata/log_CodeTrace(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int id, Delta<log_CodeTrace> patch)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_CodeTrace log_CodeTrace = await db.log_CodeTrace.FindAsync(id);
            if (log_CodeTrace == null)
            {
                return NotFound();
            }

            patch.Patch(log_CodeTrace);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_CodeTraceExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_CodeTrace);
        }

        // DELETE odata/log_CodeTrace(5)
        public async Task<IHttpActionResult> Delete([FromODataUri] int id)
        {
            log_CodeTrace log_CodeTrace = await db.log_CodeTrace.FindAsync(id);
            if (log_CodeTrace == null)
            {
                return NotFound();
            }

            db.log_CodeTrace.Remove(log_CodeTrace);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool log_CodeTraceExists(int id)
        {
            return db.log_CodeTrace.Count(e => e.ID == id) > 0;
        }
    }
}
