﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;
using System.Net.Http;
using System;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class auth_AffiliatesController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Affiliates> Get()
        {
            return db.auth_Affiliates;
        }

        public HttpResponseMessage Post(auth_Affiliates affiliate)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //auth_Affiliates checkParentAffiliate = affiliate;

                    //for (int i = 0; i <= 10; i++)
                    //{
                    //    if (i == 10) throw new Exception("上層組織設定錯誤,會導致組織階層錯誤");

                    //    var parent = db.auth_Affiliates.Where(o => o.Parent == checkParentAffiliate.AffiliateId);

                    //    if (parent.Count() == 0)
                    //    {
                    //        break;
                    //    }
                    //    else
                    //    {
                    //        if (parent.First().Parent == null || parent.First().Parent == 0)
                    //        {
                    //            break;
                    //        }
                    //        else
                    //        {
                    //            checkParentAffiliate = parent.First();
                    //        }
                    //    }
                    //}

                    CheckParent(affiliate.AffiliateId, affiliate);

                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
                    affiliate.Lst_Maint_Usr = logonUserCode;
                    affiliate.Lst_Maint_Dt = DateTime.Now;

                    affiliate = MetaEdge.Utility.DataValidator.ValidateEntity(affiliate);

                    db.auth_Affiliates.Add(affiliate);
                    db.SaveChanges();

                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, affiliate);

                    return response;
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int AffiliateId, auth_Affiliates affiliate)
        {
            if (!ModelState.IsValid || AffiliateId != affiliate.AffiliateId)
            {
                return BadRequest(ModelState);
            }

            //if (affiliate.AffiliateId == affiliate.Parent) throw new Exception("組織和上層組織不能相同");

            //auth_Affiliates checkParentAffiliate = affiliate;

            //for (int i = 0; i <= 10; i++)
            //{
            //    if (i == 10) throw new Exception("上層組織設定錯誤,會導致組織階層錯誤");

            //    var parent = db.auth_Affiliates.Where(o => o.AffiliateId == checkParentAffiliate.Parent);

            //    if (parent.Count() == 0)
            //    {
            //        break;
            //    }
            //    else
            //    {
            //        if (parent.First().Parent == null || parent.First().Parent == 0)
            //        {
            //            break;
            //        }
            //        else if (parent.First().Parent == affiliate.AffiliateId)
            //        {
            //            throw new Exception("上層組織設定錯誤,會導致組織階層錯誤");
            //        }
            //        else
            //        {
            //            checkParentAffiliate = parent.First();
            //        }
            //    }
            //}


            CheckParent(AffiliateId, affiliate);

            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            affiliate.Lst_Maint_Usr = logonUserCode;
            affiliate.Lst_Maint_Dt = DateTime.Now;
            db.Entry(affiliate).State = EntityState.Modified;

            await db.SaveChangesAsync();

            return Created(affiliate);
        }

        int currentLevel = 0;
        int maxLevel = 10;
        string levelTrace = string.Empty;
        protected int CheckParent(int origAffiliateId, auth_Affiliates affiliates)
        {
            //            if (maxLevel > 10) { return false; }
            if (currentLevel > maxLevel) { throw new Exception("上層組織設定錯誤,會導致組織階層錯誤"); }

            currentLevel += 1;

            levelTrace = string.Format(@"{0}\{1}-{2}", levelTrace, affiliates.AffiliateCode, affiliates.AffiliateName);

            if (affiliates.Parent == origAffiliateId)
            {
                //return false;
                throw new Exception(string.Format("組織和上層組織不能相同。階層: {0}", levelTrace));
            }

            var parent = db.auth_Affiliates.Where(o => o.AffiliateId == affiliates.Parent).FirstOrDefault();
            if (parent != null)
            {
                CheckParent(origAffiliateId, parent);
            }
            return currentLevel;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
