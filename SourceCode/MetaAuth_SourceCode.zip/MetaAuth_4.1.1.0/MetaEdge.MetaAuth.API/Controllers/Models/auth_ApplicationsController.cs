﻿using MetaEdge.Security.Data.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using System.Collections.Generic;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class auth_ApplicationsController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Applications> Get()
        {
            int userId = int.Parse(HttpContext.Current.Items["UserId"].ToString());

            var result = (from s1 in db.auth_Applications

                          join s2 in db.auth_UserApplication
                            on s1.AppId equals s2.AppId

                          where userId == 0 ? true : s2.UserId == userId

                          select s1).Distinct();

            return result;
        }

        [Queryable]
        public IQueryable<auth_Applications> Get([FromODataUri] int AppId)
        {
            return db.auth_Applications.Where(o => o.AppId == AppId);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
