﻿using MetaEdge.MetaAuthWeb.Data.Models;
using MetaEdge.MetaAuthWeb.Entity.Models;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class sys_ParametersController : ODataController
    {
        private MetaAuthWebContext db = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<sys_Parameters> Get()
        {
            return db.sys_Parameters;
        }

        [Queryable]
        public IQueryable<sys_Parameters> Get([FromODataUri] int? AppId)
        {
            return db.sys_Parameters.Where(o => o.AppId == AppId);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
