﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class auth_RolesController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IQueryable<auth_Roles> Get()
        {
            return db.auth_Roles;
        }

        public HttpResponseMessage Post(auth_Roles role)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());

                    role.Lst_Maint_Usr = logonUserCode;
                    role.Lst_Maint_Dt = DateTime.Now;

                    role = MetaEdge.Utility.DataValidator.ValidateEntity(role);

                    db.auth_Roles.Add(role);
                    db.SaveChanges();

                    HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.Created, role);

                    return response;
                }
                else
                {
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IHttpActionResult> Put([FromODataUri] int RoleId, auth_Roles role)
        {
            if (!ModelState.IsValid || RoleId != role.RoleId)
            {
                return BadRequest(ModelState);
            }

            string logonUserCode = MetaEdge.Utility.DataValidator.ValidateObject(HttpContext.Current.Items["UserCode"].ToString());
            role.Lst_Maint_Usr = logonUserCode;
            role.Lst_Maint_Dt = DateTime.Now;
            db.Entry(role).State = EntityState.Modified;

            await db.SaveChangesAsync();

            return Created(role);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
