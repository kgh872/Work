﻿using MetaEdge.Security.Data.Models;
using MetaEdge.Security.Entity.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class log_OperationController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // GET odata/log_Operation
        [Queryable]
        public IQueryable<log_Operation> Getlog_Operation()
        {
            return db.log_Operation;
        }

        // GET odata/log_Operation(5)
        [Queryable]
        public SingleResult<log_Operation> Getlog_Operation([FromODataUri] int id)
        {
            return SingleResult.Create(db.log_Operation.Where(log_operation => log_operation.ID == id));
        }

        // PUT odata/log_Operation(5)
        public async Task<IHttpActionResult> Put([FromODataUri] int id, log_Operation log_operation)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != log_operation.ID)
            {
                return BadRequest();
            }

            db.Entry(log_operation).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_OperationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_operation);
        }

        // POST odata/log_Operation
        public async Task<IHttpActionResult> Post(log_Operation log_operation)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_operation = MetaEdge.Utility.DataValidator.ValidateEntity(log_operation);
            db.log_Operation.Add(log_operation);
            await db.SaveChangesAsync();

            return Created(log_operation);
        }

        // PATCH odata/log_Operation(5)
        [AcceptVerbs("PATCH", "MERGE")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int id, Delta<log_Operation> patch)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            log_Operation log_operation = await db.log_Operation.FindAsync(id);
            if (log_operation == null)
            {
                return NotFound();
            }

            patch.Patch(log_operation);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!log_OperationExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(log_operation);
        }

        // DELETE odata/log_Operation(5)
        public async Task<IHttpActionResult> Delete([FromODataUri] int id)
        {
            log_Operation log_operation = await db.log_Operation.FindAsync(id);
            if (log_operation == null)
            {
                return NotFound();
            }

            db.log_Operation.Remove(log_operation);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool log_OperationExists(int id)
        {
            return db.log_Operation.Count(e => e.ID == id) > 0;
        }
    }
}
