﻿using Newtonsoft.Json;
using MetaEdge.Security.Data.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    /// <summary>
    /// 麵包屑導航（英語：Breadcrumb Trail）是在使用者介面中的一種導航輔助。它是用戶一個在程式或檔案中確定和轉移他們位置的一種方法。
    /// 麵包屑導航通常在頁面頂部水平出現，一般會位於標題或頁頭的下方。它們提供給用戶返回之前任何一個頁面的連結（這些連結也是能到達當前頁面的路徑），
    /// 在層級架構中通常是這個頁面的父級頁面。麵包屑導航提供給用戶回溯到網站首頁或入口頁面的一條路徑，通常是以大於號（>）出現，儘管一些設計是其他的符號（如>>）。
    /// 它們絕大部分看起來就像這樣：首頁>分類頁>次級分類頁 或者 首頁>>分類頁>>次級分類頁。
    /// </summary>
    public class BreadcrumbTrailController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        // GET api/BreadcrumbTrail
        [Queryable]
        public IQueryable<auth_Objects> Get([FromODataUri] int ObjectId)
        {
            #region Join Logic
            var resultSet = (from s1 in db.auth_Objects
                             select s1);
            #endregion

            int? parentid = ObjectId;

            List<auth_Objects> navagetePath = new List<auth_Objects>();

            while (parentid != 0)
            {
                #region CurrentItem

                var currentItem = from p in resultSet
                                  where p.ObjectId == parentid
                                  select p;

                if (currentItem.Count() == 0)
                {
                    break;
                }

                foreach (var item in currentItem)
                {
                    parentid = item.Parent;

                    auth_Objects ap = new auth_Objects();
                    ap.ObjectId = item.ObjectId;
                    ap.Parent = item.Parent;
                    ap.ObjectName = item.ObjectName;
                    ap.MenuPosition = item.MenuPosition;
                    ap.MenuText = item.MenuText;
                    ap.ToolTipText = item.ToolTipText;
                    ap.NavigateUrl = item.NavigateUrl;
                    ap.ReportUrl = item.ReportUrl;
                    ap.MenuClass = item.MenuClass;
                    ap.IconUrl = item.IconUrl;
                    ap.Suspended = item.Suspended;

                    ap = MetaEdge.Utility.DataValidator.ValidateEntity(ap);

                    navagetePath.Add(ap);
                }

                #endregion
            }

            List<auth_Objects> path = new List<auth_Objects>();
            int lv = 0;

            string navigatePath = string.Empty;

            foreach (auth_Objects menu in navagetePath.AsEnumerable().Reverse())
            {
                navigatePath += menu.MenuText + "  \\  ";

                //"PageLvl":"4",
                //MenuPosition
                menu.MenuPosition = lv;

                //"IsParent":"False"
                //bool Suspended
                menu.Suspended = !(lv == navagetePath.Count - 1);
                
                path.Add(MetaEdge.Utility.DataValidator.ValidateEntity(menu));
                lv++;
            }

            //把navigate字串串起來回傳
            navigatePath = navigatePath.TrimEnd(new char[] { ' ', '\\' });
            path = new List<auth_Objects>();
            path.Add(MetaEdge.Utility.DataValidator.ValidateEntity(new auth_Objects() { MenuText = navigatePath }));


            return path.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}