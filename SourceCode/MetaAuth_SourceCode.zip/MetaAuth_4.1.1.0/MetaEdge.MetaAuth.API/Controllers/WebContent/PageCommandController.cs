﻿using Newtonsoft.Json;
using MetaEdge.Security.Data.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.Security.Entity.Models;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class PageCommandController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IEnumerable<PageCommand> Get([FromODataUri] int ObjectId)
        {
            int userId = int.Parse(HttpContext.Current.Items["UserId"].ToString());

            var resultSet = (from s1 in db.auth_Objects
                            where s1.ObjectId == ObjectId

                            join s2 in db.auth_Permissions
                            on s1.ObjectId equals s2.ObjectId

                            join s3 in db.auth_RolePermission
                            on s2.PermissionId equals s3.PermissionId

                            join s4 in db.auth_UserRole
                            on s3.RoleId equals s4.RoleId

                            join s5 in db.auth_Operations
                            on s2.OperationId equals s5.OperationId

                            where s1.ObjectId == ObjectId
                               && s4.UserId == userId
                               && s5.Type != "page"

                            select s5).Distinct();

            List<PageCommand> list = new List<PageCommand>();
            var resultSet1 = resultSet.Where(o => o.Parent == 0 || o.Parent == null).OrderBy(o => o.Seq).AsQueryable();

            #region 產生第一層功能選單
            foreach (var item in resultSet1)
            {
                PageCommand page = new PageCommand();
                page.OperationId = item.OperationId;
                page.AppId = item.AppId;
                page.Parent = item.Parent;
                page.Seq = item.Seq;
                page.OperationCode = item.OperationCode;
                page.Type = item.Type;
                page.OperationName = item.OperationName;
                page.ToolTipText = item.ToolTipText;
                page.BtnClass = item.BtnClass;
                page.BtnColor = item.BtnColor;
                page.IconClass = item.IconClass;

                page.Detail = new List<PageCommandDetail>();

                page = MetaEdge.Utility.DataValidator.ValidateEntity(page);

                list.Add(page);
            }
            #endregion

            #region 產生子功能選單
            foreach (var item in list)
            {
                var resultSet2 = resultSet.Where(o => o.Parent == item.OperationId).OrderBy(o => o.Seq).AsQueryable();

                foreach (var item2 in resultSet2)
                {
                    PageCommandDetail detail = new PageCommandDetail();
                    detail.OperationId = item2.OperationId;
                    detail.AppId = item2.AppId;
                    detail.Parent = item2.Parent;
                    detail.Seq = item2.Seq;
                    detail.OperationCode = item2.OperationCode;
                    detail.Type = item2.Type;
                    detail.OperationName = item2.OperationName;
                    detail.ToolTipText = item.ToolTipText;
                    detail.BtnClass = item2.BtnClass;
                    detail.BtnColor = item2.BtnColor;
                    detail.IconClass = item2.IconClass;

                    detail = MetaEdge.Utility.DataValidator.ValidateEntity(detail);

                    item.Detail.Add(detail);
                }
            }
            #endregion

            return list.AsQueryable().OrderBy(t => t.Seq);
        }

        [Queryable]
        public IEnumerable<PageCommand> Get([FromODataUri] int AppId, [FromODataUri] string NavigateUrl)
        {
            int userId = int.Parse(HttpContext.Current.Items["UserId"].ToString());

            var resultSet = (from s1 in db.auth_Objects
                             where s1.AppId == AppId
                                && s1.NavigateUrl == NavigateUrl

                            join s2 in db.auth_Permissions
                            on s1.ObjectId equals s2.ObjectId

                            join s3 in db.auth_RolePermission
                            on s2.PermissionId equals s3.PermissionId

                            join s4 in db.auth_UserRole
                            on s3.RoleId equals s4.RoleId

                            join s5 in db.auth_Operations
                            on s2.OperationId equals s5.OperationId

                            where s1.NavigateUrl == NavigateUrl
                               && s4.UserId == userId
                               && s5.Type != "page"

                            select s5).Distinct();

            List<PageCommand> list = new List<PageCommand>();
            var resultSet1 = resultSet.Where(o => o.Parent == 0 || o.Parent == null).OrderBy(o => o.Seq).AsQueryable();

            #region 產生第一層功能選單
            foreach (var item in resultSet1)
            {
                PageCommand page = new PageCommand();
                page.OperationId = item.OperationId;
                page.AppId = item.AppId;
                page.Parent = item.Parent;
                page.Seq = item.Seq;
                page.OperationCode = item.OperationCode;
                page.Type = item.Type;
                page.OperationName = item.OperationName;
                page.BtnClass = item.BtnClass;
                page.BtnColor = item.BtnColor;
                page.IconClass = item.IconClass;

                page.Detail = new List<PageCommandDetail>();

                page = MetaEdge.Utility.DataValidator.ValidateEntity(page);

                list.Add(page);
            }
            #endregion

            #region 產生子功能選單
            foreach (var item in list)
            {
                var resultSet2 = resultSet.Where(o => o.Parent == item.OperationId).OrderBy(o => o.Seq).AsQueryable();

                foreach (var item2 in resultSet2)
                {
                    PageCommandDetail detail = new PageCommandDetail();
                    detail.OperationId = item2.OperationId;
                    detail.AppId = item2.AppId;
                    detail.Parent = item2.Parent;
                    detail.Seq = item2.Seq;
                    detail.OperationCode = item2.OperationCode;
                    detail.Type = item2.Type;
                    detail.OperationName = item2.OperationName;
                    detail.BtnClass = item2.BtnClass;
                    detail.BtnColor = item2.BtnColor;
                    detail.IconClass = item2.IconClass;

                    detail = MetaEdge.Utility.DataValidator.ValidateEntity(detail);

                    item.Detail.Add(detail);
                }
            }
            #endregion

            return list.AsQueryable().OrderBy(t => t.Seq);
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}