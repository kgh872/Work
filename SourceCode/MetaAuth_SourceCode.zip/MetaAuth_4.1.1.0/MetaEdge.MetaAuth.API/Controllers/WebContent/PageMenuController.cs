﻿using MetaEdge.Security.Data.Models;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.Security.Entity.Models;
using System.Collections.Generic;

namespace MetaEdge.MetaAuth.API.Controllers
{
    public class PageMenuController : ODataController
    {
        private MetaAuthContext db = new MetaAuthContext();

        [Queryable]
        public IEnumerable<auth_Objects> Get()
        {
            return db.auth_Objects;
        }

        [Queryable]
        public IEnumerable<auth_Objects> Get([FromODataUri] int AppId)
        {
            int userId = int.Parse(HttpContext.Current.Items["UserId"].ToString());

            var result = (from s1 in db.auth_Objects

                         join s2 in db.auth_Permissions
                           on s1.ObjectId equals s2.ObjectId

                         join s3 in db.auth_Operations
                           on s2.OperationId equals s3.OperationId

                         join s4 in db.auth_RolePermission
                           on s2.PermissionId equals s4.PermissionId

                         join s5 in db.auth_UserRole
                           on s4.RoleId equals s5.RoleId

                         where s1.AppId == AppId
                            && s1.MenuPosition > 0
                            && s1.Suspended != true
                            && s2.AppId == AppId
                            && s3.AppId == AppId
                            && s3.Type == "page"
                            && s5.UserId == userId

                         select s1).Distinct();

            return result;
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}