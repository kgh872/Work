﻿using MetaEdge.Data;
using MetaEdge.Security.Entity.Models;
using MetaEdge.Web;
using System;

namespace FormLoginProvider
{
    public class SSOClient : MetaEdge.Web.SSOProviderBase
    {
        public override SSOInfo Verify(SSOInfo jobject)
        {
            try
            {
                // 執行資料庫驗證
                auth_Users[] result = AuthApiHelper.Get<auth_Users>(string.Format("auth_Users(userCode='{0}')", jobject.UserCode));

                if (result.Length > 0)
                {
                    jobject.UserId = result[0].UserId;
                    jobject.UserCode = result[0].UserCode;
                    jobject.UserName = result[0].UserName;
                    jobject.AffiliateId = result[0].AffiliateId;

                    // 查看使用者有無應用程式權限
                    auth_UserApplication[] userApps = AuthApiHelper.Get<auth_UserApplication>(string.Format("auth_UserApplication?$filter=UserId eq {0}", jobject.UserId));
                    if (userApps.Length == 0)
                    {
                        jobject.Message = "使用者無登入系統權限.";
                    }
                    else if (result[0].Suspended == true)
                    {
                        jobject.Message = "此帳號已被停用.";
                    }
                    else if (result[0].SignOnRetryLimit != 0 && result[0].SignOnRetryLimit != null
                        && result[0].SignOnRetryLimit == result[0].SignOnErrorCnt)
                    {
                        jobject.Message = "登入失敗次數已達到限制,帳號已被鎖定.";
                    }
                    else if (result[0].Password == MetaEdge.Security.Cryptography.ToSHA512(jobject.UserPassw))
                    {
                        jobject.IsAuthenticated = true;

                        // 有設定「限制重登次數」的話，在成功登入後，「登入錯誤次數」會歸零
                        if (result[0].SignOnRetryLimit != null && result[0].SignOnRetryLimit != 0 && result[0].SignOnErrorCnt > 0)
                        {
                            result[0].SignOnErrorCnt = 0;
                            string jData = Newtonsoft.Json.JsonConvert.SerializeObject(result[0]);
                            AuthApiHelper.Put<auth_Users>(string.Format("auth_Users(userId={0})", result[0].UserId), jData);
                        }
                    }
                    else
                    {
                        jobject.Message = "帳號或密碼不正確.";

                        // 有設定「限制重登次數」的話，「登入錯誤次數」增加 1
                        if (result[0].SignOnRetryLimit != null && result[0].SignOnRetryLimit != 0)
                        {
                            if (result[0].SignOnErrorCnt == null)
                            {
                                result[0].SignOnErrorCnt = 1;
                            }
                            else
                            {
                                result[0].SignOnErrorCnt += 1;
                            }

                            string jData = Newtonsoft.Json.JsonConvert.SerializeObject(result[0]);
                            AuthApiHelper.Put<auth_Users>(string.Format("auth_Users(userId={0})", result[0].UserId), jData);
                        }
                    }
                }
                else
                {
                    jobject.Message = "系統查無此帳號.";
                }
            }
            catch (Exception ex)
            {
                jobject.IsAuthenticated = false;
                jobject.Message = ex.GetBaseException().Message;
            }

            return jobject;
        }
    }
}
