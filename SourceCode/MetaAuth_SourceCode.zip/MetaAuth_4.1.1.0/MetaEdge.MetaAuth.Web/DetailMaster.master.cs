using System;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class DetailMaster : MetaEdge.Web.BaseMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterHiddenField("CanChanagePwd", MetaEdge.Registry.AppSettingsFactory.Get("CanChanagePwd"));

        }
    }
}