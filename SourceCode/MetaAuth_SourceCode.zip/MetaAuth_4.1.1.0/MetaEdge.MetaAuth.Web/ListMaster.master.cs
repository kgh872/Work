using System;


namespace MetaEdge.MetaAuth.WebUI
{
    public partial class ListMaster : MetaEdge.Web.BaseMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}