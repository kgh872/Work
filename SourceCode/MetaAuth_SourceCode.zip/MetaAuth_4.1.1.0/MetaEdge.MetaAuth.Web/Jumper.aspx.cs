﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using MetaEdge.Security.Entity.Models;
using MetaEdge.Data;
using System.IO;
using MetaEdge.Web;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class Jumper : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            checkUrlReferrer(MetaEdge.Registry.AppSettingsFactory.Get("WEBURL"), "~/Error.html");

            // 使用者直接連結其他系統，如 http://localhost/MetaFiT4 ，若沒有登入的狀態，則會被導至 http://localhost/MetaAuth/login.aspx
            // 若已有登入MetaAuth，便直接導向並登入MetaFiT4 
            if (!string.IsNullOrEmpty(Request.QueryString["toApp"]))
            {
                auth_Applications[] apps = AuthApiHelper.Get<auth_Applications>(string.Format("auth_Applications?$filter=AppId eq {0}", Request.QueryString["toApp"]));
                if (apps.Length > 0)
                {
                    if (MetaEdge.Registry.AppSettingsFactory.Get("APPID") == Request.QueryString["toApp"])
                    {
                        string url = string.Format(apps[0].DefaultUrl);
                        Response.Redirect(url);
                    }
                    else
                    {
                        // 產生 Token
                        // =========================================
                        string token = Guid.NewGuid().ToString();
                        sys_SSOToken ssoTaken = new sys_SSOToken();
                        ssoTaken.Token = token;

                        UserInfo userInfo = new UserInfo();
                        ssoTaken.UserId = userInfo.UserId;
                        ssoTaken.CreateDate = DateTime.Now;

                        string jData = Newtonsoft.Json.JsonConvert.SerializeObject(ssoTaken);
                        AuthApiHelper.Post<sys_SSOToken>("sys_SSOToken", jData);
                        // =========================================

                        // 將 token 一起導向其他系統
                        // =========================================
                        string url = string.Format("{0}?token={1}", apps[0].LoginUrl, token);
                        Response.Redirect(url);
                        // =========================================
                    }
                }
            }

            Response.Redirect(FormsAuthentication.DefaultUrl);
        }

        /// <summary>
        /// 驗證 "Referer" 標頭的值
        /// </summary>
        /// <param name="webUrl"></param>
        /// <param name="errUrl"></param>
        protected void checkUrlReferrer(string webUrl, string errUrl)
        {
            bool isValid = false;

            Uri referrer = HttpContext.Current.Request.UrlReferrer;
            if (referrer != null)
            {
                isValid = HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(webUrl) > -1;

                if (isValid == false)
                {
                    // 在畫面的左上角切換系統，UrlReferrer會是其他的Application
                    auth_Applications[] apps = AuthApiHelper.Get<auth_Applications>(string.Format("auth_Applications?$filter=AppShortName eq '{0}'", HttpContext.Current.Request.UrlReferrer.Segments[1].Replace("/", "")));
                    if (apps.Length > 0)
                    {
                        isValid = true;
                    }
                }
            }
            else
            {
                isValid = true;
            }

            if (!isValid)
            {
                Response.Redirect(errUrl);
            }
        }
    }
}