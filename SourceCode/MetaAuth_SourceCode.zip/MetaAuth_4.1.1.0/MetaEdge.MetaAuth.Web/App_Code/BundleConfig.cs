﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;

/// <summary>
/// BundleConfig 的摘要描述
/// </summary>
public class BundleConfig
{
    public static void RegisterBundles(BundleCollection bundles)
    {
        BundleTable.EnableOptimizations = true;

        // bundling script.
        bundles.Add(
            new ScriptBundle("~/bundles/scripts/jQuery")
            .Include(
                "~/Scripts/jQuery/ajaxfileupload.js",
                "~/Scripts/jQuery/datepicker-zh-TW.js",
                "~/Scripts/jQuery/jquery.js",
                "~/Scripts/jQuery/jquery-migrate.js",
                "~/Scripts/jQuery/jquery-confirm.min.js",
                "~/Scripts/jQuery/jquery-sortable-lists.js",
                "~/Scripts/jQuery/jquery-style.js",
                "~/Scripts/jQuery/jquery-ui.min.js",
                "~/Scripts/jQuery/jquery.layout-latest.js",
                "~/Scripts/jQuery/jquery.steps.js",
                "~/Scripts/jQuery/jQuery.support.transition.js",
                "~/Scripts/jQuery/json2.js"
            ));

        bundles.Add(
            new ScriptBundle("~/bundles/scripts/metaedge")
            .Include(
                "~/Scripts/metaedge.ajaxErrorHandle.js",
                "~/Scripts/metaedge.common.js",
                "~/Scripts/metaedge.extend.js",
                "~/Scripts/metaedge.gridVM.js",
                "~/Scripts/metaedge.gvFunctions.js",
                "~/Scripts/metaedge.IE8fix.js",
                "~/Scripts/metaedge.UrlFactory.js"
            ));

        
        //// bundling styles.
        //bundles.Add(
        //    new StyleBundle("~/bundles/styles")
        //    .Include(
        //        "~/Styles/Style1.css",
        //        "~/Styles/Style2.css",
        //        "~/Styles/Style3.css",
        //        "~/Styles/Style4.css"
        //    ));
    }
}