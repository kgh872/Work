﻿using Newtonsoft.Json.Linq;
using SpreadsheetGear;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

/// <summary>
/// ExcelHelper 的摘要描述
/// </summary>

public class ExcelHelper
{

    //public static byte[] GetExportExcel<T>(string SheetName, string[] TitleNames, double[] ColumnsWidth, string[] ColumnsName, T[] datas)
    //{
    //    IWorkbook Sp_Workbook = Factory.GetWorkbook();
    //    IWorksheet Sp_Worksheet;

    //    //新增頁籤
    //    Sp_Worksheet = Sp_Workbook.Worksheets.AddBefore(Sp_Workbook.Worksheets[0]);

    //    //頁籤名稱
    //    Sp_Worksheet.Name = SheetName;

    //    //標題
    //    for (int i = 0; i < TitleNames.Length; i++)
    //    {
    //        Sp_Worksheet.Cells[0, i].Value = TitleNames[i];

    //        //設定標題置中
    //        Sp_Worksheet.Cells[0, i].HorizontalAlignment = HAlign.Center;
    //        Sp_Worksheet.Cells[0, i].VerticalAlignment = SpreadsheetGear.VAlign.Center; 

    //        // 粗體
    //        Sp_Worksheet.Cells[0, i].Font.Bold = true; 

    //        //設定底色
    //        Sp_Worksheet.Cells[0, i].Interior.Color = SpreadsheetGear.Drawing.Color.FromArgb(82, 82, 82);

    //        // Font Color
    //        Sp_Worksheet.Cells[0, i].Font.Color = SpreadsheetGear.Drawing.Color.FromArgb(255, 255, 255); // Font Color

    //        //設定欄位寬度
    //        if (ColumnsWidth[i] > 0)
    //        {
    //            Sp_Worksheet.Cells[0, i].ColumnWidth = ColumnsWidth[i];
    //        }
    //        else
    //        {
    //            //依內容自動設定
    //            Sp_Worksheet.Cells[0, i].Columns.AutoFit();
    //        }
    //    }

    //    //寫入明細資料
    //    Type entityType = typeof(T);
    //    PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);
    //    int dataLength = datas.Length;
    //    string endColumn = Convert.ToChar('A' + ColumnsName.Count() - 1).ToString();
    //    for (int row, i = 0; i < dataLength; i++)
    //    {
    //        row = i + 1;
    //        for (int j = 0; j < ColumnsName.Length; j++)
    //        {
    //            PropertyDescriptor prop = properties[ColumnsName[j]];
    //            if (prop.PropertyType == typeof(string))
    //            {
    //                Sp_Worksheet.Cells[row, j].NumberFormat = "@";
    //            }

    //            Sp_Worksheet.Cells[row, j].Value = prop.GetValue(datas[i]);                 
    //        }

    //        string rowRange = string.Format("A{1}:{0}{1}", endColumn, row+1);

    //        //自動換列
    //        Sp_Worksheet.Cells[rowRange].WrapText = true;

    //        //靠上對齊
    //        Sp_Worksheet.Cells[rowRange].VerticalAlignment = VAlign.Top;

    //        if (row % 2 == 0)
    //        {
    //            // 資料行背景顏色
    //            Sp_Worksheet.Cells[rowRange].Interior.Color = SpreadsheetGear.Drawing.Color.FromArgb(237, 237, 237); 
    //        }
    //    }

    //    // 內容格式設置
    //    string contentRange = string.Format("A1:{0}{1}", endColumn, (dataLength + 1));
    //    SpreadsheetGear.IRange grandTotalCells = Sp_Worksheet.Cells[contentRange];
    //    grandTotalCells.Borders.LineStyle = SpreadsheetGear.LineStyle.Continous; // 儲存格格線

    //    byte[] exportResult = Sp_Worksheet.SaveToMemory(SpreadsheetGear.FileFormat.Excel8);
    //    return exportResult;
    //}

    public static byte[] GetExportExcel(string SheetName, string[] TitleNames, double[] ColumnsWidth, string[] ColumnsNames, JObject[] datas)
    {
        IWorkbook Sp_Workbook = Factory.GetWorkbook();
        IWorksheet Sp_Worksheet;

        //新增頁籤
        Sp_Worksheet = Sp_Workbook.Worksheets.AddBefore(Sp_Workbook.Worksheets[0]);

        //頁籤名稱
        Sp_Worksheet.Name = SheetName;

        //標題
        for (int i = 0; i < TitleNames.Length; i++)
        {
            Sp_Worksheet.Cells[0, i].Value = TitleNames[i];

            //設定標題置中
            Sp_Worksheet.Cells[0, i].HorizontalAlignment = HAlign.Center;
            Sp_Worksheet.Cells[0, i].VerticalAlignment = SpreadsheetGear.VAlign.Center;

            // 粗體
            Sp_Worksheet.Cells[0, i].Font.Bold = true;

            //設定底色
            Sp_Worksheet.Cells[0, i].Interior.Color = SpreadsheetGear.Drawing.Color.FromArgb(82, 82, 82);

            // Font Color
            Sp_Worksheet.Cells[0, i].Font.Color = SpreadsheetGear.Drawing.Color.FromArgb(255, 255, 255); // Font Color

            //設定欄位寬度
            if (ColumnsWidth != null && ColumnsWidth.Length > i && ColumnsWidth[i] > 0)
            {
                Sp_Worksheet.Cells[0, i].ColumnWidth = ColumnsWidth[i];
            }
            else
            {
                //依內容自動設定
                Sp_Worksheet.Cells[0, i].Columns.AutoFit();
            }
        }

        //寫入明細資料
        int dataLength = datas.Length;
        string endColumn = ToExcelColumn(ColumnsNames.Count());
        for (int row, i = 0; i < dataLength; i++)
        {
            row = i + 1;
            for (int j = 0; j < ColumnsNames.Length; j++)
            {
                //PropertyDescriptor prop = properties[ColumnsName[j]];
                var tmpData = datas[i][ColumnsNames[j]];
                if (tmpData.Type == JTokenType.String)
                {
                    Sp_Worksheet.Cells[row, j].NumberFormat = "@";
                    Sp_Worksheet.Cells[row, j].Value = tmpData.ToString();
                }
                if (tmpData.Type == JTokenType.Date)
                {
                    Sp_Worksheet.Cells[row, j].Value = tmpData.ToObject<DateTime>();
                }
                else
                {
                    Sp_Worksheet.Cells[row, j].Value = tmpData.ToString();
                }
            }

            string rowRange = string.Format("A{1}:{0}{1}", endColumn, row + 1);

            //自動換列
            Sp_Worksheet.Cells[rowRange].WrapText = true;

            //靠上對齊
            Sp_Worksheet.Cells[rowRange].VerticalAlignment = VAlign.Top;

            if (row % 2 == 0)
            {
                // 資料行背景顏色
                Sp_Worksheet.Cells[rowRange].Interior.Color = SpreadsheetGear.Drawing.Color.FromArgb(237, 237, 237);
            }
        }

        // 內容格式設置
        string contentRange = string.Format("A1:{0}{1}", endColumn, (dataLength + 1));
        SpreadsheetGear.IRange grandTotalCells = Sp_Worksheet.Cells[contentRange];
        grandTotalCells.Borders.LineStyle = SpreadsheetGear.LineStyle.Continous; // 儲存格格線

        byte[] exportResult = Sp_Worksheet.SaveToMemory(SpreadsheetGear.FileFormat.Excel8);
        return exportResult;
    }

    private const string ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    public static string ToExcelColumn(int columnIndex)
    {
        string str = string.Empty;
        while (columnIndex > 0)
        {
            str = ALPHABET[(columnIndex - 1) % 26] + str;
            columnIndex /= 26;
        }

        return str;
    }

    public static string ToExcelCoordinates(string coordinates)
    {
        string first = coordinates.Substring(0, coordinates.IndexOf(','));
        int i = int.Parse(first);
        string second = coordinates.Substring(first.Length + 1);

        string str = string.Empty;
        while (i > 0)
        {
            str = ALPHABET[(i - 1) % 26] + str;
            i /= 26;
        }

        return str + second;
    }

    public static string ToNumericCoordinates(string coordinates)
    {
        string first = string.Empty;
        string second = string.Empty;

        CharEnumerator ce = coordinates.GetEnumerator();
        while (ce.MoveNext())
            if (char.IsLetter(ce.Current))
                first += ce.Current;
            else
                second += ce.Current;

        int i = 0;
        ce = first.GetEnumerator();
        while (ce.MoveNext())
            i = (26 * i) + ALPHABET.IndexOf(ce.Current) + 1;

        string str = i.ToString();
        return str + "," + second;
    }
}
