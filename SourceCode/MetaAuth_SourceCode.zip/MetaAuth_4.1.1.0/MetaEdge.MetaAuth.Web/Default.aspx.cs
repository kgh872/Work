﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class Default : MetaEdge.Web.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            base.checkUrlReferrer(MetaEdge.Registry.AppSettingsFactory.Get("WEBURL"), "~/Error.html");
        }
    }
}