using System;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class EmptyMaster : MetaEdge.Web.BaseMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            base.registerJSFile("~/Scripts/jQuery/jquery-ui.min.js", "jqueryUI", Page);
            base.registerJSFile("~/Scripts/jQuery/jquery.layout-latest.js", "jqueryLatest", Page);
            base.registerJSFile("~/Scripts/jQuery/ajaxfileupload.js", "ajaxfileupload", Page);
            base.registerJSFile("~/Scripts/Bootstrap/bootstrap.min.js", "bootStrap", Page);
            base.registerJSFile("~/Scripts/Knockout/knockout-3.5.1.js", "knouckout", Page);
            base.registerJSFile("~/Scripts/Knockout/bindingHandlers.js", "knockoutBind", Page);
            base.registerJSFile("~/Scripts/moment.min.js", "moment", Page);
            base.registerJSFile("~/Scripts/Knockout/knockout.mapping.js", "knockout.mapping", Page);
            base.registerJSFile("~/Scripts/metaedge.UrlFactory.js", "metaedge.UrlFactory", Page);
            base.registerJSFile("~/Scripts/metaedge.gridVM.js", "metaedge.gridVM", Page);

            base.registerJSFile("~/Scripts/metaedge.ajaxErrorHandle.js", "metaedge.ajaxErrorHandle", Page);

            base.registerJSFile("~/Scripts/Validation-Engine/languages/jquery.validationEngine-zh_TW.js", "jquery.validationEngine-zh_TW", Page);
            base.registerJSFile("~/Scripts/Validation-Engine/jquery.validationEngine.js", "jquery.validationEngine", Page);

            if (IEVersion == browserType.IE6 || IEVersion == browserType.IE7 || IEVersion == browserType.IE8)
            {
                registerJSFile("~/Scripts/metaedge.IE8fix.js", "IE8fix", Page);
            }
        }
    }
}