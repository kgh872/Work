﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using MetaEdge.Security.Entity.Models;
using MetaEdge.Data;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            checkUrlReferrer(MetaEdge.Registry.AppSettingsFactory.Get("WEBURL"), "~/Error.html");

            MetaEdge.Data.LogHelper.UpdateLogonLog();

            HttpContext.Current.Session.RemoveAll();
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            FormsAuthentication.SignOut();

            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, "");
            cookie.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie);

            HttpCookie cookie2 = new HttpCookie("ASP.NET_SessionId", "");
            cookie2.Expires = DateTime.Now.AddYears(-1);
            Response.Cookies.Add(cookie2);

            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Request.Cookies.Clear();

            //FormsAuthentication.RedirectToLoginPage();

            auth_Applications[] app = MetaEdge.Data.AuthApiHelper.Get<auth_Applications>(string.Format("auth_Applications(AppId={0})", MetaEdge.Registry.AppSettingsFactory.Get("APPID")));
            string logoutUrl = string.Empty;

            if (app.Length > 0)
            {
                logoutUrl = app[0].LogoutUrl;
            }

            ExpireAllCookies();

            if (!string.IsNullOrEmpty(logoutUrl))
            {
                Response.Redirect(logoutUrl);
            }
            else
            {
                // 無設定 LogoutUrl，直接關閉視窗
                Response.Write("<script>window.opener=null;var win = window.open('','_self'); win.close();</script>");
            }
        }

        /// <summary>
        /// 驗證 "Referer" 標頭的值
        /// </summary>
        /// <param name="webUrl"></param>
        /// <param name="errUrl"></param>
        protected void checkUrlReferrer(string webUrl, string errUrl)
        {
            bool isValid = false;

            Uri referrer = HttpContext.Current.Request.UrlReferrer;
            if (referrer != null)
            {
                isValid = HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(webUrl) > -1;

                if (isValid == false)
                {
                    // 在畫面的左上角切換系統，UrlReferrer會是其他的Application
                    auth_Applications[] apps = AuthApiHelper.Get<auth_Applications>(string.Format("auth_Applications?$filter=AppShortName eq '{0}'", HttpContext.Current.Request.UrlReferrer.Segments[1].Replace("/", "")));
                    if (apps.Length > 0)
                    {
                        isValid = true;
                    }
                }
            }
            else
            {
                isValid = true;
            }

            if (!isValid)
            {
                Response.Redirect(errUrl);
            }
        }

        private void ExpireAllCookies()
        {
            if (HttpContext.Current != null)
            {
                int cookieCount = HttpContext.Current.Request.Cookies.Count;
                for (var i = 0; i < cookieCount; i++)
                {
                    var cookie = HttpContext.Current.Request.Cookies[i];
                    if (cookie != null)
                    {
                        var expiredCookie = new HttpCookie(cookie.Name)
                        {
                            Expires = DateTime.Now.AddDays(-1),
                            Domain = cookie.Domain
                        };
                        HttpContext.Current.Response.Cookies.Add(expiredCookie); // overwrite it
                    }
                }

                // clear cookies server side
                HttpContext.Current.Request.Cookies.Clear();
            }

            string appguid = System.Web.Configuration.WebConfigurationManager.AppSettings["AppCookieGUID"];

            var expiredCookieMetaEdge = new HttpCookie("MetaEdge" + appguid)
            {
                Expires = DateTime.Now.AddDays(-1),
                //Domain = cookie.Domain
            };
            HttpContext.Current.Response.Cookies.Add(expiredCookieMetaEdge); // overwrite it

            var expiredCookieMetaEdgeSubstitute = new HttpCookie("MetaEdge-Substitute" + appguid)
            {
                Expires = DateTime.Now.AddDays(-1),
                //Domain = cookie.Domain
            };
            HttpContext.Current.Response.Cookies.Add(expiredCookieMetaEdgeSubstitute); // overwrite it

        }
    }
}
