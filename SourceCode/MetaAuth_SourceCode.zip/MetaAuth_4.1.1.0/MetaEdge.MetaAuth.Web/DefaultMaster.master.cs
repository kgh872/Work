using System;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class DefaultMaster : MetaEdge.Web.BaseMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterHiddenField("CanChanagePwd", MetaEdge.Registry.AppSettingsFactory.Get("CanChanagePwd"));
            Page.ClientScript.RegisterHiddenField("PwdChangeMaxDay", MetaEdge.Registry.AppSettingsFactory.Get("PwdChangeMaxDay"));
            SetCookieTimeout();
        }

        private void SetCookieTimeout()
        {
            hfSessionTimeoutTotalMinutes.Value = (GetFormsAuthenticationTimeout() * 60).ToString();
        }

        /// <summary>
        /// ���oweb.config FormsAuthenticationConfiguration Timeout���ɶ�
        /// </summary>
        /// <returns></returns>
        private double GetFormsAuthenticationTimeout()  
        {
            // Get the Web application configuration.
            System.Configuration.Configuration configuration =
                WebConfigurationManager.OpenWebConfiguration("~");

            // Get the external Authentication section.
            AuthenticationSection authenticationSection =
                (AuthenticationSection)configuration.GetSection(
                "system.web/authentication");

            // Get the external Forms section .
            FormsAuthenticationConfiguration formsAuthentication =
                authenticationSection.Forms;

            // avoid cookie timeout
            return formsAuthentication.Timeout.TotalMinutes;
        }
    }
}