﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using MetaEdge.Security.Entity.Models;
using MetaEdge.Data;
using MetaEdge.Web;
using System.Runtime.Remoting;
using Newtonsoft.Json;
using System.Reflection;
using System.Web.Security.AntiXss;

namespace MetaEdge.MetaAuth.WebUI
{
    public partial class login : System.Web.UI.Page
    {
        string appId = string.Empty;
        string token = string.Empty;
        string metaedge_ssoticket = string.Empty;
        string toApp = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            appId = AntiXssEncoder.HtmlEncode(MetaEdge.Registry.AppSettingsFactory.Get("APPID"), false);
            token = AntiXssEncoder.HtmlEncode(Request.QueryString["Token"], false);
            metaedge_ssoticket = AntiXssEncoder.HtmlEncode(Request.Form["METAEDGE_SSOTICKET"], false);
            toApp = AntiXssEncoder.HtmlEncode(Request.QueryString["toApp"], false);

            if (metaedge_ssoticket != null)
            {
                //KGI SSO Login
                LoginUser("", false);
            }
            else if (User.Identity.IsAuthenticated)
            {
                if (!string.IsNullOrEmpty(toApp))
                {
                    Response.Redirect("Jumper.aspx?toApp=" + toApp);
                }

                auth_Applications[] apps = AuthApiHelper.Get<auth_Applications>(string.Format("auth_Applications?$filter=AppId eq {0}", appId));

                if (apps.Length > 0)
                {
                    //Response.Redirect(apps[0].DefaultUrl);
                    LoginUser(User.Identity.Name, true);
                }
                else
                {
                    Response.Redirect(FormsAuthentication.DefaultUrl);
                }
            }
            else if (!string.IsNullOrEmpty(token))
            {
                // 查詢此 tokenId 是否存在，並且是在5分鐘內建立的
                sys_SSOToken[] result = AuthApiHelper.Get<sys_SSOToken>(string.Format("sys_SSOToken?$filter=Token eq '{0}'", token));

                if (result.Length > 0)
                {
                    if (result[0].CreateDate >= DateTime.Now.AddMinutes(-5))
                    {
                        // 查詢此 UserId 是否有使用此應用程式的權限
                        auth_UserApplication[] ua = AuthApiHelper.Get<auth_UserApplication>(string.Format("auth_UserApplication?$filter=UserId eq {0} and AppId eq {1}", result[0].UserId, appId));
                        if (ua.Length > 0)
                        {
                            // 取得使用者的資料
                            auth_Users[] users = AuthApiHelper.Get<auth_Users>(string.Format("auth_Users?$filter=UserId eq {0}", result[0].UserId));
                            if (users.Length > 0)
                            {
                                LoginUser(users[0].UserCode, true);
                            }
                        }
                        else
                        {
                            string NoPermissionScript = "<script type='text/javascript'>alert('無使用系統之權限!'); window.close();</script>";
                            ClientScript.RegisterClientScriptBlock(Page.GetType(), "NoPermissionScript", NoPermissionScript);
                        }
                    }
                    else
                    {
                        string JumperTimeoutScript = "<script type='text/javascript'>alert('應用程式移轉逾時,請再重試一次'); window.close();</script>";
                        ClientScript.RegisterClientScriptBlock(Page.GetType(), "JumperTimeoutScript", JumperTimeoutScript);
                    }
                }
            }
            else
            {
                //lblMessage.Text = "無SSO TICKET，請進行手動登入。";
            }

            // 取得版本資訊
            // ===========================================
            lblVersion.Text = Application["MetaFiT_Version"].ToString();
            // ===========================================
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            LoginUser(this.txtUserName.Text, false);
        }

        protected void LoginUser(string userCode, bool hasToken)
        {
            lblMessage.Text = string.Empty;
            bool islogin = false;

            UserInfo userInfo = new UserInfo();
            userInfo.UserCode = AntiXssEncoder.HtmlEncode(userCode, false);
            string appId = MetaEdge.Registry.AppSettingsFactory.Get("APPID");
            string passw = HttpUtility.UrlDecode(this.txtPassw.Text);

            try
            {

                SSOInfo ssoInfo = new SSOInfo();
                ssoInfo.UserCode = userCode;
                ssoInfo.UserPassw = passw;

                string ssoAssemblyName = string.Empty;
                string ssoTypeName = string.Empty;
                if (hasToken == false)
                {
                    // 建立 SSO 執行個體
                    // =====================================================
                    ssoAssemblyName = MetaEdge.Registry.AppSettingsFactory.Get("SSOAssemblyName");
                    ssoTypeName = MetaEdge.Registry.AppSettingsFactory.Get("SSOTypeName");
                    ObjectHandle oh = Activator.CreateInstance(ssoAssemblyName, ssoTypeName);
                    object inst = oh.Unwrap();
                    Type type = inst.GetType();
                    // =====================================================

                    // 設定 SSO 使用者資訊
                    // =====================================================
                    List<HttpCookie> cookies = new List<HttpCookie>();
                    for (int i = 0; i < Request.Cookies.Count; i++)
                    {
                        cookies.Add(Request.Cookies[i]);
                    }
                    string cookiesJsonString = JsonConvert.SerializeObject(cookies);
                    ssoInfo.JObjectData.Add("Cookies", cookiesJsonString);

                    List<KeyValuePair<string, string>> serverVariables = new List<KeyValuePair<string, string>>();
                    for (int i = 0; i < Request.Cookies.Count; i++)
                    {
                        string key = Request.ServerVariables.GetKey(i);
                        string value = Request.ServerVariables[key];
                        serverVariables.Add(new KeyValuePair<string, string>(key, value));
                    }
                    string serverVariablesJsonString = JsonConvert.SerializeObject(serverVariables);
                    ssoInfo.JObjectData.Add("ServerVariables", serverVariablesJsonString);

                    List<KeyValuePair<string, string>> form = new List<KeyValuePair<string, string>>();
                    for (int i = 0; i < Request.Form.Count; i++)
                    {
                        string key = Request.Form.GetKey(i);
                        string value = Request.Form[key];
                        form.Add(new KeyValuePair<string, string>(key, value));
                    }
                    string formsJsonString = JsonConvert.SerializeObject(form);
                    ssoInfo.JObjectData.Add("Form", formsJsonString);

                    List<KeyValuePair<string, string>> queryString = new List<KeyValuePair<string, string>>();
                    for (int i = 0; i < Request.QueryString.Count; i++)
                    {
                        string key = Request.QueryString.GetKey(i);
                        string value = Request.QueryString[key];
                        queryString.Add(new KeyValuePair<string, string>(key, value));
                    }
                    string queryStringJsonString = JsonConvert.SerializeObject(queryString);
                    ssoInfo.JObjectData.Add("QueryString", queryStringJsonString);


                    object[] args = new object[] { ssoInfo };
                    // =====================================================

                    // 驗證 SSO
                    // =====================================================
                    ssoInfo = (SSOInfo)type.InvokeMember("Verify", BindingFlags.InvokeMethod, Type.DefaultBinder, inst, args);
                    islogin = ssoInfo.IsAuthenticated;
                    // =====================================================
                }
                else
                {
                    islogin = true;
                }

                // 授權
                if (islogin)
                {
                    string errMsg = string.Empty;
                    bool isSSOAuth = ssoAssemblyName != "FormLoginProvider";
                    bool isAuthorization = DBValidadeUser(userCode, passw, isSSOAuth, out errMsg);

                    if (isAuthorization)
                    {
                        SetUserInfo(ssoInfo.UserCode, out userInfo);

                        System.Text.StringBuilder sbUserData = new System.Text.StringBuilder();
                        sbUserData.Append(string.Format("userData={0}", Newtonsoft.Json.JsonConvert.SerializeObject(userInfo)));

                        LogHelper.AddLogonLog(userInfo.UserId, sbUserData.ToString(), "Success");

                        Login(userInfo, sbUserData.ToString());
                    }
                    else
                    {
                        System.Text.StringBuilder sbUserData = new System.Text.StringBuilder();
                        sbUserData.Append("userData={\"UserCode\":\"" + userInfo.UserCode + "\",\"Message\":\"" + errMsg + "\"}");

                        LogHelper.AddLogonLog(userInfo.UserId, sbUserData.ToString(), "Fail");

                        //Login Fail
                        HttpCookie loginfailCookie = new HttpCookie("loginFail");
                        loginfailCookie.Value = Server.UrlEncode(errMsg);
                        System.Web.HttpContext.Current.Response.Cookies.Set(loginfailCookie);
                        //Response.Redirect(DotNetCasClient.CasAuthentication.NotAuthorizedUrl);

                        lblMessage.Text = errMsg;
                    }
                }
                else
                {
                    System.Text.StringBuilder sbUserData = new System.Text.StringBuilder();
                    sbUserData.Append("userData={\"UserCode\":\"" + userInfo.UserCode + "\",\"Message\":\"" + ssoInfo.Message + "\"}");

                    LogHelper.AddLogonLog(userInfo.UserId, sbUserData.ToString(), "Fail");
                    lblMessage.Text = ssoInfo.Message;
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = ex.GetBaseException().Message;
                MetaEdge.Utility.ExceptionUtility.LogException(ex, ex.TargetSite.Name);
            }
        }

        private void SetUserInfo(string userCode, out UserInfo userInfo)
        {
            userInfo = new UserInfo();

            try
            {
                auth_Users[] users = AuthApiHelper.Get<auth_Users>(string.Format("auth_Users(userCode='{0}')", userCode));
                if (users.Length > 0)
                {
                    auth_Users user = users[0];

                    userInfo.UserId = user.UserId;
                    userInfo.UserCode = userCode;
                    userInfo.UserName = user.UserName;
                    userInfo.AffiliateId = user.AffiliateId;

                    auth_Affiliates[] resultAffiliates = AuthApiHelper.Get<auth_Affiliates>(string.Format("auth_Affiliates(AffiliateId={0})", userInfo.AffiliateId));
                    userInfo.AffiliateName = resultAffiliates[0].AffiliateName;

                    userInfo.SessionId = HttpContext.Current.Session.SessionID;
                }
            }
            catch (Exception ex)
            {
                MetaEdge.Utility.ExceptionUtility.LogException(ex, string.Format("SetUserInfo('{0}')", userCode));
            }
        }

        protected void Login(UserInfo userInfo, string userData)
        {
            FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1,
              userInfo.UserCode,
              DateTime.Now,
              DateTime.Now.AddMinutes(240),
              true,
              userData.ToString(),
              FormsAuthentication.FormsCookiePath);

            // Encrypt the ticket.
            string encTicket = FormsAuthentication.Encrypt(ticket);

            // Create the cookie.
            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
            cookie.HttpOnly = true;
            HttpContext.Current.Response.Cookies.Add(cookie);

            // Create the cookie - MetaEdge組件的UserInfo使用
            string appguid = System.Web.Configuration.WebConfigurationManager.AppSettings["AppCookieGUID"];
            HttpCookie cookie2 = new HttpCookie("MetaEdge" + appguid, encTicket);
            cookie2.HttpOnly = true;
            HttpContext.Current.Response.Cookies.Add(cookie2);

            // Create Identity;
            FormsIdentity id = new FormsIdentity(ticket);
            string[] roles = new string[] { };
            GenericPrincipal principal = new GenericPrincipal(id, roles);
            HttpContext.Current.User = principal;

            HttpContext.Current.Response.AddHeader("REQUIRES_AUTH", "1");

            HttpContext.Current.Response.Redirect("~/Security/Substitute/Security_Substitute_Choice.aspx?toApp=" + toApp, false);
            
            //if (!string.IsNullOrEmpty(toApp))
            //{
            //    HttpContext.Current.Response.Redirect("Jumper.aspx?toApp=" + toApp);
            //}
            //else
            //{
            //    // 查詢此 UserId 的應用程式權限
            //    auth_UserApplication[] ua = AuthApiHelper.Get<auth_UserApplication>(string.Format("auth_UserApplication?$filter=UserId eq {0}", userInfo.UserId));
            //    if (ua.Length == 1)
            //    {
            //        // 如果使用者只有 1 項應用程式的權限，則直接導向該應用程式
            //        HttpContext.Current.Response.Redirect("Jumper.aspx?toApp=" + ua[0].AppId);
            //    }
            //    else
            //    {

            //        HttpContext.Current.Response.Redirect(FormsAuthentication.DefaultUrl, false);
            //    }
            //}
        }

        protected bool DBValidadeUser(string UserCode, string Password, bool isSSOLogin, out string errorMessage)
        {
            errorMessage = string.Empty;
            // 執行資料庫驗證
            auth_Users[] result = AuthApiHelper.Get<auth_Users>(string.Format("auth_Users(UserCode='{0}')", UserCode));
            auth_Users user = result.Length > 0 ? result[0] : null;

            if (user == null)
            {
                //throw new Exception("系統查無此帳號.");
                errorMessage = "系統查無此帳號.";
                return false;
            }

            if (user.Suspended ?? false)
            {
                //throw new Exception("帳號停用中.");
                errorMessage = "帳號停用中.";
                return false;
            }

            if ((user.SignOnRetryLimit ?? 0) != 0 && user.SignOnRetryLimit == user.SignOnErrorCnt)
            {
                //throw new Exception("登入失敗次數已達到限制,帳號已被鎖定.");
                errorMessage = "登入失敗次數已達到限制,帳號已被鎖定.";
                return false;
            }

            if (!isSSOLogin && user.Password != MetaEdge.Security.Cryptography.ToSHA512(Password))
            {
                // 有設定「限制重登次數」的話，「登入錯誤次數」增加 1
                if (!(result[0].SignOnRetryLimit == null || result[0].SignOnRetryLimit == 0))
                {
                    if (result[0].SignOnErrorCnt == null)
                    {
                        result[0].SignOnErrorCnt = 1;
                    }
                    else
                    {
                        result[0].SignOnErrorCnt += 1;
                    }

                    string jData = Newtonsoft.Json.JsonConvert.SerializeObject(result[0]);
                    AuthApiHelper.Put<auth_Users>(string.Format("auth_Users(userId={0})", result[0].UserId), jData);
                }
                //throw new Exception("帳號或密碼不正確.");
                errorMessage = string.Format("登入失敗，帳號或密碼錯誤!(次數：{0})", result[0].SignOnErrorCnt);
                return false;
            }

            // 有設定「限制重登次數」的話，在成功登入後，「登入錯誤次數」會歸零
            if (!(result[0].SignOnRetryLimit == null || result[0].SignOnRetryLimit == 0))
            {
                result[0].SignOnErrorCnt = 0;
                string jData = Newtonsoft.Json.JsonConvert.SerializeObject(result[0]);
                AuthApiHelper.Put<auth_Users>(string.Format("auth_Users(userId={0})", result[0].UserId), jData);
            }
            return true;
        }

        protected void UpdateSignOnErrorCount(string userCode)
        {
            // 執行資料庫驗證
            auth_Users[] result = AuthApiHelper.Get<auth_Users>(string.Format("auth_Users(UserCode='{0}')", userCode));
            auth_Users user = result.Length > 0 ? result[0] : null;

            // 有設定「限制重登次數」的話，「登入錯誤次數」增加 1
            if (result[0].SignOnRetryLimit != null && result[0].SignOnRetryLimit != 0)
            {
                if (result[0].SignOnErrorCnt == null)
                {
                    result[0].SignOnErrorCnt = 1;
                }
                else
                {
                    result[0].SignOnErrorCnt += 1;
                }

                string jData = Newtonsoft.Json.JsonConvert.SerializeObject(result[0]);
                AuthApiHelper.Put<auth_Users>(string.Format("auth_Users(userId={0})", result[0].UserId), jData);
            }
        }
    }
}
