using System;

namespace MetaEdge.MetaFiT.WebUI
{
    public partial class DetailMaster2 : MetaEdge.Web.BaseMasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}