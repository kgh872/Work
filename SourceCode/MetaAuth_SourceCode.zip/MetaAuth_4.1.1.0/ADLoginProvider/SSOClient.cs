﻿using MetaEdge.Data;
using MetaEdge.Security.Entity.Models;
using MetaEdge.Web;
using System;
using System.DirectoryServices;

namespace ADLoginProvider
{
    public class SSOClient : MetaEdge.Web.SSOProviderBase
    {
        public override SSOInfo Verify(SSOInfo jobject)
        {
            try
            {
                string LoginAD = MetaEdge.Registry.AppSettingsFactory.Get("ADServer");
                string LDUrl = string.Format("LDAP://{0}", LoginAD);
                string LUser = string.Format(@"{0}\{1}", LoginAD, jobject.UserCode);
                DirectoryEntry AdUser = new DirectoryEntry(LDUrl, jobject.UserCode, jobject.UserPassw);
                DirectorySearcher search = new DirectorySearcher(AdUser);
           
                //search.Filter = "(&(cn=" + jobject.UserCode + "))";
                search.Filter = "(SAMAccountName=" + jobject.UserCode + ")";
                SearchResult result = search.FindOne();

                if (null == result)
                {
                    jobject.IsAuthenticated = false;
                }
                else
                {
                    jobject.IsAuthenticated = true;
                    jobject.UserName = result.Properties["displayName"][0].ToString();
                }

            }
            catch (Exception e)
            {
                jobject.IsAuthenticated = false;
                jobject.Message = e.Message;
            }

            return jobject;
        }
    }
}
