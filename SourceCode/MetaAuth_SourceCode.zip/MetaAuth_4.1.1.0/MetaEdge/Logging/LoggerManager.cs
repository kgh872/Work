﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.Logging
{
    public static class LoggerManager
    {
        private static ILoggerFactoryAdapter _adapter;

        public static ILoggerFactoryAdapter Adapter
        {
            get
            {
                if (_adapter == null)
                {
                    _adapter = new Default.FileLoggerFactoryAdapter();
                }
                return _adapter;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("Adapter");
                }
                _adapter = value;
            }
        }

        public static ILogger GetCurrentLogger(string name)
        {
            return Adapter.GetLogger(name);
        }

        public static void Archive(string name)
        {
            ((LoggerBase)GetCurrentLogger(name)).Archive();
        }
    }
}
