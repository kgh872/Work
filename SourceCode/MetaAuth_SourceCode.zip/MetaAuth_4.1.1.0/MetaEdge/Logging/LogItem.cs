﻿namespace MetaEdge.Logging
{
    using System;
    using System.Xml.Serialization;

    public class LogItem
    {
        #region properties
        
        public LogLevel Level { get; set; }

        public DateTimeOffset Timestamp { get; set; }

        public string Title { get; set; }

        public string Message { get; set; }

        public string LoggerName { get; set; }

        [XmlIgnore]
        public Exception Exception { get; set; }

        public int? EventId { get; set; }

        #endregion

        public LogItem()
        {
            Title = String.Empty;
            Message = String.Empty;
            Level = LogLevel.Info;
            LoggerName = String.Empty;

            Timestamp = DateTimeOffset.Now;
        }
    }
}
