﻿namespace MetaEdge.Logging.MSSQL
{
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.IO;
    using System.Data;
    using System.Data.SqlClient;

    public class MSSQLLogger : LoggerBase
    {
        string _serverName = "127.0.0.1";
        string _databaseName = "MetaAuth";
        string _schema = "dbo";

        string _tableName = "log_Exception";
        string _userName = "";
        string _validCode = "";

        string _connectionString = string.Empty;
        const int _defaultArchiveMaxDays = 90;
        int _archiveMaxDays = _defaultArchiveMaxDays;

        //public MSSQLLogger(string name, string serverName, string databaseName, string schema, string tableName, string userName, string validCode)
        //    : this(name, serverName, databaseName, schema, tableName)
        //{
        //    _userName = userName;
        //    _validCode = validCode;
        //}

        //public MSSQLLogger(string name, string serverName, string databaseName, string schema, string tableName)
        //    : this(name, serverName, databaseName)
        //{
        //    _tableName = tableName;
        //    _schema = schema;
        //}

        //public MSSQLLogger(string name, string serverName, string databaseName)
        //    : this(name)
        //{
        //    _serverName = serverName;
        //    _databaseName = databaseName;
        //}

        public MSSQLLogger(string name, string connectionString)
            : this(name)
        {
            _connectionString = connectionString;
            using (SqlConnection conn = new SqlConnection(this.ConnectionString))
            {
                _databaseName = conn.Database;
                _serverName = conn.DataSource;
            }
        }

        public MSSQLLogger(string name)
            : base(name)
        {
        }

        public string ServerName
        {
            get { return _serverName; }
            set { _serverName = value; }
        }

        public string DatabaseName
        {
            get { return _databaseName; }
            set { _databaseName = value; }
        }

        public string Schema
        {
            get { return _schema; }
            set { _schema = value; }
        }

        public string TableName
        {
            get { return _tableName; }
            set { _tableName = value; }
        }

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        public string ValidCode
        {
            get { return _validCode; }
            set { _validCode = value; }
        }

        public string ConnectionString
        {
            get
            {
                if (!string.IsNullOrEmpty(_connectionString))
                {
                    return _connectionString;
                }

                string connectionStringPattern = "Server={0};database={1};uid={2};pwd={3};Trusted_Connection=False;";
                if (string.IsNullOrEmpty(_userName) || string.IsNullOrEmpty(_validCode))
                {
                    connectionStringPattern = "Server={0};database={1};Trusted_Connection=True;";
                }
                return string.Format(connectionStringPattern, _serverName, _databaseName, _userName, _validCode);
            }
            set { _connectionString = value; }
        }


        public int ArchiveMaxDays
        {
            get
            {
                if (_archiveMaxDays != _defaultArchiveMaxDays)
                {
                    return _archiveMaxDays;
                }
                
                string customLogKeepDays = MetaEdge.Registry.AppSettingsFactory.Get("MetaEdgeLoggingArchiveMaxDays");
                if (!string.IsNullOrEmpty(customLogKeepDays))
                {
                    int.TryParse(customLogKeepDays, out _archiveMaxDays);
                }
                return _archiveMaxDays;
            }

            set { _archiveMaxDays = value; }
        }

        public override void Log(LogItem item)
        {
            Guid globalId = Guid.NewGuid();
            string datetime = item.Timestamp.ToString("yyyy/MM/dd HH:mm:ss.fff");
            string levelName = Enum.GetName(typeof(LogLevel), item.Level);
            string source = item.LoggerName;
            string stackTrace = item.Exception != null ? item.Exception.ToString() : string.Empty;
            string serviceName = AppDomain.CurrentDomain.FriendlyName;

            // IIS 應用程式
            if (serviceName.StartsWith("/LM/W3SVC/1/ROOT/"))
            {
                // TODO: 截斷後面變動的數字  /LM/W3SVC/1/ROOT/MetaAuth-20-132119768112188196
                for (int i = 0; i < 2 && serviceName.LastIndexOf("-") > 0; i++)
                {
                    serviceName = serviceName.Substring(0, serviceName.LastIndexOf("-"));
                }

            }

            int maxMessageLength = 4000;
            int maxStackTraceLength = 10000000;

            string command = string.Format(@"
                DECLARE @cmd NVARCHAR(1000)
                DECLARE @innerDatabase NVARCHAR(1000)
                DECLARE @innerSchema NVARCHAR(1000)
                DECLARE @innerTable NVARCHAR(1000)
                
                SET @innerDatabase = @Database
                SET @innerSchema = @Schema
                SET @innerTable = @Table

                SET @cmd = 'INSERT INTO ' + QUOTENAME(@innerDatabase)
                                + '.' + QUOTENAME(@innerSchema)
                                + '.' + QUOTENAME(@innerTable)
                                + '(AppId, HostName, GlobalId, ServiceName, LogLevel, Source, Message, StackTrace, LogTime)  '
                                + ' Select @AppId, @HostName, @GlobalId, @ServiceName, @LogLevel, @Source, @Message, @StackTrace, @LogTime';

                EXEC sp_executesql @cmd, N'@AppId INT, @HostName NVARCHAR(50), @GlobalId UNIQUEIDENTIFIER, @ServiceName VARCHAR(100), @LogLevel VARCHAR(50), @Source NVARCHAR(100), @Message NVARCHAR(4000), @StackTrace NVARCHAR(MAX), @LogTime DATETIME', @AppId = @AppId, @HostName = @HostName, @GlobalId = @GlobalId, @ServiceName = @ServiceName, @LogLevel = @LogLevel, @Source = @Source , @Message = @Message , @StackTrace = @StackTrace , @LogTime = @LogTime
              "
            );

            try
            {
                using (SqlConnection conn = new SqlConnection(this.ConnectionString))
                {
                    conn.Open();
                    SqlParameter[] sqlParams = new SqlParameter[]
                    {
                        new SqlParameter("Database", this.DatabaseName)
                        , new SqlParameter("Schema", this.Schema)
                        , new SqlParameter("Table", this.TableName)
                        , new SqlParameter("GlobalId", globalId)
                        , new SqlParameter("AppId", MetaEdge.Registry.AppSettingsFactory.Get("APPID"))
                        , new SqlParameter("HostName", System.Environment.MachineName)
                        , new SqlParameter("ServiceName", serviceName) // TODO :
                        , new SqlParameter("LogLevel", Enum.GetName(typeof(LogLevel), item.Level))
                        , new SqlParameter("Source", item.LoggerName)
                        , new SqlParameter("Message", item.Message!=null && item.Message.Length > maxMessageLength ? item.Message.Substring(0,maxMessageLength):item.Message)
                        , new SqlParameter("StackTrace", stackTrace!=null && stackTrace.Length > maxStackTraceLength ? stackTrace.Substring(0,maxStackTraceLength):stackTrace )
                        , new SqlParameter("LogTime", DateTime.Now)
                    };

                    SqlCommand cmd = new SqlCommand(command, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddRange(sqlParams);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Logging.Default.FileLoggerFactoryAdapter adapter = new Logging.Default.FileLoggerFactoryAdapter();
                // 紀錄<寫Log錯誤>
                adapter.GetLogger("MSSQLLogger").Error(command, ex);
                // 紀錄<原始Log>
                adapter.GetLogger(item.LoggerName).Log(item);
            }
        }

        public void DeleteLogByDays()
        {
            DeleteLogByDays(this.ArchiveMaxDays);
        }

        public void DeleteLogByDays(int archiveMaxDays)
        {
            string command = string.Format(@"
                DECLARE @cmd NVARCHAR(1000)
                SET @cmd = 'DELETE ' + QUOTENAME('{0}') 
                    + '.' + QUOTENAME('{1}') 
                    + '.' + QUOTENAME('{2}')
                    + ' WHERE Timestamp < GETDATE() - {3}';
					
					EXEC sp_executesql @cmd;"
                , DatabaseName
                , Schema
                , TableName
                , archiveMaxDays
            );

            try
            {
                using (SqlConnection conn = new SqlConnection(this.ConnectionString))
                {
                    SqlCommand cmd = new SqlCommand(command, conn);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                Log(command, ex, LogLevel.Error);
            }
        }

        public override void Archive()
        {
            DeleteLogByDays();
        }
    }
}
