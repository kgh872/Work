﻿namespace MetaEdge.Logging.MSSQL
{
    public class MSSQLLoggerFactoryAdapter : ILoggerFactoryAdapter
    {
        private string _connectionString;
        public MSSQLLoggerFactoryAdapter()
        {

        }

        public MSSQLLoggerFactoryAdapter(string connectionString)
        {
            _connectionString = connectionString;
        }

        public ILogger GetLogger(string name)
        {
            return !string.IsNullOrEmpty(_connectionString) ? new MSSQLLogger(name, _connectionString) : new MSSQLLogger(name);
        }

    }
}
