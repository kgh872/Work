﻿using System;
namespace MetaEdge.Logging
{
    using System.Configuration;

    public abstract class LoggerBase : ILogger
    {
        protected LoggerBase(string name)
        {
            Name = name;
        }

        LogLevel minLogLevel = LogLevel.Info;

        public string Name { get; private set; }

        #region Trace

        public void Trace(string message)
        {
            Log(message, LogLevel.Trace);
        }

        public void Trace(Exception exception)
        {
            Log(exception, LogLevel.Trace);
        }

        public void Trace(string message, Exception exception)
        {
            Log(message, exception, LogLevel.Trace);
        }

        #endregion

        #region Debug
        
        public void Debug(string message)
        {
            Log(message, LogLevel.Debug);
        }

        public void Debug(Exception exception)
        {
            Log(exception, LogLevel.Debug);
        }

        public void Debug(string message, Exception exception)
        {
            Log(message, exception, LogLevel.Debug);
        }

        #endregion

        #region Info

        public void Info(string message)
        {
            Log(message, LogLevel.Info);
        }

        public void Info(Exception exception)
        {
            Log(exception, LogLevel.Info);
        }

        public void Info(string message, Exception exception)
        {
            Log(message, exception, LogLevel.Info);
        }

        #endregion

        #region Warn

        public void Warn(string message)
        {
            Log(message, LogLevel.Warn);
        }

        public void Warn(Exception exception)
        {
            Log(exception, LogLevel.Warn);
        }

        public void Warn(string message, Exception exception)
        {
            Log(message, exception, LogLevel.Warn);
        }

        #endregion

        #region Error

        public void Error(string message)
        {
            Log(message, LogLevel.Error);
        }

        public void Error(Exception exception)
        {
            Log(exception, LogLevel.Error);
        }

        public void Error(string message, Exception exception)
        {
            Log(message, exception, LogLevel.Error);
        }

        #endregion

        #region Fatal

        public void Fatal(string message)
        {
            Log(message, LogLevel.Fatal);
        }

        public void Fatal(Exception exception)
        {
            Log(exception, LogLevel.Fatal);
        }

        public void Fatal(string message, Exception exception)
        {
            Log(message, exception, LogLevel.Fatal);
        }

        #endregion

        #region Log

        public virtual void Log(string message, LogLevel level)
        {
            Log(message, null, level);
        }

        public virtual void Log(Exception exception, LogLevel level)
        {
            Log(exception.GetBaseException().Message, exception, level);
        }

        public virtual void Log(string message, Exception exception, LogLevel level)
        {
            LogItem item = new LogItem { 
                Level = level, 
                Message = message, 
                LoggerName = this.Name,
                Exception = exception
            };
            Log(item);
        }

        #endregion

        protected LogLevel MinLogLevel
        {
            get 
            {
                string customMinLogLevel = ConfigurationManager.AppSettings["MetaEdgeLoggingMinLogLevel"];
                if (string.IsNullOrEmpty(customMinLogLevel))
                {
                    Enum.TryParse<LogLevel>(customMinLogLevel, out minLogLevel);
                }
                return minLogLevel; 
            }
            set { minLogLevel = value; }
        }

        protected virtual bool IsLogLevelEnabled(LogLevel level)
        {
            return (int)level >= (int)minLogLevel;
        }

        public abstract void Log(LogItem item);

        /// <summary>
        /// The app.config add appSetting key "MetaEdgeLoggingArchiveMaxDays" can change archive max days 
        /// </summary>
        public abstract void Archive();

    }
}
