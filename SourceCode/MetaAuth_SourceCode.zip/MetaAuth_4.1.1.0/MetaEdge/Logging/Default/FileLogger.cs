﻿namespace MetaEdge.Logging.Default
{
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.IO;

    public class FileLogger : LoggerBase
    {
        string _logFolder = AppDomain.CurrentDomain.BaseDirectory + "Log";
        const int _defaultArchiveMaxDays = 90;
        int _archiveMaxDays = _defaultArchiveMaxDays;

        public FileLogger(string name, string logFolder)
            : base(name)
        {
            _logFolder = logFolder;
        }

        public FileLogger(string name)
            : base(name)
        {
        }

        public string LogFolder
        {
            get { return _logFolder; }
            set { _logFolder = value; }
        }

        public int ArchiveMaxDays
        {
            get {
                if (_archiveMaxDays != _defaultArchiveMaxDays)
                {
                    return _archiveMaxDays;
                }

                string customLogKeepDays = ConfigurationManager.AppSettings["MetaEdgeLoggingArchiveMaxDays"];
                if (!string.IsNullOrEmpty(customLogKeepDays))
                {
                    int.TryParse(customLogKeepDays, out _archiveMaxDays);
                }
                return _archiveMaxDays;
            }

            set { _archiveMaxDays = value; }
        }

        public override void Log(LogItem item)
        {
            Guid globalId = Guid.NewGuid();
            string datetime = item.Timestamp.ToString("yyyy/MM/dd HH:mm:ss.fff").PadRight(23, ' ');
            string levelName = Enum.GetName(typeof(LogLevel), item.Level).PadRight(5, ' ');
            string source = item.LoggerName;
            string stackTrace = item.Exception != null ? item.Exception.ToString() : string.Empty;


            //每天存一個檔案
            string fileHead = item.LoggerName; //"OpLog";  //檔案前置詞
            string messageHeader = string.Empty;
            string messageContent = string.Empty;
            string now = DateTime.Now.ToString("yyyyMMdd");
            FileInfo lastFile;

            if (!Directory.Exists(_logFolder))
            {
                Directory.CreateDirectory(_logFolder);
            }
            DirectoryInfo dir = new DirectoryInfo(_logFolder);
            FileInfo[] fileInfos = dir.GetFiles(string.Format("{0}{1}.txt",
                                                    fileHead,
                                                    now));
            StreamWriter sw;
            if (fileInfos.Length > 0)
            {
                lastFile = fileInfos[0];
                sw = lastFile.AppendText();
            }
            else
            {
                lastFile = new FileInfo(string.Format(@"{0}\{1}{2}.txt", dir.FullName, fileHead, now));
                sw = lastFile.AppendText();
                messageHeader = string.Format("{0} |{1} |{2}|{3}|{4}|{5}",
                                                   "GlobalId".PadRight(36, ' '),
                                                   "Datetime".PadRight(23, ' '),
                                                   "Level".PadRight(5, ' '),
                                                   "Source",
                                                   "Message",
                                                   "StackTrace");
                sw.WriteLine(messageHeader);
            }

            messageContent = string.Format("{0} |{1} |{2}|{3}|{4}|{5}",
                                                    globalId.ToString(),
                                                    datetime,
                                                    levelName,
                                                    source,
                                                    item.Message,
                                                    stackTrace);
            sw.WriteLine(messageContent);
            sw.Close();
        }

        public void DeleteLogByDays()
        {
            DeleteLogByDays(this.ArchiveMaxDays);
        }

        public void DeleteLogByDays(int archiveMaxDays)
        {
            if (!Directory.Exists(_logFolder)) { return; }

            string[] files = Directory.GetFiles(_logFolder);

            foreach (string file in files)
            {
                FileInfo fi = new FileInfo(file);
                if (fi.LastAccessTime < DateTime.Now.AddDays(-archiveMaxDays))
                {
                    fi.Delete();
                }
            }
        }

        public override void Archive()
        {
            DeleteLogByDays();
        }
    }
}
