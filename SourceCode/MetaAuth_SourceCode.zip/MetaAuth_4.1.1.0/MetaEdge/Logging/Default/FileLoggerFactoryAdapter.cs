﻿namespace MetaEdge.Logging.Default
{
    public class FileLoggerFactoryAdapter  : ILoggerFactoryAdapter
    {
        public ILogger GetLogger(string name)
        {
            return new FileLogger(name);
        }
    }
}
