﻿using Newtonsoft.Json.Linq;

namespace MetaEdge.Data
{
    public class ODataItem
    {
        public string Uri { get; set; }
        public string Method { get; set; }
        public JObject Data { get; set; }
    }
}