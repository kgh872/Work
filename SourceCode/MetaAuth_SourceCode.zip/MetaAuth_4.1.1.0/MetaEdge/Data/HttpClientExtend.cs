﻿using MetaEdge.Web;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace MetaEdge.Data
{
    /// <summary>
    /// 配合 static HttpClient使用，
    /// 因原生的GetAsync,PostAsync等方法，static HttpClient於多線程設置DefaultHeader時會互相影響，
    /// 故改用原生SendAsync方法，讓不同Request可以有各自的Header
    /// 為方便加入不同Header，加上此擴充方法
    /// extension method that allow you to manipulate the request header and more of the HttpRequestMessage before it is sent
    /// https://stackoverflow.com/questions/37928543/httpclient-single-instance-with-different-authentication-headers
    /// </summary>
    public static class httpClientExtend
    {

        public static Task<HttpResponseMessage> SendAsync<T>  
            (this HttpClient httpClient, HttpMethod method, string uri, T value, Action<HttpRequestMessage> preAction)
        {
            var httpRequestMessage = new HttpRequestMessage(method, uri)
            {
                Content = new ObjectContent<T>
                    (value, new System.Net.Http.Formatting.JsonMediaTypeFormatter(), (System.Net.Http.Headers.MediaTypeHeaderValue)null)
            };
            preAction(httpRequestMessage);

            return httpClient.SendAsync(httpRequestMessage);
        }

        public static Task<HttpResponseMessage> GetAsync(this HttpClient httpClient, string uri, Action<HttpRequestMessage> preAction)
        {
            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, uri);

            preAction(httpRequestMessage);

            return httpClient.SendAsync(httpRequestMessage);
        }

        public static Task<HttpResponseMessage> PostAsJsonAsync<T>
            (this HttpClient httpClient, string uri, T value, Action<HttpRequestMessage> preAction)
        {
            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, uri)
            {
                Content = new ObjectContent<T>
                    (value, new System.Net.Http.Formatting.JsonMediaTypeFormatter(), (System.Net.Http.Headers.MediaTypeHeaderValue)null)
            };
            preAction(httpRequestMessage);

            return httpClient.SendAsync(httpRequestMessage);
        }

        public static Task<HttpResponseMessage> PutAsJsonAsync<T>
            (this HttpClient httpClient, string uri, T value, Action<HttpRequestMessage> preAction)
        {
            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Put, uri)
            {
                Content = new ObjectContent<T>
                    (value, new System.Net.Http.Formatting.JsonMediaTypeFormatter(), (System.Net.Http.Headers.MediaTypeHeaderValue)null)
            };
            preAction(httpRequestMessage);

            return httpClient.SendAsync(httpRequestMessage);
        }

        public static Task<HttpResponseMessage> PatchAsJsonAsync<T>
            (this HttpClient httpClient, string uri, T value, Action<HttpRequestMessage> preAction)
        {
            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Put, uri)
            {
                Content = new ObjectContent<T>
                    (value, new System.Net.Http.Formatting.JsonMediaTypeFormatter(), (System.Net.Http.Headers.MediaTypeHeaderValue)null)
            };
            preAction(httpRequestMessage);

            return httpClient.SendAsync(httpRequestMessage);
        }


        public static Task<HttpResponseMessage> DeleteAsync(this HttpClient httpClient, string uri, Action<HttpRequestMessage> preAction)
        {
            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Delete, uri);

            preAction(httpRequestMessage);

            return httpClient.SendAsync(httpRequestMessage);
        }
    }
}
