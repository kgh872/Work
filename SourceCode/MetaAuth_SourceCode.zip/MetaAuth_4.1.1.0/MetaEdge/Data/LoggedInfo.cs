﻿
namespace MetaEdge.Data
{
    public class LoggedInfo
    {
        public string Status { get; set; }
        public string Command { get; set; }
        public string Source { get; set; }
        public string Target { get; set; }
        public string Result { get; set; }
    }
}