﻿using System;
using System.Data;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.Remoting;
using System.Collections.Specialized;
using System.Collections;
using MetaEdge.Security;
using Newtonsoft.Json.Linq;
using System.Web;
using System.Linq;
using MetaEdge.Web;
using System.Net;
using Newtonsoft.Json;

namespace MetaEdge.Data
{
    /// <summary>
    /// Summary description for LogHelper
    /// </summary>
    public partial class LogHelper
    {
        public const int SqlLogMaxLength = 4000;
        /// <summary>
        /// 寫入使用者操作紀錄稽核軌跡
        /// </summary>
        /// <param name="item"></param>
        /// <param name="result"></param>
        public static void WriteAuditLog(ODataItem item, string result, string status)
        {
            string objectName = item.Uri.Split('?')[0].Split('(')[0];
            string[] segment = objectName.Split('/');
            objectName = segment[segment.Length - 1];

            if (HttpContext.Current.Request.Headers.GetValues("SkipLog") != null)
            {
                return;
            }

            string[] byPass = new string[] { "PageMenu", "securityPath", "securityCommand", "getActionName", "auth_Applications", "PageCommand", "BreadcrumbTrail" };
            if (!byPass.Contains(objectName) && !objectName.StartsWith("usp_WebParam"))
            {

                int rowCount = 1;
                if (status == "Fail") { rowCount = 0; }

                if (!string.IsNullOrEmpty(result))
                {
                    JObject resultObject = JObject.Parse(result);
                    if (resultObject["value"] != null)
                    {
                        rowCount = JObject.Parse(result)["value"].Count();
                    }
                }

                if (item.Method.ToUpper() == "POST" || item.Method.ToUpper() == "PUT")
                {
                    result = item.Data.ToString();
                }

                result = result.Length > SqlLogMaxLength ? result.Substring(0, SqlLogMaxLength) : result;
                objectName = GetObjectName(objectName);

                string actionName = GetActionName(objectName);
                if (!string.IsNullOrEmpty(actionName))
                {
                    LogHelper.AddAuditLog(objectName, actionName, GetOperationName(item.Method), item.Uri, status, rowCount, result);
                }
            }
        }

        private static string GetActionName(string objectName)
        {
            string actionName = string.Empty;
            if (HttpContext.Current.Request.Headers.GetValues("ActionTitle") != null)
            {
                actionName = HttpContext.Current.Request.Headers.GetValues("ActionTitle")[0];
                if (!string.IsNullOrEmpty(actionName))
                {
                    return Uri.UnescapeDataString(actionName);
                }
            }

            //string actionName = string.Empty;

            string actionUrl = HttpContext.Current.Request.UrlReferrer.AbsolutePath.Replace(HttpContext.Current.Request.ApplicationPath + @"/", "");
            //actionUrl = actionUrl.Substring(0, actionUrl.LastIndexOf('/') + 1);
            actionUrl = actionUrl.Substring(0, actionUrl.LastIndexOf('/') + 1).TrimStart('/');
            JObject[] pages = AuthApiHelper.Get<JObject>(string.Format("auth_Objects?$filter=(AppId eq 1 or AppId eq {0}) and substringof('{1}', NavigateUrl)&$orderby=AppId desc,NavigateUrl desc", MetaEdge.Registry.AppSettingsFactory.Get("APPID"), actionUrl));

            if (pages.Length > 0)
            {
                actionName = pages.First().GetValue("ObjectName").ToString();
            }
            return actionName;
        }

        private static string GetObjectName(string objectName)
        {
            string objectId = string.Empty;
            int Id = -1;
            if (HttpContext.Current.Request.Headers.GetValues("ActionId") != null)
            {
                objectId = HttpContext.Current.Request.Headers.GetValues("ActionId")[0];
                if (!string.IsNullOrEmpty(objectId) && int.TryParse(objectId, out Id))
                {

                    JObject actionObj = GetObject(objectId);
                    JObject categoryObj = null;
                    JObject moduleObj = null;
                    if (actionObj != null)
                    {
                        categoryObj = GetObject(actionObj["Parent"].ToString());
                        if (categoryObj != null)
                        {
                            moduleObj = GetObject(categoryObj["Parent"].ToString());
                            if (moduleObj != null)
                            {
                                objectName = string.Format(@"{0}\{1}\{2}"
                                    , moduleObj["ObjectName"].ToString()
                                    , categoryObj["ObjectName"].ToString()
                                    , actionObj["ObjectName"].ToString()
                                );
                            }
                        }
                    }
                }
            }
            return objectName;
        }

        private static JObject GetObject(string objectId)
        {
            JObject jobj = null;
            JObject[] pages = AuthApiHelper.Get<JObject>(string.Format("auth_Objects?$filter=ObjectId eq {0}", objectId));
            if (pages.Length > 0)
            {
                jobj = pages.First();
            }
            return jobj;
        }

        private static string GetOperationName(string httpMethod)
        {
            return httpMethod.ToUpper();
        }

        public static void AddLogonLog(int userId, string loggedInfo, string status)
        {
            string sessionId = string.Empty;
            if (HttpContext.Current.Session != null)
            {
                sessionId = HttpContext.Current.Session.SessionID;
            }

            JObject log = new JObject();
            log.Add("AppId", int.Parse(MetaEdge.Registry.AppSettingsFactory.Get("APPID")));
            log.Add("SessionId", sessionId);
            log.Add("UserId", userId);
            log.Add("LoginIP", HttpContext.Current.Request.UserHostAddress);
            log.Add("LoginTime", DateTime.Now);
            log.Add("LoggedInfo", loggedInfo);
            log.Add("Status", status);

            if (status == "Fail")
            {
                log.Add("LogoutTime", DateTime.Now);
            }

            string jData = Newtonsoft.Json.JsonConvert.SerializeObject(log);

            AuthApiHelper.Post<JObject>("log_Logon", jData);
        }

        public static void UpdateLogonLog()
        {
            JObject[] logs = AuthApiHelper.Get<JObject>(string.Format("log_Logon?$top=1&$filter=LoginIP eq '{0}'&$orderby=ID desc", HttpContext.Current.Request.UserHostAddress));
            if (logs.Length > 0)
            {
                JObject log = logs[0];
                log["LogoutTime"] = DateTime.Now;
                string jData = Newtonsoft.Json.JsonConvert.SerializeObject(log);
                AuthApiHelper.Put<JObject>(string.Format("log_Logon(id={0})", log.GetValue("ID").ToString()), jData);
            }
        }

        public static void AddOperationLog(System.Web.Http.Controllers.HttpActionContext actionContext, ApiClientInfo apiClientInfo, LoggedInfo logInfo)
        {
            string loggedInfo = JsonConvert.SerializeObject(logInfo, Formatting.Indented).Replace("\\\"", "\"").Replace(@"\r\n", "");
            loggedInfo = loggedInfo.Length > SqlLogMaxLength ? loggedInfo.Substring(0, SqlLogMaxLength) : loggedInfo;
            JObject log = new JObject();
            log.Add("ID", 0);
            log.Add("AppId", apiClientInfo.AppId);
            log.Add("UserId", apiClientInfo.UserId);
            log.Add("Operation", actionContext.Request.Method.Method);
            log.Add("PageTitle", actionContext.ControllerContext.Controller.ToString());
            log.Add("FunctionTime", DateTime.Now);
            log.Add("LoggedInfo", loggedInfo);

            AuthApiHelper.Post<JObject>("log_Operation", log);
        }

        /// <summary>
        /// 新增稽核的紀錄
        /// </summary>
        /// <param name="objectName"></param>
        /// <param name="actionName"></param>
        /// <param name="operation"></param>
        /// <param name="command"></param>
        /// <param name="status"></param>
        /// <param name="dataCount"></param>
        /// <param name="result"></param>
        public static void AddAuditLog(string objectName, string actionName, string operation, string command, string status, int dataCount, string result)
        {
            UserInfo userInfo = new UserInfo();

            JObject log = new JObject();
            log.Add("AppId", int.Parse(MetaEdge.Registry.AppSettingsFactory.Get("APPID")));
            log.Add("UserId", userInfo.UserId);
            log.Add("Source", HttpContext.Current.Request.UserHostAddress);
            log.Add("ActionTime", DateTime.Now);
            log.Add("Target", System.Environment.MachineName);
            log.Add("ObjectName", objectName);
            log.Add("Account", System.Environment.UserName);
            log.Add("ActionName", actionName);
            log.Add("Operation", operation);
            log.Add("Command", command);
            log.Add("Status", status);
            log.Add("DataCount", dataCount);
            log.Add("Result", result);
            log.Add("SubstituteUserId", userInfo.SubstituteUserId);
            log.Add("SubstituteUserCode", userInfo.SubstituteUserCode);
            log.Add("SubstituteUserName", userInfo.SubstituteUserName);

            //string jData = Newtonsoft.Json.JsonConvert.SerializeObject(log);

            AuthApiHelper.Post<JObject>("log_Audit", log);
        }

        public static void OperationLog(System.Web.Http.Controllers.HttpActionContext actionContext, ApiClientInfo apiClientInfo, string eventName)
        {
            if (!MustLog(Logging.LogLevel.Info)) { return; }

            if (ByPassLog(actionContext)) return;

            string result = Newtonsoft.Json.JsonConvert.SerializeObject(actionContext.ActionArguments);
            string status = HttpStatusCode.Accepted.ToString();

            LoggedInfo logInfo = new LoggedInfo();
            logInfo.Command = actionContext.Request.RequestUri.ToString();
            logInfo.Source = apiClientInfo.UserHostAddress;
            logInfo.Target = Environment.MachineName;
            logInfo.Status = status;
            logInfo.Result = result;

            AddOperationLog(actionContext, apiClientInfo, logInfo);
        }

        public static void OperationLog(System.Web.Http.Filters.HttpActionExecutedContext actionExecutedContext, ApiClientInfo apiClientInfo, string eventName)
        {
            if (!MustLog(Logging.LogLevel.Info)) { return; }

            System.Web.Http.Controllers.HttpActionContext actionContext = actionExecutedContext.ActionContext;
            if (ByPassLog(actionContext)) return;

            string result = string.Empty;
            int dataCount = 0;
            string status = HttpStatusCode.Accepted.ToString();

            if (actionExecutedContext.Exception == null)
            {
                status = actionContext.Response.StatusCode.ToString();

                try
                {
                    var responseResult = string.Empty;
                    if (actionExecutedContext.Response.Content != null)
                    {
                        responseResult = actionExecutedContext.Response.Content.ReadAsStringAsync().Result;

                        if (JObject.Parse(responseResult).GetValue("value") != null)
                        {
                            dataCount = JObject.Parse(responseResult)["value"].Count();
                            result = JObject.Parse(responseResult)["value"].ToString();
                        }
                        else
                        {
                            dataCount = 1;
                            var tempResult = JObject.Parse(responseResult);
                            tempResult.Remove("odata.metadata");
                            result = tempResult.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    result = ex.GetBaseException().Message;
                    if (ex.GetBaseException().InnerException != null)
                    {
                        result = ex.GetBaseException().InnerException.Message;
                    }
                }
            }

            else
            {
                result = actionExecutedContext.Exception.GetBaseException().Message;
                if (actionExecutedContext.Exception.GetBaseException().InnerException != null)
                {
                    result = actionExecutedContext.Exception.GetBaseException().InnerException.Message;
                }

                result = actionExecutedContext.Exception.GetBaseException().Message;
                status = HttpStatusCode.ExpectationFailed.ToString();
            }

            LoggedInfo logInfo = new LoggedInfo();
            logInfo.Command = actionContext.Request.RequestUri.ToString();
            logInfo.Source = apiClientInfo.UserHostAddress;
            logInfo.Target = Environment.MachineName;
            logInfo.Status = status;
            logInfo.Result = result;

            AddOperationLog(actionContext, apiClientInfo, logInfo);
        }

        private static bool ByPassLog(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            bool byPass = false;
            string controllerName = actionContext.ControllerContext.Controller.ToString();

            string[] byPassController = new string[]
            {
                "MetaEdge.MetaAuth.API.Controllers.BreadcrumbTrailController",
                "MetaEdge.MetaAuth.API.Controllers.PageCommandController",
                "MetaEdge.MetaAuth.API.Controllers.PageMenuController",
                "MetaEdge.MetaAuth.API.Controllers.log_AuditController",
                "MetaEdge.MetaAuth.API.Controllers.log_CodeTraceController",
                "MetaEdge.MetaAuth.API.Controllers.log_LogonController",
                "MetaEdge.MetaAuth.API.Controllers.log_OperationController",
            };

            if (byPassController.Contains(controllerName))
            {
                byPass = true;
            }

            return byPass;
        }


        public static void AddCode(System.Web.Http.Filters.HttpActionExecutedContext actionExecutedContext, ApiClientInfo apiClientInfo, string eventName)
        {
            System.Web.Http.Controllers.HttpActionContext actionContext = actionExecutedContext.ActionContext;
            if (ByPassLog(actionContext)) return;

            string result = string.Empty;
            int dataCount = 0;
            string status = HttpStatusCode.Accepted.ToString();

            if (actionExecutedContext.Exception == null)
            {
                status = actionContext.Response.StatusCode.ToString();

                try
                {
                    var responseResult = string.Empty;
                    if (actionExecutedContext.Response.Content != null)
                    {
                        responseResult = actionExecutedContext.Response.Content.ReadAsStringAsync().Result;

                        if (JObject.Parse(responseResult).GetValue("value") != null)
                        {
                            dataCount = JObject.Parse(responseResult)["value"].Count();
                            result = JObject.Parse(responseResult)["value"].ToString();
                        }
                        else
                        {
                            dataCount = 1;
                            var tempResult = JObject.Parse(responseResult);
                            tempResult.Remove("odata.metadata");
                            result = tempResult.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    result = ex.GetBaseException().Message;
                    if (ex.GetBaseException().InnerException != null)
                    {
                        result = ex.GetBaseException().InnerException.Message;
                    }
                }
            }

            else
            {
                result = actionExecutedContext.Exception.GetBaseException().Message;
                if (actionExecutedContext.Exception.GetBaseException().InnerException != null)
                {
                    result = actionExecutedContext.Exception.GetBaseException().InnerException.Message;
                }

                result = actionExecutedContext.Exception.GetBaseException().Message;
                status = HttpStatusCode.ExpectationFailed.ToString();
            }

            LoggedInfo logInfo = new LoggedInfo();
            logInfo.Command = actionContext.Request.RequestUri.ToString();
            logInfo.Source = apiClientInfo.UserHostAddress;
            logInfo.Target = Environment.MachineName;
            logInfo.Status = status;
            logInfo.Result = result;

            AddOperationLog(actionContext, apiClientInfo, logInfo);
        }

        private static bool MustLog(Logging.LogLevel currentLogLevel)
        {
            string logLevelSetting = string.Empty;
            try
            {
                logLevelSetting = MetaEdge.Registry.AppSettingsFactory.Get("LogLevel");
            }
            catch
            {
                return true;
            }

            if (!string.IsNullOrEmpty(logLevelSetting))
            {
                int logLevelSettingValue = (int)Enum.Parse(currentLogLevel.GetType(), logLevelSetting);

                return (int)currentLogLevel >= logLevelSettingValue;
            }
            return true;
        }
    }
}