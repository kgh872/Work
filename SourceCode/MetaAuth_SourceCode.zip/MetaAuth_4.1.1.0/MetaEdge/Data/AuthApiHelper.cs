﻿using MetaEdge.Web;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace MetaEdge.Data
{
    public class AuthApiHelper
    {
        private static HttpClient _httpClient = null;
        private static readonly object padlock = new object();

        public static HttpClient HttpClientInstnace
        {
            get
            {
                if (_httpClient != null)
                {
                    return _httpClient;
                }

                lock (padlock)
                {
                    if (_httpClient == null)
                    {
                        Uri baseUri = new Uri(AuthUrl);
                        _httpClient = new HttpClient();

                        _httpClient.Timeout = System.Threading.Timeout.InfiniteTimeSpan;
                        _httpClient.BaseAddress = baseUri;

                        //_httpClient.DefaultRequestHeaders.Accept.Add(
                        //    new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                        #region HttpClient 無法反應 DNS 異動的解決方式

                        //設定 1 分鐘沒有活動即關閉連線，預設 -1 (永不關閉)
                        ServicePointManager.FindServicePoint(baseUri)
                        .ConnectionLeaseTimeout = (int)TimeSpan.FromMinutes(1).TotalMilliseconds;
                        //設定 1 分鐘更新 DNS，預設 12000 (2 分鐘)
                        ServicePointManager.DnsRefreshTimeout = (int)TimeSpan.FromMinutes(1).TotalMilliseconds;

                        #endregion
                    }
                }
                return _httpClient;
            }
        }

        public static string AuthUrl
        {
            get
            {
                return MetaEdge.Registry.AppSettingsFactory.Get("AUTHURL");
            }
        }

        public static T[] Get<T>(string oDataUri)
        {
            return Get<T>(oDataUri, ApiClientInfo.Create());
        }

        public static T[] Get<T>(string oDataUri, string ClientInfo)
        {
            try
            {
                HttpResponseMessage response = HttpClientInstnace.GetAsync(oDataUri, x =>
                {
                    x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    x.Headers.Add("WEB-INFO", ClientInfo);
                }).Result;

                response.EnsureSuccessStatusCode();

                JObject content = new JObject();
                if (response.IsSuccessStatusCode)
                {
                    content = response.Content.ReadAsAsync<JObject>().Result;
                }

                return Newtonsoft.Json.JsonConvert.DeserializeObject<T[]>(content["value"].ToString());
            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("AuthApiHelper.Get");
                logger.Error(string.Format("HttpClientInstnace.BaseAddress: {0}, AuthUrl: {1}", HttpClientInstnace.BaseAddress.ToString(), AuthUrl), ex);
                throw ex;
            }
        }

        public static T Post<T>(string oDataUri, string data)
        {
            return Post<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static T Post<T>(string oDataUri, string data, string ClientInfo)
        {
            try
            {
                HttpResponseMessage response = HttpClientInstnace.PostAsJsonAsync(oDataUri, Newtonsoft.Json.Linq.JObject.Parse(data), x =>
                {
                    x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    x.Headers.Add("WEB-INFO", ClientInfo);
                }).Result;
                response.EnsureSuccessStatusCode();

                JObject content = new JObject();
                if (response.IsSuccessStatusCode)
                {
                    content = response.Content.ReadAsAsync<JObject>().Result;
                    if (content != null)
                    {
                        if (content.ToString().Contains("odata.metadata"))
                        {
                            content.Remove("odata.metadata");
                        }
                    }
                }

                return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("AuthApiHelper.Post");
                logger.Error(string.Format("HttpClientInstnace.BaseAddress: {0}, AuthUrl: {1}", HttpClientInstnace.BaseAddress.ToString(), AuthUrl), ex);
                throw ex;
            }
        }

        // 因為 data 含有 Json 的資料，若把 data 序列化為 string，再 Newtonsoft.Json.Linq.JObject.Parse 轉成 Json，會造成格式錯誤的問題
        // 如：log_Operation
        public static T Post<T>(string oDataUri, JObject data)
        {
            return Post<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static T Post<T>(string oDataUri, JObject data, string ClientInfo)
        {
            try
            {
                HttpResponseMessage response = HttpClientInstnace.PostAsJsonAsync(oDataUri, data, x =>
                {
                    x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    x.Headers.Add("WEB-INFO", ClientInfo);
                }).Result;
                response.EnsureSuccessStatusCode();

                JObject content = new JObject();
                if (response.IsSuccessStatusCode)
                {
                    content = response.Content.ReadAsAsync<JObject>().Result;
                    if (content != null)
                    {
                        if (content.ToString().Contains("odata.metadata"))
                        {
                            content.Remove("odata.metadata");
                        }
                    }
                }

                return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("AuthApiHelper.Post");
                logger.Error(string.Format("HttpClientInstnace.BaseAddress: {0}, AuthUrl: {1}", HttpClientInstnace.BaseAddress.ToString(), AuthUrl), ex);
                throw ex;
            }
        }

        public static void Put<T>(string oDataUri, string data)
        {
            Put<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static void Put<T>(string oDataUri, string data, string ClientInfo)
        {
            try
            {
                HttpResponseMessage response = HttpClientInstnace.PostAsJsonAsync(oDataUri, Newtonsoft.Json.Linq.JObject.Parse(data), x =>
                {
                    x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    x.Headers.Add("WEB-INFO", ClientInfo);
                    x.Headers.Add("X-HTTP-Method-Override", "PUT");
                }).Result;

                response.EnsureSuccessStatusCode();

                JObject content = new JObject();
                if (response.IsSuccessStatusCode)
                {
                    content = response.Content.ReadAsAsync<JObject>().Result;
                    //content.Remove("odata.metadata");
                }

                //return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());

            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("AuthApiHelper.Put");
                logger.Error(string.Format("HttpClientInstnace.BaseAddress: {0}, AuthUrl: {1}", HttpClientInstnace.BaseAddress.ToString(), AuthUrl), ex);
                throw ex;
            }
        }

        public static void Patch<T>(string oDataUri, string data)
        {
            Patch<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static void Patch<T>(string oDataUri, string data, string ClientInfo)
        {
            try
            {
                HttpResponseMessage response = HttpClientInstnace.PostAsJsonAsync(oDataUri, Newtonsoft.Json.Linq.JObject.Parse(data), x =>
                {
                    x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    x.Headers.Add("WEB-INFO", ClientInfo);
                    x.Headers.Add("X-HTTP-Method-Override", "PATCH");
                }).Result;

                response.EnsureSuccessStatusCode();

                JObject content = new JObject();
                if (response.IsSuccessStatusCode)
                {
                    content = response.Content.ReadAsAsync<JObject>().Result;
                    //content.Remove("odata.metadata");
                }

                //return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("AuthApiHelper.Patch");
                logger.Error(string.Format("HttpClientInstnace.BaseAddress: {0}, AuthUrl: {1}", HttpClientInstnace.BaseAddress.ToString(), AuthUrl), ex);
                throw ex;
            }
        }

        public static System.Net.HttpStatusCode Delete(string oDataUri, string ClientInfo)
        {
            try
            {
                HttpResponseMessage response = HttpClientInstnace.PostAsJsonAsync(oDataUri, oDataUri, x =>
                {
                    x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    x.Headers.Add("WEB-INFO", ClientInfo);
                    x.Headers.Add("X-HTTP-Method-Override", "DELETE");
                }).Result;

                response.EnsureSuccessStatusCode();

                JObject content = new JObject();
                if (response.IsSuccessStatusCode)
                {
                    content = response.Content.ReadAsAsync<JObject>().Result;
                }

                return response.StatusCode;
            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("AuthApiHelper.Delete");
                logger.Error(string.Format("HttpClientInstnace.BaseAddress: {0}, AuthUrl: {1}", HttpClientInstnace.BaseAddress.ToString(), AuthUrl), ex);
                throw ex;
            }
        }

        public static string SendSingleRequest(HttpContext context, ODataItem item)
        {
            string result = string.Empty;

            Action<HttpRequestMessage> AddHeader = new Action<HttpRequestMessage>(x =>
            {
                x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                x.Headers.Add("WEB-INFO", ApiClientInfo.Create());
            });

            Task<HttpResponseMessage> responseTask = null;
            HttpResponseMessage response = null;

            switch (item.Method.ToUpper())
            {
                case "GET":
                    //if (item.Uri.Contains("Security_Roles_List"))
                    //{
                    //    response = HttpClientInstnace.GetAsync(item.Uri, x =>
                    //    {
                    //        x.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    //        x.Headers.Add("WEB-INFO", ApiClientInfo.Create());
                    //        System.Threading.Thread.Sleep(15000);
                    //    }).Result;

                    //}
                    //else
                    //{
                    responseTask = HttpClientInstnace.GetAsync(item.Uri, AddHeader);
                    //response = HttpClientInstnace.GetAsync(item.Uri, AddHeader).Result;
                    //}
                    break;

                case "POST":
                    responseTask = HttpClientInstnace.PostAsJsonAsync(item.Uri, item.Data, AddHeader);
                    //response = HttpClientInstnace.PostAsJsonAsync(item.Uri, item.Data, AddHeader).Result;
                    break;

                case "PUT":
                    responseTask = HttpClientInstnace.PutAsJsonAsync(item.Uri, item.Data, AddHeader);
                    //response = HttpClientInstnace.PutAsJsonAsync(item.Uri, item.Data, AddHeader).Result;
                    break;

                case "PATCH":
                    responseTask = HttpClientInstnace.PatchAsJsonAsync(item.Uri, item.Data, AddHeader);
                    //response = HttpClientInstnace.PatchAsJsonAsync(item.Uri, item.Data, AddHeader).Result;
                    break;

                case "DELETE":
                    if (item.Data.Count == 0)
                    {
                        responseTask = HttpClientInstnace.DeleteAsync(item.Uri, AddHeader);
                        //response = HttpClientInstnace.DeleteAsync(item.Uri, AddHeader).Result;
                    }
                    else
                    {
                        responseTask = HttpClientInstnace.SendAsync(new HttpMethod(item.Method), item.Uri, item.Data, AddHeader);
                        //response = HttpClientInstnace.SendAsync(new HttpMethod(item.Method), item.Uri, item.Data, AddHeader).Result;
                    }
                    break;

                default:
                    responseTask = HttpClientInstnace.GetAsync(item.Uri, AddHeader);
                    //response = HttpClientInstnace.GetAsync(item.Uri, AddHeader).Result;
                    break;

            }

            string errMessage = null;
            string contents = null;
            try
            {
                response = responseTask.Result;
            }
            catch (Exception ex)
            {
                JObject jError = new JObject();
                jError.Add("value", "");
                jError.Add("ODataItem", Newtonsoft.Json.JsonConvert.SerializeObject(item));
                errMessage = Newtonsoft.Json.JsonConvert.SerializeObject(jError);

                Exception ex2 = new Exception(errMessage, ex);

                MetaEdge.Utility.ExceptionUtility.LogException(ex2, ex2.GetType().FullName);
                LogHelper.WriteAuditLog(item, errMessage, "Fail");

                throw ex2;
            }


            try
            {
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                errMessage = ex.GetBaseException().Message;
                contents = response.Content.ReadAsStringAsync().Result;

                try
                {
                    if (contents.IndexOf("<!DOCTYPE html>") == 0)
                    {
                        errMessage = contents.Substring(contents.IndexOf("<title>") + 7, contents.IndexOf("</title>") - (contents.IndexOf("<title>") + 7));
                    }
                    else if (((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(contents))["value"] != null)
                    {
                        errMessage = ((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(contents))["value"].ToString();
                        errMessage = ((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(errMessage))["Message"].ToString();
                    }
                    else if (((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(contents))["odata.error"]["innererror"] != null)
                    {
                        errMessage = ((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(contents))["odata.error"]["innererror"]["internalexception"]["message"].ToString();
                    }
                    else if (((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(contents))["odata.error"]["message"] != null)
                    {
                        errMessage = ((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(contents))["odata.error"]["message"].ToString();
                        errMessage = ((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(errMessage))["value"].ToString();
                        errMessage = ((JObject)Newtonsoft.Json.JsonConvert.DeserializeObject(errMessage))["Message"].ToString();
                    }
                }
                catch
                { }

                JObject jError = new JObject();
                jError.Add("Message", errMessage);
                jError.Add("value", "");
                jError.Add("ODataItem", Newtonsoft.Json.JsonConvert.SerializeObject(item));
                errMessage = Newtonsoft.Json.JsonConvert.SerializeObject(jError);

                HttpException hex = new HttpException((int)response.StatusCode, errMessage, ex);

                MetaEdge.Utility.ExceptionUtility.LogException(hex, hex.GetType().FullName);
                LogHelper.WriteAuditLog(item, errMessage, "Fail");

                throw hex;
            }

            if (response.IsSuccessStatusCode)
            {
                var asyncResult = response.Content.ReadAsAsync<JObject>().Result;
                if (asyncResult != null)
                {
                    result = asyncResult.ToString();
                }
            }
            response.Dispose();

            LogHelper.WriteAuditLog(item, result, "Success");

            return result;
        }

        public static string WebUrl
        {
            get
            {
                string apiUrl = MetaEdge.Registry.AppSettingsFactory.Get("WEBURL");

                if (string.IsNullOrEmpty(apiUrl))
                {
                    apiUrl = string.Format("{0}://{1}:{2}/{3}"
                        , HttpContext.Current.Request.Url.Scheme
                        , HttpContext.Current.Request.Url.Host
                        , HttpContext.Current.Request.Url.Port
                        , HttpContext.Current.Request.Url.Segments[1]);
                }
                else
                {
                    Uri uriResult;
                    bool isValidUrl = Uri.TryCreate(apiUrl, UriKind.Absolute, out uriResult)
                        && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

                    if (!isValidUrl)
                    {
                        apiUrl = string.Format("{0}://{1}:{2}/{3}"
                        , HttpContext.Current.Request.Url.Scheme
                        , HttpContext.Current.Request.Url.Host
                        , HttpContext.Current.Request.Url.Port
                        , apiUrl);
                    }
                }
                return apiUrl;
            }
        }

        public static string ApiUrl
        {
            get
            {
                string apiUrl = MetaEdge.Registry.AppSettingsFactory.Get("APIURL");

                if (string.IsNullOrEmpty(apiUrl))
                {
                    apiUrl = string.Format("{0}://{1}:{2}/{3}API/odata/"
                        , HttpContext.Current.Request.Url.Scheme
                        , HttpContext.Current.Request.Url.Host
                        , HttpContext.Current.Request.Url.Port
                        , HttpContext.Current.Request.Url.Segments[1].Replace("/", ""));
                }
                else
                {
                    Uri uriResult;
                    bool isValidUrl = Uri.TryCreate(apiUrl, UriKind.Absolute, out uriResult)
                        && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps);

                    if (!isValidUrl)
                    {
                        apiUrl = string.Format("{0}://{1}:{2}/{3}API/odata/"
                        , HttpContext.Current.Request.Url.Scheme
                        , HttpContext.Current.Request.Url.Host
                        , HttpContext.Current.Request.Url.Port
                        , apiUrl);
                    }
                }
                return apiUrl;
            }
        }
    }
}
