﻿using MetaEdge.Web;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace MetaEdge.Data
{
    public class ApproveApiHelper
    {
        public static T[] Get<T>(string oDataUri)
        {
            try
            {
                return Get<T>(oDataUri, ApiClientInfo.Create());
            }
            catch (Exception ex)
            {
                Exception newEx = ex;
                if (ex.InnerException != null)
                {
                    newEx = ex.InnerException;
                }
                throw newEx;
            }
        }

        public static T[] Get<T>(string oDataUri, string ClientInfo)
        {
            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Add("WEB-INFO", ClientInfo);

            HttpResponseMessage response = client.GetAsync(serviceAddress + oDataUri, HttpCompletionOption.ResponseContentRead).Result;
            response.EnsureSuccessStatusCode();

            JObject content = new JObject();
            if (response.IsSuccessStatusCode)
            {
                content = response.Content.ReadAsAsync<JObject>().Result;
            }

            return Newtonsoft.Json.JsonConvert.DeserializeObject<T[]>(content["value"].ToString());
        }

        public static T Post<T>(string oDataUri, string data)
        {
            return Post<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static T Post<T>(string oDataUri, string data, string ClientInfo)
        {
            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Add("WEB-INFO", ClientInfo);

            HttpRequestMessage request =
                        new HttpRequestMessage(new HttpMethod("POST"), serviceAddress + oDataUri)
                        {
                            Content = new ObjectContent<JObject>(Newtonsoft.Json.Linq.JObject.Parse(data), new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                        };

            HttpResponseMessage response = client.PostAsync(oDataUri, request.Content).Result;
            response.EnsureSuccessStatusCode();

            JObject content = new JObject();
            if (response.IsSuccessStatusCode)
            {
                content = response.Content.ReadAsAsync<JObject>().Result;
                if (content != null)
                {
                    if (content.ToString().Contains("odata.metadata"))
                    {
                        content.Remove("odata.metadata");
                    }
                }
            }

            return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
        }

        // 因為 data 含有 Json 的資料，若把 data 序列化為 string，再 Newtonsoft.Json.Linq.JObject.Parse 轉成 Json，會造成格式錯誤的問題
        // 如：log_Operation
        public static T Post<T>(string oDataUri, JObject data)
        {
            return Post<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static T Post<T>(string oDataUri, JObject data, string ClientInfo)
        {
            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Add("WEB-INFO", ClientInfo);

            HttpRequestMessage request =
                        new HttpRequestMessage(new HttpMethod("POST"), serviceAddress + oDataUri)
                        {
                            Content = new ObjectContent<JObject>(data, new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                        };

            HttpResponseMessage response = client.PostAsync(oDataUri, request.Content).Result;
            response.EnsureSuccessStatusCode();

            JObject content = new JObject();
            if (response.IsSuccessStatusCode)
            {
                content = response.Content.ReadAsAsync<JObject>().Result;
                if (content != null)
                {
                    if (content.ToString().Contains("odata.metadata"))
                    {
                        content.Remove("odata.metadata");
                    }
                }
            }

            return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
        }

        public static void Put<T>(string oDataUri, string data)
        {
            Put<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static void Put<T>(string oDataUri, string data, string ClientInfo)
        {
            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Add("WEB-INFO", ClientInfo);

            HttpRequestMessage request =
                        new HttpRequestMessage(new HttpMethod("POST"), serviceAddress + oDataUri)
                        {
                            Content = new ObjectContent<JObject>(Newtonsoft.Json.Linq.JObject.Parse(data), new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                        };

            HttpResponseMessage response = client.PutAsync(oDataUri, request.Content).Result;
            response.EnsureSuccessStatusCode();

            JObject content = new JObject();
            if (response.IsSuccessStatusCode)
            {
                content = response.Content.ReadAsAsync<JObject>().Result;
                //content.Remove("odata.metadata");
            }

            //return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
        }

        public static void Patch<T>(string oDataUri, string data)
        {
            Patch<T>(oDataUri, data, ApiClientInfo.Create());
        }

        public static void Patch<T>(string oDataUri, string data, string ClientInfo)
        {
            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Add("WEB-INFO", ClientInfo);

            HttpRequestMessage request =
                        new HttpRequestMessage(new HttpMethod("PATCH"), serviceAddress + oDataUri)
                        {
                            Content = new ObjectContent<JObject>(Newtonsoft.Json.Linq.JObject.Parse(data), new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                        };

            //HttpResponseMessage response = client.PutAsync(oDataUri, request.Content).Result;
            HttpResponseMessage response = PatchAsync(client, new Uri(serviceAddress + oDataUri), request.Content).Result;
            response.EnsureSuccessStatusCode();

            JObject content = new JObject();
            if (response.IsSuccessStatusCode)
            {
                content = response.Content.ReadAsAsync<JObject>().Result;
                //content.Remove("odata.metadata");
            }

            //return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(content.ToString());
        }

        public static System.Net.HttpStatusCode Delete(string oDataUri)
        {
            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            client.DefaultRequestHeaders.Add("WEB-INFO", ApiClientInfo.Create());

            HttpResponseMessage response = client.DeleteAsync(serviceAddress + oDataUri).Result;
            response.EnsureSuccessStatusCode();

            JObject content = new JObject();
            if (response.IsSuccessStatusCode)
            {
                content = response.Content.ReadAsAsync<JObject>().Result;
            }

            return response.StatusCode;
        }

        public static string SendSingleRequest(HttpContext context, ODataItem item)
        {
            string result = string.Empty;

            string serviceAddress = MetaEdge.Registry.AppSettingsFactory.Get("APPRURL");

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(serviceAddress);

            client.DefaultRequestHeaders.Accept.Add(
                new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = new HttpResponseMessage();

            HttpRequestMessage request =
                        new HttpRequestMessage(new HttpMethod(item.Method), item.Uri)
                        {
                            Content = new ObjectContent<JObject>(item.Data, new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                        };

            client.DefaultRequestHeaders.Add("WEB-INFO", ApiClientInfo.Create());

            switch (item.Method.ToUpper())
            {
                case "GET":
                    response = client.GetAsync(item.Uri).Result;
                    break;

                case "POST":
                    response = client.PostAsync(item.Uri, request.Content).Result;
                    break;

                case "PUT":
                    response = client.PutAsync(item.Uri, request.Content).Result;
                    break;

                case "PATCH":
                    response = PatchAsync(client, new Uri(item.Uri), request.Content).Result;
                    break;

                case "DELETE":
                    if (item.Data.Count == 0)
                    {
                        response = client.DeleteAsync(item.Uri).Result;
                    }
                    else
                    {
                        response = client.SendAsync(request).Result;
                    }
                    break;

                default:
                    response = client.GetAsync(item.Uri).Result;
                    break;
            }
            try
            {
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                string errMessage = ex.Message;

                try
                {
                    errMessage = System.Text.Encoding.Default.GetString(Convert.FromBase64String(response.ReasonPhrase));
                    errMessage = System.Web.HttpUtility.UrlDecode(errMessage);
                }
                catch { }

                LogHelper.WriteAuditLog(item, errMessage, "Fail");
                HttpException hex = new HttpException((int)response.StatusCode, errMessage);

                throw hex;
            }

            if (response.IsSuccessStatusCode)
            {
                var asyncResult = response.Content.ReadAsAsync<JObject>().Result;
                if (asyncResult != null)
                {
                    result = asyncResult.ToString();
                }
            }
            response.Dispose();

            LogHelper.WriteAuditLog(item, result, "Success");

            return result;
        }

        public static async Task<HttpResponseMessage> PatchAsync(HttpClient client, Uri requestUri, HttpContent content)
        {
            var method = new HttpMethod("PATCH");

            var request = new HttpRequestMessage(method, requestUri)
            {
                Content = content
            };

            HttpResponseMessage response = new HttpResponseMessage();
            // In case you want to set a timeout
            //CancellationToken cancellationToken = new CancellationTokenSource(60).Token;

            try
            {
                response = client.SendAsync(request).Result;
                // If you want to use the timeout you set
                //response = await client.SendRequestAsync(request).AsTask(cancellationToken);
            }
            catch (TaskCanceledException e)
            {
                //Debug.WriteLine("ERROR: " + e.ToString());
            }

            return response;
        }
    }
}
