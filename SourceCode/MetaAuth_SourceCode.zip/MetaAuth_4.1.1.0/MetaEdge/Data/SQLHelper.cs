﻿using System;
using System.Data;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.Remoting;
using System.Collections.Specialized;
using System.Collections;
using MetaEdge.Security;
using System.Threading.Tasks;
using MetaEdge.Utility;

namespace MetaEdge.Data
{

    /// <summary>
    /// 要調整ExecQueryProcedure     LBOTSSO.DataBaseUser有參照
    /// 要調整ExecNonQueryProcedure  LBOTSSO.SSOClient有參照
    /// </summary>
    public class SQLHelper
    {
        public static DataTable ExecTextCommand(string connectionString, string command, SqlParameter[] parameters)//執行單一SQL COMMAND並傳回結果
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(command, conn);
            cmd.CommandType = CommandType.Text;
            cmd.CommandTimeout = 1000;
            cmd.Parameters.AddRange(parameters);
            SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            DataTable table = new DataTable();
            table.Load(rd);
            rd.Close();

            return table;
        }

        public static DataTable ExecTextCommand(string connectionString, string command)//執行單一SQL COMMAND並傳回結果
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd = new SqlCommand(command, conn);
            cmd.CommandType = CommandType.Text;
            cmd.CommandTimeout = 1000;
            SqlDataReader rd = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            DataTable table = new DataTable();
            table.Load(rd);
            rd.Close();

            return table;
        }


        public static void ExecNoneQuery(string connectionString, string command)//執行SQL,沒有回傳值
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand(command, conn);
            cmd.CommandType = CommandType.Text;
            cmd.CommandTimeout = 1000;
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static object ExecScarlar(string connectionString, string command)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand(command, conn);
            cmd.CommandType = CommandType.Text;
            cmd.CommandTimeout = 1000;
            object obj = cmd.ExecuteScalar();
            conn.Close();
            return obj;
        }

        public static object ExecQueryProcedure(string connectionString, string procName, params SqlParameter[] parameters)//執行帶有參數的查詢SP
        {
            //20080111將前端網頁傳回的null改成DBNull
           
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            SqlCommand cmd = new SqlCommand(procName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1000;
            cmd.Parameters.AddRange(parameters);

            SqlDataReader rd = null;
            try
            {
                rd = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException Sqlex)
            {
                throw Sqlex;
            }

            DataTable dt = new DataTable();
            dt.Load(rd);
            foreach (DataColumn c in dt.Columns)
            {
                c.AllowDBNull = true;
            }
            return dt;
        }

        public static int ExecNonQueryProcedure(string connectionString, string procName, params SqlParameter[] parameters)
        {
            //執行帶有參數的非查詢的SP
            SqlConnection conn = new SqlConnection(connectionString);
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            SqlCommand cmd = new SqlCommand(procName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1000;
            cmd.Parameters.AddRange(parameters);
            int rt = 0;
            try
            {
                rt = cmd.ExecuteNonQuery();
            }
            catch (SqlException Sqlex)
            {
                ApplicationException appex = new ApplicationException("", Sqlex);
                appex.Data.Add("Conn", "disconent");
                //appex.Data.Add("", "");
                //throw DAHelper.NormalException(Sqlex);
                throw appex;
            }
            finally
            {
                conn.Close();
            }
            return rt;
        }

        public static int ExecSPandGetReturnValue(string connectionString, string procName, params SqlParameter[] parameters)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand(procName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1000;
            cmd.Parameters.AddRange(parameters);
            SqlParameter rtParam = cmd.Parameters.Add("@ReturnValue", SqlDbType.Int);
            rtParam.Direction = ParameterDirection.ReturnValue;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (SqlException Sqlex)
            {
                throw Sqlex;
            }
            finally
            {
                conn.Close();
            }
            return (int)cmd.Parameters["@ReturnValue"].Value;
        }
        public static SqlParameter[] ExecSPandGetOutputValue(string connectionString, string procName, params SqlParameter[] parameters)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand cmd = new SqlCommand(procName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 1000;
            cmd.Parameters.AddRange(parameters);

            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (SqlException Sqlex)
            {
                throw Sqlex;
            }
            finally
            {
                conn.Close();
            }
            return parameters;
        }

        /// <summary>
        /// Execute a SqlCommand (that returns no resultset) against the specified SqlTransaction
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  int result = ExecuteNonQuery(trans, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="transaction">A valid SqlTransaction</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">An array of SqlParamters used to execute the command</param>
        /// <returns>An int representing the number of rows affected by the command</returns>
        public static int ExecNonQueryWithTrans(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            if (transaction == null) throw new ArgumentNullException("transaction");
            if (transaction != null && transaction.Connection == null) throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");

            // Create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            cmd.CommandTimeout = 3600;

            bool mustCloseConnection = false;
            PrepareCommand(cmd, transaction.Connection, transaction, commandType, commandText, commandParameters, out mustCloseConnection);

            // Finally, execute the command
            int retval = cmd.ExecuteNonQuery();

            // Detach the SqlParameters from the command object, so they can be used again
            cmd.Parameters.Clear();
            return retval;
        }

        /// <summary>
        /// This method opens (if necessary) and assigns a connection, transaction, command type and parameters 
        /// to the provided command
        /// </summary>
        /// <param name="command">The SqlCommand to be prepared</param>
        /// <param name="connection">A valid SqlConnection, on which to execute this command</param>
        /// <param name="transaction">A valid SqlTransaction, or 'null'</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">An array of SqlParameters to be associated with the command or 'null' if no parameters are required</param>
        /// <param name="mustCloseConnection"><c>true</c> if the connection was opened by the method, otherwose is false.</param>
        public static void PrepareCommand(SqlCommand command, SqlConnection connection, SqlTransaction transaction, CommandType commandType, string commandText, SqlParameter[] commandParameters, out bool mustCloseConnection)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandText == null || commandText.Length == 0) throw new ArgumentNullException("commandText");

            // If the provided connection is not open, we will open it
            if (connection.State != ConnectionState.Open)
            {
                mustCloseConnection = true;
                connection.Open();
            }
            else
            {
                mustCloseConnection = false;
            }

            // Associate the connection with the command
            command.Connection = connection;

            // Set the command text (stored procedure name or SQL statement)
            command.CommandText = commandText;

            // If we were provided a transaction, assign it
            if (transaction != null)
            {
                if (transaction.Connection == null) throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
                command.Transaction = transaction;
            }

            // Set the command type
            command.CommandType = commandType;

            // Attach the command parameters if they are provided
            if (commandParameters != null)
            {
                AttachParameters(command, commandParameters);
            }
            return;
        }

        /// <summary>
        /// This method is used to attach array of SqlParameters to a SqlCommand.
        /// 
        /// This method will assign a value of DbNull to any parameter with a direction of
        /// InputOutput and a value of null.  
        /// 
        /// This behavior will prevent default values from being used, but
        /// this will be the less common case than an intended pure output parameter (derived as InputOutput)
        /// where the user provided no input value.
        /// </summary>
        /// <param name="command">The command to which the parameters will be added</param>
        /// <param name="commandParameters">An array of SqlParameters to be added to command</param>
        public static void AttachParameters(SqlCommand command, SqlParameter[] commandParameters)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput ||
                            p.Direction == ParameterDirection.Input) &&
                            (p.Value == null))
                        {
                            p.Value = DBNull.Value;
                        }
                        command.Parameters.Add(p);
                    }
                }
            }
        }

        public static void ExecBulkCopy(string connectionString, string dbTableName, DataTable dtSource, List<SqlBulkCopyColumnMapping> sbc)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            using (SqlBulkCopy sqlBC = new SqlBulkCopy(conn))
            {
                //設定一個批次量寫入多少筆資料
                sqlBC.BatchSize = 1000;
                //設定逾時的秒數
                sqlBC.BulkCopyTimeout = 120;

                //設定要寫入的資料表
                sqlBC.DestinationTableName = "dbo." + dbTableName;


                //DataTable 與 資料表欄位對應
                foreach (SqlBulkCopyColumnMapping bc in sbc)
                {
                    sqlBC.ColumnMappings.Add(bc);
                }

                //開始寫入
                sqlBC.WriteToServer(dtSource);
            }
            conn.Dispose();
        }

        public static void ExecuteNonQueryWithParallel(string dbname, List<string> commandTextList)
        {
            ExecuteNonQueryWithParallel(dbname, commandTextList, string.Empty);
        }

        public static void ExecuteNonQueryWithParallel(string dbname, List<string> commandTextList, string exceptionCommandText)
        {
            try
            {
                Parallel.For(0, commandTextList.Count,
                    delegate(int i)
                    {
                        try
                        {
                            // 執行命令
                            ExecuteNonQuery(dbname, commandTextList[i]);
                        }
                        catch (Exception ex)
                        {
                            // 發生例外執行命令
                            if (!string.IsNullOrEmpty(exceptionCommandText))
                            {
                                ExecuteNonQuery(dbname, exceptionCommandText);
                            }
                            else
                            {
                                Logging.LoggerManager.GetCurrentLogger("SQLHelper").Error(ex);
                                //Logger.LogToFile(ex);
                            }
                        }
                    }
                );
            }
            catch (Exception e)
            { 
                throw new Exception("MetaEdge.SQLHelper.ExecuteNonQueryWithParallel", e); 
            }
        }

        public static void ExecuteNonQuery(string connectionString, string CommandText)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(CommandText, conn);
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 1000000;
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

    }
}
