using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace MetaEdge.Security
{
    public class AESDecryptor
    {
        private static string rgbKey = MetaEdge.Registry.AppSettingsFactory.Get("rbgKey");
        /// TripleDES�[�K�p�_
        /// </summary>
        public static string RgbKey
        {
            set { rgbKey = value; }
        }

        private static string rgbIV = MetaEdge.Registry.AppSettingsFactory.Get("rbgIV");
        /// <summary>
        /// TripleDES��l�ƦV�q
        /// </summary>
        public static string RgbIV
        {
            set { rgbIV = value; }
        }

        public static string DecryptTextFromMemory(byte[] Data, byte[] Key, byte[] IV)
        {
            try
            {
                string plaintext = null;

                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    AES.KeySize = 256;

                    ICryptoTransform decryptor = AES.CreateDecryptor(Key, IV);

                    using (MemoryStream msDecrypt = new MemoryStream(Data))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                plaintext = srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }

                return plaintext;
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }

        /// <summary>
        /// �ǤJ�r��i��ѱK�C
        /// </summary>
        /// <param name="EncryptingString"></param>
        /// <returns></returns>
        public static string Decrypt(string DataString)
        {
            return DecryptTextFromMemory(Convert.FromBase64String(DataString), Convert.FromBase64String(rgbKey), Convert.FromBase64String(rgbIV));
        }
    }
}
