using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace MetaEdge.Security
{
    public class TripleDESDecrytor
    {
        private static string rgbKey = MetaEdge.Registry.AppSettingsFactory.Get("rbgKey");
        /// TripleDES�[�K�p�_
        /// </summary>
        public static string RgbKey
        {
            set { rgbKey = value; }
        }

        private static string rgbIV = MetaEdge.Registry.AppSettingsFactory.Get("rbgIV");
        /// <summary>
        /// TripleDES��l�ƦV�q
        /// </summary>
        public static string RgbIV
        {
            set { rgbIV = value; }
        }

        public static string DecryptTextFromMemory(byte[] Data, byte[] Key, byte[] IV)
        {
            try
            {
                // Create a new MemoryStream using the passed 
                // array of encrypted data.
                MemoryStream msDecrypt = new MemoryStream(Data);

                // Create a CryptoStream using the MemoryStream 
                // and the passed key and initialization vector (IV).
                CryptoStream csDecrypt = new CryptoStream(msDecrypt,
                    new TripleDESCryptoServiceProvider().CreateDecryptor(Key, IV),
                    CryptoStreamMode.Read);

                // Create buffer to hold the decrypted data.
                byte[] fromEncrypt = new byte[Data.Length];

                // Read the decrypted data out of the crypto stream
                // and place it into the temporary buffer.
                csDecrypt.Read(fromEncrypt, 0, fromEncrypt.Length);

                //Convert the buffer into a string and return it.
                return new ASCIIEncoding().GetString(fromEncrypt).Replace("\0","");
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }
        }

        /// <summary>
        /// �ǤJ�r��i��ѱK�C
        /// </summary>
        /// <param name="EncryptingString"></param>
        /// <returns></returns>
        public static string Decrypt(string DataString)
        {
            return DecryptTextFromMemory(Convert.FromBase64String(DataString), Convert.FromBase64String(rgbKey), Convert.FromBase64String(rgbIV));
        }
    }
}
