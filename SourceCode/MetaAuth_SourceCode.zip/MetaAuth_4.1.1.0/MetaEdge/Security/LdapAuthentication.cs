﻿using System;
using System.DirectoryServices;
using System.Text;
using System.Collections.Generic;

namespace MetaEdge.Security
{
    public class LdapAuthentication
    {
        private string _path;

        private string _userid;
        private string _username;
        private string _pwd;
        private List<string> _domain;
        private string _email;
        private string _comment;

        private string UserId
        {
            get
            {
                return _userid;
            }
            set
            {
                _userid = value;
            }
        }

        private string strPwd
        {
            get
            {
                return _pwd;
            }
            set
            {
                _pwd = value;
            }
        }

        public string UserName
        {
            get
            {
                return _username;
            }
            set
            {
                _username = value;
            }
        }

        public List<string> Domain
        {
            get
            {
                return _domain;
            }
            set
            {
                _domain = value;
            }
        }

        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }

        public string Comment
        {
            get
            {
                return _comment;
            }
            set
            {
                _comment = value;
            }
        }

        public LdapAuthentication(string path)
        {
            _path = MakeUpAdPath(path);
        }

        protected string MakeUpAdPath(string domain)
        {
            StringBuilder sb = new StringBuilder("GC://");
            foreach (string dc in domain.Split('.'))
            {
                sb.AppendFormat("dc={0},", dc);
            }
            return sb.ToString().TrimEnd(',');
        }

        public List<Dictionary<string, string>> GetUserInfo(string domain, string userid)
        {
            List<Dictionary<string, string>> userinfoList = new List<Dictionary<string, string>>();

            DirectoryEntry ent = new DirectoryEntry(MakeUpAdPath(domain));
            DirectorySearcher dirsearcher = new DirectorySearcher(ent);

            dirsearcher.Filter = string.Format("(sAMAccountName={0})", userid);
            dirsearcher.SearchScope = SearchScope.Subtree;
            dirsearcher.PropertiesToLoad.Add("cn");
            dirsearcher.PropertiesToLoad.Add("givenName");
            dirsearcher.PropertiesToLoad.Add("telephoneNumber");

            SearchResultCollection results = dirsearcher.FindAll();

            foreach (SearchResult result in results)
            {
                System.DirectoryServices.PropertyCollection pc = result.GetDirectoryEntry().Properties;
                Dictionary<string, string> dic = new Dictionary<string, string>();
                string key = string.Empty;
                string val = string.Empty;

                foreach (object obj in pc.PropertyNames)
                {
                    key = obj.ToString();
                    val = pc[key] == null ? string.Empty : pc[key].Value.ToString();

                    dic[key] = val;
                }

                userinfoList.Add(dic);
            }

            return userinfoList;
        }

        /// <summary>
        /// If User ID is exists in domain, LdapAuthentication load User Information.
        /// </summary>
        /// <param name="domain"></param>
        /// <param name="userid"></param>
        /// <returns></returns>
        public bool Exists(string domain, string userid)
        {
            List<Dictionary<string, string>> userinfoList = new List<Dictionary<string, string>>();
            try
            {
                userinfoList = GetUserInfo(domain, userid);
            }
            catch (Exception ex)
            {
                string s = ex.GetBaseException().Message;
                return false;
            }

            if (userinfoList.Count == 0)
            {
                throw new Exception("The user is not exists in domain!");
            }

            Dictionary<string, string> dic = userinfoList[0];

            foreach (KeyValuePair<string, string> kv in dic)
            {
                switch (kv.Key)
                {
                    case "displayName":
                        UserName = kv.Value;
                        break;
                    case "mail":
                        Email = kv.Value;
                        break;
                    case "description":
                        Comment = kv.Value;
                        break;
                    default:
                        break;
                }
            }

            Domain = new List<string>();
            foreach (Dictionary<string, string> dic0 in userinfoList)
            {
                foreach (KeyValuePair<string, string> kv in dic0)
                {
                    if (kv.Key == "distinguishedName")
                    {
                        string[] strDomain = kv.Value.Split(',');
                        string tar = string.Empty;

                        foreach (string s in strDomain)
                        {
                            if (s.StartsWith("DC="))
                            {
                                tar += s.Replace("DC=", "") + ".";
                            }
                        }
                        Domain.Add(tar.TrimEnd('.'));
                    }
                }
            }

            return true;
        }

        public bool IsAuthenticated(string domain, string username, string pwd)
        {
            string domainAndUsername = domain + @"\" + username;

            DirectoryEntry entry = new DirectoryEntry(MakeUpAdPath(domain), domainAndUsername, pwd);

            try
            {
                DirectorySearcher search = new DirectorySearcher(entry);

                search.Filter = "(SAMAccountName=" + username + ")";
                SearchResult result = search.FindOne();

                if (null == result)
                { return false; }

                UserName = result.Properties["displayName"].ToString();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return true;
        }
    }
}