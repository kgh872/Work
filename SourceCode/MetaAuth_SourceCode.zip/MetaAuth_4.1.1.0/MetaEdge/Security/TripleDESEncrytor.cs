using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace MetaEdge.Security
{
    public class TripleDESEncrytor
    {
        private static string rgbKey = MetaEdge.Registry.AppSettingsFactory.Get("rbgKey");
        /// TripleDES�[�K�p�_
        /// </summary>
        public static string RgbKey
        {
            set { rgbKey = value; }
        }

        private static string rgbIV = MetaEdge.Registry.AppSettingsFactory.Get("rbgIV");
        /// <summary>
        /// TripleDES��l�ƦV�q
        /// </summary>
        public static string RgbIV
        {
            set { rgbIV = value; }
        }

        public static byte[] EncryptTextToMemory(string Data, byte[] Key, byte[] IV)
        {
            try
            {
                // Create a MemoryStream.
                MemoryStream mStream = new MemoryStream();

                // Create a CryptoStream using the MemoryStream 
                // and the passed key and initialization vector (IV).
                CryptoStream cStream = new CryptoStream(mStream,
                    new TripleDESCryptoServiceProvider().CreateEncryptor(Key, IV),
                    CryptoStreamMode.Write);

                // Convert the passed string to a byte array.
                byte[] toEncrypt = new ASCIIEncoding().GetBytes(Data);

                // Write the byte array to the crypto stream and flush it.
                cStream.Write(toEncrypt, 0, toEncrypt.Length);
                cStream.FlushFinalBlock();

                // Get an array of bytes from the 
                // MemoryStream that holds the 
                // encrypted data.
                byte[] ret = mStream.ToArray();

                // Close the streams.
                cStream.Close();
                mStream.Close();

                // Return the encrypted buffer.
                return ret;
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }

        }
        /// <summary>
        /// �ǤJ�r��i��[�K�C
        /// </summary>
        /// <param name="EncryptingString"></param>
        /// <returns></returns>
        public static string Encrypt(string DataString)
        {
            byte[] buff = EncryptTextToMemory(DataString, Convert.FromBase64String(rgbKey), Convert.FromBase64String(rgbIV));
            return Convert.ToBase64String(buff);
        }
    }
}
