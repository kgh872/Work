using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace MetaEdge.Security
{
    public class AESEncryptor
    {
        private static string rgbKey = MetaEdge.Registry.AppSettingsFactory.Get("rbgKey");
        /// TripleDES�[�K�p�_
        /// </summary>
        public static string RgbKey
        {
            set { rgbKey = value; }
        }

        private static string rgbIV = MetaEdge.Registry.AppSettingsFactory.Get("rbgIV");
        /// <summary>
        /// TripleDES��l�ƦV�q
        /// </summary>
        public static string RgbIV
        {
            set { rgbIV = value; }
        }

        public static byte[] EncryptTextToMemory(string Data, byte[] Key, byte[] IV)
        {
            try
            {
                byte[] encrypted;

                using (RijndaelManaged AES = new RijndaelManaged())
                {
                    ICryptoTransform encryptor = AES.CreateEncryptor(Key, IV);

                    using (MemoryStream msEncrypt = new MemoryStream())
                    {
                        using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(Data);
                            }
                            encrypted = msEncrypt.ToArray();
                        }
                    }
                }

                return encrypted;
            }
            catch (CryptographicException e)
            {
                Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
                return null;
            }

        }
        /// <summary>
        /// �ǤJ�r��i��[�K�C
        /// </summary>
        /// <param name="EncryptingString"></param>
        /// <returns></returns>
        public static string Encrypt(string DataString)
        {
            byte[] buff = EncryptTextToMemory(DataString, Convert.FromBase64String(rgbKey), Convert.FromBase64String(rgbIV));
            return Convert.ToBase64String(buff);
        }
    }
}
