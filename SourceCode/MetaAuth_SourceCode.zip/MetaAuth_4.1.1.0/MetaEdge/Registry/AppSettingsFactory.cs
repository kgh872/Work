﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Runtime.Caching;

namespace MetaEdge.Registry
{
    public class AppSettingsFactory
    {
        static public string Get(string settingName)
        {
            string configType = ConfigurationManager.AppSettings["ConfigType"].ToString();
            string settingValue = string.Empty;

            //驗證是否為WebConFig選擇來源Value是否為數字,若回傳錯誤
            int SelectSource = 0;
            bool result = int.TryParse(configType, out SelectSource);

            if (result == true)
            {
                switch (SelectSource)
                {
                    case 0:
                        settingValue = GetRegistryValue(settingName);
                        break;
                    case 1:
                        settingValue = (ConfigurationManager.AppSettings[settingName] ?? "").ToString();
                        break;
                }
            }
            return settingValue;
        }

        private static string GetRegistryValue(string settingName)
        {
            Dictionary<string, string> registryAppSettingsDictionary = null;
            string settingValue = string.Empty;
            if (MemoryCache.Default["RegistryAppSettingsDictionary"] != null)
            {
                registryAppSettingsDictionary = (Dictionary<string, string>)MemoryCache.Default["RegistryAppSettingsDictionary"];

                if (!registryAppSettingsDictionary.TryGetValue(settingName, out settingValue))
                {
                    return null;
                    //throw new Exception(string.Format("The registry key [{0}] is not found.", settingName));
                }
                return registryAppSettingsDictionary[settingName];
            }

            string regeditPath = ConfigurationManager.AppSettings["RegeditPath"].ToString();
            Microsoft.Win32.RegistryKey start = Microsoft.Win32.Registry.LocalMachine;
            Microsoft.Win32.RegistryKey programName = start.OpenSubKey(regeditPath + "\\AppSettings");
            if (programName == null)
            {
                Microsoft.Win32.RegistryKey localMachine64 = Microsoft.Win32.RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryView.Registry64);
                programName = localMachine64.OpenSubKey(regeditPath + "\\AppSettings", false);

            }

            if (programName != null)
            {
                registryAppSettingsDictionary = new Dictionary<string, string>();
                string[] allKeys = programName.GetValueNames();
                foreach (string key in allKeys)
                {
                    registryAppSettingsDictionary.Add(key, programName.GetValue(key).ToString());
                }

                //settingValue = (string)programName.GetValue(settingName);
                CacheItemPolicy policy = new CacheItemPolicy
                {
                    SlidingExpiration = new TimeSpan(0, 60, 0)
                };
                MemoryCache.Default.Add("RegistryAppSettingsDictionary", registryAppSettingsDictionary, policy);

                settingValue = GetRegistryValue(settingName);
                programName.Close();
            }
            return settingValue;
        }
    }
}
