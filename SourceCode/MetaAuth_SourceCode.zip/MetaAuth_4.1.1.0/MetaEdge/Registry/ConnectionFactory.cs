﻿using System;
using System.Data;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Runtime.Remoting;
using System.Collections.Specialized;
using System.Collections;
using MetaEdge.Security;
using System.Configuration;
using SpreadsheetGear;

namespace MetaEdge.Registry
{
    public class ConnectionFactory
    {
        static public string Get(string connectionName)
        {
            string configType = ConfigurationManager.AppSettings["ConfigType"].ToString();
            string regeditPath = ConfigurationManager.AppSettings["RegeditPath"].ToString();
            string connectionString = string.Empty;

            //驗證是否為WebConFig選擇來源Value是否為數字,若回傳錯誤
            int SelectSource = 0;
            bool result = int.TryParse(configType, out SelectSource);

            if (result == true)
            {
                switch (SelectSource)
                {
                    case 0:
                        Microsoft.Win32.RegistryKey start = Microsoft.Win32.Registry.LocalMachine;
                        Microsoft.Win32.RegistryKey programName = start.OpenSubKey(regeditPath + "\\Connections");

                        if (programName == null)
                        {
                            Microsoft.Win32.RegistryKey localMachine64 = Microsoft.Win32.RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, Microsoft.Win32.RegistryView.Registry64);
                            programName = localMachine64.OpenSubKey(regeditPath + "\\Connections", false);
                        }

                        if (programName != null)
                        {
                            connectionString = (string)programName.GetValue(connectionName);
                            programName.Close();
                        }
                        break;
                    case 1:
                        connectionString = ConfigurationManager.AppSettings[connectionName].ToString();
                        break;
                }

                if (!string.IsNullOrEmpty(connectionString))
                {
                    connectionString = AESDecryptor.Decrypt(connectionString);
                }
            }

            return connectionString;
        }
    }
}
