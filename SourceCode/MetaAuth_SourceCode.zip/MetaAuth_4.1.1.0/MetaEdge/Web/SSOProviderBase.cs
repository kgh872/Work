﻿using System.Web;
using System.Web.Security;
using Newtonsoft.Json.Linq;
using MetaEdge.Data;

namespace MetaEdge.Web
{
    public class SSOProviderBase
    {
        public virtual SSOInfo Verify(SSOInfo jobject)
        {
            return jobject;
        }

    }
}
