﻿using System.Web;
using System.Web.Security;
using Newtonsoft.Json.Linq;

namespace MetaEdge.Web
{
    public class UserInfo
    {
        public UserInfo()
        {
            if (HttpContext.Current.User == null && !(HttpContext.Current.User.Identity is FormsIdentity))
            {
                return;
            }

            try
            {
                string appguid = System.Web.Configuration.WebConfigurationManager.AppSettings["AppCookieGUID"];

                HttpCookie ticketCookie = HttpContext.Current.Request.Cookies["MetaEdge" + appguid];
                HttpCookie ticketCookieSubstitute = HttpContext.Current.Request.Cookies["MetaEdge-Substitute" + appguid];

                if (ticketCookieSubstitute != null)
                {
                    FormsAuthenticationTicket ticketSubstitute = FormsAuthentication.Decrypt(ticketCookie.Value);
                    string userDataSubstitute = ticketSubstitute.UserData;
                    if (userDataSubstitute.ToLower().IndexOf("userdata=") > -1)
                    {
                        JObject jObjSubstitute = JObject.Parse(userDataSubstitute.Split('|')[0].Split('=')[1]);
                        if (jObjSubstitute["UserId"] != null && jObjSubstitute["UserCode"] != null)
                        {
                            this.SubstituteUserId = jObjSubstitute["UserId"].ToString();
                            this.SubstituteUserCode = jObjSubstitute["UserCode"].ToString();
                            this.SubstituteUserName = jObjSubstitute["UserName"].ToString();
                        }
                    }

                    ticketCookie = HttpContext.Current.Request.Cookies["MetaEdge-Substitute" + appguid];
                }

                FormsAuthenticationTicket ticket;
                if (ticketCookie != null)
                {
                    ticket = FormsAuthentication.Decrypt(ticketCookie.Value);
                }
                else
                {
                    if (!HttpContext.Current.User.Identity.GetType().Equals(typeof(FormsIdentity))) return;
                    FormsIdentity id = (FormsIdentity)HttpContext.Current.User.Identity;
                    ticket = id.Ticket;
                }

                string userData = ticket.UserData;
                if (userData.ToLower().IndexOf("userdata=") > -1)
                {
                    JObject jObj = JObject.Parse(userData.Split('|')[0].Split('=')[1]);
                    if (jObj["UserId"] != null && jObj["UserCode"] != null)
                    {
                        this.UserId = int.Parse(jObj["UserId"].ToString());
                        this.UserCode = jObj["UserCode"].ToString();
                        this.UserName = jObj["UserName"].ToString();
                        this.AffiliateId = int.Parse(jObj["AffiliateId"].ToString());
                        this.AffiliateName = jObj["AffiliateName"].ToString();
                        this.SessionId = jObj["SessionId"].ToString();
                    }
                }
            }
            catch
            {
            }
        }


        /// <summary>
        /// 使用者識別子
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// 使用者代號
        /// </summary>
        public string UserCode { get; set; }

        /// <summary>
        /// 使用者姓名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 使用者所在組織代號
        /// </summary>
        public int? AffiliateId { get; set; }

        /// <summary>
        /// 使用者所在組織名稱
        /// </summary>
        public string AffiliateName { get; set; }

        /// <summary>
        /// SessionId
        /// </summary>
        public string SessionId { get; set; }

        /// <summary>
        /// RoleCode
        /// </summary>
        public string RoleCode { get; set; }

        /// <summary>
        /// 代理人識別
        /// </summary>
        public string SubstituteUserId { get; set; }

        /// <summary>
        /// 代理人代號
        /// </summary>
        public string SubstituteUserCode { get; set; }

        /// <summary>
        /// 代理人名稱
        /// </summary>
        public string SubstituteUserName { get; set; }
    }
}
