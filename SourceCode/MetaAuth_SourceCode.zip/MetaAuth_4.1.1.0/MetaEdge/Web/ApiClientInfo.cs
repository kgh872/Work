﻿using MetaEdge.Data;
using System;
using System.Web;

namespace MetaEdge.Web
{
    public class ApiClientInfo
    {
        public string LogType { get; set; }
        public int AppId { get; set; }
        public int UserId { get; set; }
        public string UserCode { get; set; }
        public string UserName { get; set; }
        public string UserHostAddress { get; set; }
        public string ActionName { get; set; }
        public int? AffiliateId { get; set; }

        DateTime? requestTime = null;
        public DateTime? RequestTime
        {
            get
            {
                if (requestTime == null)
                {
                    string expiredSecondString = MetaEdge.Registry.AppSettingsFactory.Get("TokenExpiredSecond");
                    int expiredSecond = 60;
                    if (!int.TryParse(expiredSecondString, out expiredSecond))
                    {
                        expiredSecond = 60;
                    }
                    requestTime = DateTime.Now.AddSeconds(expiredSecond);
                }
                return requestTime;
            }
            set
            {
                requestTime = value;
            }
        }

        public static string Create()
        {
            string logType = "Operation";
            return Create(logType);
        }

        public static string Create(string logType)
        {
            string ActionName = string.Empty;
            Uri referrer = HttpContext.Current.Request.UrlReferrer;
            if (referrer != null)
            {
                ActionName = referrer.OriginalString;
            }

            UserInfo userInfo = new UserInfo();

            ApiClientInfo clientInfo = new ApiClientInfo();
            clientInfo.LogType = logType;
            clientInfo.AppId = int.Parse(MetaEdge.Registry.AppSettingsFactory.Get("APPID"));
            clientInfo.UserId = userInfo.UserId;
            clientInfo.UserCode = userInfo.UserCode;
            clientInfo.UserName = HttpUtility.UrlEncode(userInfo.UserName);
            clientInfo.UserHostAddress = HttpContext.Current.Request.UserHostAddress;
            clientInfo.ActionName = ActionName;// HttpContext.Current.Request.UrlReferrer.AbsolutePath;
            clientInfo.AffiliateId = userInfo.AffiliateId;

            string info = Newtonsoft.Json.JsonConvert.SerializeObject(clientInfo);

            if (MetaEdge.Registry.AppSettingsFactory.Get("WebInfoEncrypt") != "Y")
            {
                return Newtonsoft.Json.JsonConvert.SerializeObject(clientInfo);
            }
            else
            {
                info = MetaEdge.Security.AESEncryptor.Encrypt(info);
                byte[] bytes = System.Text.Encoding.GetEncoding("utf-8").GetBytes(info);

                return Convert.ToBase64String(bytes);
            }
        }
    }
}
