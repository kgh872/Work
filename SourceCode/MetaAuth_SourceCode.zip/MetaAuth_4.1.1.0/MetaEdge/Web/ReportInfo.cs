﻿namespace MetaEdge.Web
{
    using System;
    using System.Web;
    using System.Collections.Specialized;
    using System.Text;
    public class ReportInfo
    {
        public static ReportInfo Current
        {
            get
            {
                ReportInfo reportInfo = new ReportInfo();
                if (HttpContext.Current.Session["ReportInfo"] != null)
                {
                    reportInfo = HttpContext.Current.Session["ReportInfo"] as ReportInfo;
                }
                return reportInfo;
            }
        }

        public ReportInfo()
        {
            string[] KeyValuePairs = ConnectionString.Split(';');
            string[] KeyValues;
            int i = 0;
            try
            {
                for (i = 0; i < KeyValuePairs.Length; i++)
                {
                    KeyValues = KeyValuePairs[i].Split('=');
                    switch (KeyValues[0])
                    {
                        case "ReportServerDomain": this.ReportServerDomain = KeyValues[1]; break;
                        case "ReportServer": this.ReportServer = KeyValues[1]; break;
                        case "ReportServerTimeout": this.ReportServerTimeout = int.Parse(KeyValues[1]); ; break;
                        case "ReportServerUrl": this.ReportServerUrl = KeyValues[1]; break;
                        case "ReportServerFolder": this.ReportServerFolder = KeyValues[1]; break;
                        case "ReportServerUserName": this.ReportServerUserName = KeyValues[1]; break;
                        case "ReportServerPassword": this.ReportServerPassword = KeyValues[1]; break;
                        default:
                            break;
                    }
                }

                NameValueCollection utf8Request;
                utf8Request = HttpUtility.ParseQueryString(HttpContext.Current.Request.Url.Query, Encoding.UTF8);
                this.ReportName = utf8Request["rptName"];

            }
            catch (Exception ex)
            {
                new Exception(KeyValuePairs[i] + ": 參數設定錯誤!\r\n" + ex.GetBaseException().Message);
            }
        }

        public ReportInfo(string connectionString)
            : this()
        {
            this._connectionString = connectionString;
        }

        string _connectionString = string.Empty;
        //  ReportParameter _extenderReportParameter;

        public string ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_connectionString))
                {
                    _connectionString = MetaEdge.Registry.ConnectionFactory.Get("Report");
                    //_connectionString = MetaEdge.Security.AESDecryptor.Decrypt(_connectionString);
                }

                return _connectionString;
            }
            set
            {
                _connectionString = value;
            }
        }

        public int ReportServerTimeout { get; set; }
        public string ReportServer { get; set; }
        public string ReportServerUrl { get; set; }
        public string ReportServerFolder { get; set; }
        public string ReportServerDomain { get; set; }
        public string ReportServerUserName { get; set; }
        public string ReportServerPassword { get; set; }
        public string ReportName { get; set; }

        public string ReportPath
        {
            get
            {
                return "/" + this.ReportServerFolder + "/" + this.ReportName;
            }
        }

        public string Command { get; set; }
        public string ActionName { get; set; }
        public string UserHostName { get; set; }

    }
}