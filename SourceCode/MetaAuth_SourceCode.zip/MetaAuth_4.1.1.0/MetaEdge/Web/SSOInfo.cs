﻿using System.Web;
using System.Web.Security;
using Newtonsoft.Json.Linq;
using MetaEdge.Data;

namespace MetaEdge.Web
{
    public class SSOInfo
    {
        public SSOInfo()
        {
            JObjectData = new JObject();
        }

        /// <summary>
        /// 使用者識別子
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// 使用者代號
        /// </summary>
        public string UserCode { get; set; }

        /// <summary>
        /// 使用者姓名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 使用者密碼
        /// </summary>
        public string UserPassw { get; set; }

        /// <summary>
        /// 使用者所在組織
        /// </summary>
        public int? AffiliateId { get; set; }

        /// <summary>
        /// 使用者所在組織名稱
        /// </summary>
        public string AffiliateName { get; set; }

        /// <summary>
        /// JObjectData: Cookies, ServerVariables
        /// </summary>
        public JObject JObjectData { get; set; }

        /// <summary>
        /// 訊息
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// 證驗結果
        /// </summary>
        public bool IsAuthenticated { get; set; }

    }
}
