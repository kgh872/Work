﻿using System;
using System.IO;
using System.Web;
using System.Collections;
using System.Diagnostics;
using MetaEdge.Logging;

namespace MetaEdge.Utility
{
    // Create our own utility for exceptions
    public sealed class ExceptionUtility
    {
        // All methods are static, so this can be private
        private ExceptionUtility()
        { }

        // Log an Exception
        public static void LogException(Exception exc, string source)
        {
            string logTarget = MetaEdge.Registry.AppSettingsFactory.Get("LogTarget");
            switch (logTarget)
            {
                case "SQL":
                    LoggerManager.Adapter = new Logging.MSSQL.MSSQLLoggerFactoryAdapter(MetaEdge.Registry.ConnectionFactory.Get("MetaAuth"));
                    LoggerManager.GetCurrentLogger(source).Error(exc);
                    break;
                case "FILE":
                    LoggerManager.Adapter = new Logging.Default.FileLoggerFactoryAdapter();
                    LoggerManager.GetCurrentLogger(source).Error(exc);
                    break;
                default:
                    Orig_LogExceptionFile(exc, source);
                    break;
            }
        }

        public static void Orig_LogExceptionFile(Exception exc, string source)
        {
            // Include enterprise logic for logging exceptions
            // Get the absolute path to the log file
            //string logFile = "~/App_Data/ErrorLog/ErrorLog.txt";
            //logFile = HttpContext.Current.Server.MapPath(logFile);

            //每天存一個檔案
            string fileHead = "OpLog";  //檔案前置詞
            string ErrorMessageTitle = string.Empty;
            string ErrorMessage = string.Empty;
            string now = DateTime.Now.ToString("yyyyMMdd");
            FileInfo lastFile;

            string _textFileFolder = AppDomain.CurrentDomain.BaseDirectory + @"\App_Data\ErrorLog";
            if (!Directory.Exists(_textFileFolder))
            {
                Directory.CreateDirectory(_textFileFolder);
            }
            DirectoryInfo dir = new DirectoryInfo(_textFileFolder);
            FileInfo[] fileInfos = dir.GetFiles(string.Format("{0}{1}.txt",
                                                    fileHead,
                                                    now));
            if (fileInfos.Length > 0)
                lastFile = fileInfos[0];
            else
                lastFile = new FileInfo(string.Format(@"{0}\{1}{2}.txt", dir.FullName, fileHead, now));

            // Open the log file for append and write the log
            using (StreamWriter sw = new StreamWriter(lastFile.FullName, true))
            {
                sw.WriteLine("********{0}********", DateTime.Now);

                Exception realException = exc.GetBaseException();
                if (exc.InnerException != null)
                {
                    realException = exc.InnerException.GetBaseException();
                }
                if (realException != null && HttpContext.Current != null)
                {
                    sw.Write("User ID: ");
                    sw.Write(HttpContext.Current.User.Identity.Name);
                    sw.Write("     Remote IP: ");
                    sw.Write(HttpContext.Current.Request.UserHostAddress);
                    sw.Write("     Browser Type: ");
                    sw.WriteLine(HttpContext.Current.Request.Browser.Type);

                    sw.WriteLine("Base Exception");
                    sw.Write("     Source: ");
                    sw.WriteLine(realException.Source);
                    sw.Write("     Type: ");
                    sw.WriteLine(realException.GetType().ToString());
                    sw.Write("     Message: ");
                    sw.WriteLine(realException.Message);

                }
                sw.WriteLine("Exception");
                sw.Write("     Source: ");
                sw.WriteLine(source);
                sw.Write("     Type: ");
                sw.WriteLine(exc.GetType().ToString());
                sw.Write("     Message: ");
                sw.WriteLine(exc.Message);

                sw.WriteLine("Stack Trace: ");
                if (exc.StackTrace != null)
                {
                    sw.WriteLine(exc.StackTrace);
                }
                sw.WriteLine();
            }
        }

        // Notify System Operators about an exception
        /// <summary>
        /// 錯誤回報機制
        /// </summary>
        /// <param name="exc"></param>
        public static void NotifySystemOps(Exception exc, string source)
        {
            // Include code for notifying IT system operators
        }

        /// <summary>
        /// 取得自訂安全錯誤訊息。
        /// </summary>
        /// <param name="exc"></param>
        /// <returns></returns>
        public static string GetSafeMessage(Exception exc)
        {
            string s = string.Empty;
            string SafeMessageKey = "SafeMessage";
            Exception ex = exc;
            while (ex != null)
            {
                foreach (DictionaryEntry item in ex.Data)
                {
                    if (item.Key.ToString().Equals(SafeMessageKey))
                        s += item.Value;
                }
                ex = ex.InnerException;
            }
            return s;
        }


    }
}