﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MetaEdge.Utility
{
    public class DataValidator
    {
        public static T ValidateEntity<T>(T entity)
        {
            T newEntity = (T)Activator.CreateInstance(entity.GetType());

            foreach (var prop in entity.GetType().GetProperties())
            {
                var value = prop.GetValue(entity, null);

                if (value == null) { prop.SetValue(newEntity, null, null); }
                //else if (prop.PropertyType.Name == "DateTime") { prop.SetValue(newEntity, value, null); }
                else
                {
                    var newValue = Regex.Match(value.ToString(), @"^[\p{L}\p{M}\p{N}\s\p{P}\<>$^+=|~`]*$");
                    Type t = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    try
                    {
                        //因造字會被過濾，要先比對內容與長度後才寫入值
                        if (!value.ToString().Equals(newValue.Value) || (value.ToString().Length != newValue.Value.Length))
                        {

                            prop.SetValue(newEntity, System.ComponentModel.TypeDescriptor.GetConverter(t).ConvertFrom(value), null);
                        }
                        else
                        {
                            prop.SetValue(newEntity, System.ComponentModel.TypeDescriptor.GetConverter(t).ConvertFrom(newValue.Value), null);
                        }
                    }
                    catch (Exception ex)
                    {
                        Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("MetaEdge.Utility.ValidateEntity");
                        logger.Error(string.Format("entity: {0}", entity.ToString()), ex);
                        throw new Exception("Failed to verify entity.", ex);
                    }
                }
            }
            return newEntity;
        }

        public static T ValidateObject<T>(T value)
        {
            if (value == null) return default(T);

            try
            {
                Type t = Nullable.GetUnderlyingType(typeof(T)) ?? typeof(T);
                //string checkValue = t.Name == "DateTime" ? ((DateTime)(object)value).ToString("yyyy-MM-ddTHH:mm:ss.ffff") : value.ToString();
                var newValue = Regex.Match(value.ToString(), @"^[\p{L}\p{M}\p{N}\s\p{P}\<>$^+=|~`\u0000-\uFFEF]*$");

                return (T)System.ComponentModel.TypeDescriptor.GetConverter(t).ConvertFrom(newValue.Value);
            }
            catch (Exception ex)
            {
                Logging.ILogger logger = Logging.LoggerManager.GetCurrentLogger("MetaEdge.Utility.ValidateObject");
                logger.Error(string.Format("value: {0}", value.ToString()), ex);
                throw new Exception("Failed to verify object.", ex);
            }
        }
    }
}