﻿using System;
using System.Configuration;
using log4net;
using log4net.Config;

namespace MetaEdge.TextLog
{
    public abstract class ApiConfig
    {
        protected static ILog log = LogManager.GetLogger(typeof(ApiConfig));

        protected static readonly log4net.Core.Level GetLevel = new log4net.Core.Level(50000, "GET", "GET");
        protected static readonly log4net.Core.Level PostLevel = new log4net.Core.Level(50001, "POST", "POST");
        protected static readonly log4net.Core.Level PutLevel = new log4net.Core.Level(50002, "PUT", "PUT");
        protected static readonly log4net.Core.Level DeleteLevel = new log4net.Core.Level(50003, "DELETE", "DELETE");

        protected string _json { get; set; }
        protected string _url { get; set; }
        protected string _type { get; set; }

        public virtual void WriteLog(ApiConfig _instance)
        {
            log = LogManager.GetLogger(_instance.GetType().FullName);
            log4net.LogManager.GetRepository().LevelMap.Add(GetLevel);
            log4net.LogManager.GetRepository().LevelMap.Add(PostLevel);
            log4net.LogManager.GetRepository().LevelMap.Add(PutLevel);
            log4net.LogManager.GetRepository().LevelMap.Add(DeleteLevel);
            log4net.ThreadContext.Properties["uri"] = this._url;
            log4net.ThreadContext.Properties["json"] = this._json.Replace("\\\"", "\"").Replace(@"\r\n", "");
        }

        protected ApiConfig(string json, string url)
        {
            this._json = json;
            this._url = url;
        }
    }

    public enum HttpMethod { GET = 0, POST = 1, PUT = 2, DELETE = 3 }

    public class ApiFactory
    {
        public static void WriteLog(string _json, string _method, string _url)
        {
            string configPath = MetaEdge.Registry.AppSettingsFactory.Get("LogFilePath");
            XmlConfigurator.Configure(new System.IO.FileInfo(configPath));

            string[] skipItem = new string[] { "PageMenu", "BreadcrumbTrail", "PageCommand", "log_Audit", "log_CodeTrace", "log_Logon", "log_Operation" };

            bool isPass = false;
            foreach (string skip in skipItem)
            {
                if (_url.Contains(skip))
                {
                    isPass = true;
                }
            }

            if (isPass) { return; }

            HttpMethod httpType;
            if (Enum.TryParse<HttpMethod>(_method, out httpType))
            { }

            ApiConfig _instance = null;
            switch (httpType)
            {
                case HttpMethod.GET:
                    _instance = new ApiGet(_json, _url);
                    break;
                case HttpMethod.POST:
                    _instance = new ApiPost(_json, _url);
                    break;
                case HttpMethod.PUT:
                    _instance = new ApiPut(_json, _url);
                    break;
                case HttpMethod.DELETE:
                    _instance = new ApiDelete(_json, _url);
                    break;
            }
            _instance.WriteLog(_instance);
        }
    }
}
