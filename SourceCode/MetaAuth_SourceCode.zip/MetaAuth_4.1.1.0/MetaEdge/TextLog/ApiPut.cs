﻿namespace MetaEdge.TextLog
{
    public class ApiPut : ApiConfig
    {
        public ApiPut(string json, string url)
            : base(json, url)
        {

        }

        public override void WriteLog(ApiConfig _instance)
        {
            base.WriteLog(_instance);
            log.Logger.Log(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType, ApiConfig.PutLevel, "", null);
        }
    }
}
